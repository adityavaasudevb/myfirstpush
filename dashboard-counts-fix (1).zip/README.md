# Dashboard fixes — 5 files, two bugs

Apply in this order. Steps 1 and 2 must go together (the record constructor changed).

| # | File | What changed |
|---|---|---|
| 1 | `Application/Dtos/DashboardDto.cs` | `+ int ClaimsDecidedThisMonth` at the **end** of the record |
| 2 | `Infrastructure/Services/DashboardService.cs` | active-policies predicate fixed; new count supplied |
| 3 | `features/dashboard/models/dashboard.model.ts` | `+ claimsDecidedThisMonth` |
| 4 | `features/dashboard/admin-dashboard/admin-dashboard.html` | labels + sublines + ratio caption |
| 5 | `features/dashboard/admin-dashboard/admin-dashboard.ts` | `ratioCaption()` helper |

`admin-dashboard.html` and `.ts` here already include the ratio-caption work —
this set **supersedes** `approval-ratio-fix.zip`. Do not apply both.

## Bug 1 — 28 vs 26 active policies (confirmed by your query)

```csharp
// before: counted a paid renewal starting in the future
p.Status == Active && p.EndDateUtc >= now

// after: same predicate the policy explorer's "Active" chip uses
p.Status == Active && p.StartDateUtc <= now && p.EndDateUtc > now
```

## Bug 2 — the cards said "this month" without saying which date

- "Claims this month" → **Claims filed** + "**N decided this month**"
- "Payouts this month" → **Approved payouts** + "Claims approved this month"
- Header note explains that claims are counted by *filing*, decisions by
  *decision*, and the claims **list** dates rows by *incident* — three dates,
  all legitimate, never equal.

Your numbers were never wrong. 13 filed in November, 9 of those for November
incidents, 4 for older ones filed late. 87,867 approved across four claims on
9, 16 and 24 November — the claims page showed them under October because its
"Date" column is the **incident** date.
