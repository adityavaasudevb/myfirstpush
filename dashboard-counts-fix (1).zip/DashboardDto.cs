// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Dtos/DashboardDto.cs
namespace InsuranceService.Application.Dtos;

/// <summary>
/// FR7.1 — the five aggregated metrics. ApprovalToRejectionRatio is null when zero rejections this month.
/// The last field was added so the "claims" card can say WHICH date it uses:
/// filing and decision are not the same month for most claims, and a card that says only
/// "this month" invites the reader to compare two different populations.
/// Kept at the END of the record so the existing five read in the same order everywhere.
/// </summary>
public record DashboardMetricsDto(
    int ActivePolicies,                  // EffectiveStatus == Active right now (lazy-expiry aware)
    int ClaimsThisMonth,                 // FILED in the current calendar month (CreatedAtUtc)
    decimal TotalPayoutThisMonthInr,     // final amounts of claims that became Paid this month
    double? ApprovalToRejectionRatio,    // approvals / rejections decided this month; null when 0 rejections
    double QuoteConversionRate,          // from GET /api/quotes/stats (forwarded Admin JWT)
    int ClaimsDecidedThisMonth);         // Paid or Rejected in the current calendar month (history-dated)

/// <summary>FR7.1 — metrics plus the Review-Required renewal attention list (informational flag, D10).</summary>
public record DashboardDto(
    DashboardMetricsDto Metrics,
    int ReviewRequiredRenewalCount,
    IReadOnlyList<PolicyListItemDto> ReviewRequiredRenewals);
