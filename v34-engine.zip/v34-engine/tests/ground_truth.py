"""
Ground truth for the eleven generated documents, written from the values that generated them.

Every number here is the number the PDF actually prints — the same values the generator passes to
reportlab, and the same ones audit_docs.py re-extracts from the finished file. If a document is
regenerated with different numbers, audit_docs.py fails; if this file drifts from the generator,
the oracle score drops. Both are alarms worth having.

`truth` is what a perfect extraction returns. Field names match ExtractedDocument (camelCase,
because that is what the JSON deserialiser on the C# side expects).
"""

import os
ALB = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
A_CLEAN = os.path.join(ALB, "lane-a-sql/documents")
A_DEF = A_CLEAN
B_CLEAN = os.path.join(ALB, "lane-b-ui/documents")
B_DEF = B_CLEAN

LANE_A_INCIDENT = "2026-11-10T05:35:00+00:00"   # 11:05 IST, inside the FIR window 10:55-11:20
LANE_A_DEFECT_INCIDENT = "2026-11-10T11:10:00+00:00"  # 16:40 IST
LANE_B_INCIDENT = "2026-11-05T04:52:00+00:00"   # 10:22 IST, inside the FIR window 10:10-10:40
LANE_B_DEFECT_INCIDENT = "2026-11-05T11:15:00+00:00"  # 16:45 IST


def _li(desc, qty, amount, rate=None, cat="charge"):
    return {"description": desc, "quantity": qty, "unitPrice": round(amount / qty, 2) if qty else None,
            "amount": amount, "taxRate": rate, "category": cat, "sourceText": desc}


DOCUMENTS = {
    # ---------------------------------------------------------------- Lane A, clean
    "A/fir-clean": {
        "path": f"{A_CLEAN}/FIR-01-clean.pdf", "type": "FIR",
        "prompt_context": "Expected document type: FIR. Claim CLM-2026-GFW103, vehicle TG11LK3607.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Fir",
            "issuerName": "Miyapur Police Station", "issuerQuote": "Miyapur POLICE STATION",
            "documentNumber": "0218 / 2026", "documentNumberQuote": "0218 / 2026",
            "documentDate": "2026-11-10", "documentDateQuote": "10 November 2026",
            "vehicleRegistration": "TG11LK3607", "vehicleRegistrationQuote": "TG11LK3607",
            "lineItems": [], "confidence": "high", "readAsImage": False,
            "notes": "Occurrence 10-Nov-2026 10:55 to 11:20 hrs, place Miyapur X Roads.",
        },
    },
    "A/estimate-clean": {
        "path": f"{A_CLEAN}/RepairEstimate-01-clean.pdf", "type": "RepairEstimate",
        "prompt_context": "Expected document type: RepairEstimate. Claim CLM-2026-GFW103, vehicle TG11LK3607.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "RepairEstimate",
            "issuerName": "MEGHNA AUTO BODY WORKS",
            "issuerQuote": "MEGHNA AUTO BODY WORKS",
            "documentNumber": "MAB/EST/2026/0418", "documentNumberQuote": "MAB/EST/2026/0418",
            "documentDate": "2026-11-10", "documentDateQuote": "10 November 2026",
            "customerName": "Greenfield Fabrication Works Pvt Ltd",
            "customerNameQuote": "Greenfield Fabrication Works Pvt Ltd",
            "vehicleRegistration": "TG11LK3607", "vehicleRegistrationQuote": "TG11LK3607",
            "lineItems": [
                _li("Door assembly — left (OEM)", 1, 24600),
                _li("Mirror assembly — left, electric", 1, 3950),
                _li("Side panel — load body, MS sheet", 1, 12200),
                _li("Door lock and latch set", 1, 2350),
                _li("Dent and shape correction", 6, 5100),
                _li("Refit and alignment of door", 4, 3400),
                _li("Paint booth — two panels", 6, 5400),
                _li("Electrical refit — mirror and lock", 2, 1500),
                _li("Shop supplies and disposal", 1, 1800),
            ],
            "subtotalLines": [
                {"label": "Parts subtotal", "amount": 43100, "sourceText": "Parts subtotal ₹43,100.00"},
                {"label": "Labour subtotal", "amount": 15400, "sourceText": "Labour subtotal ₹15,400.00"},
            ],
            "taxAmount": 10854.00, "taxQuote": "Tax at 18% ₹10,854.00", "taxRates": [18],
            "grandTotal": 71154.00, "grandTotalQuote": "Estimated total ₹71,154.00",
            "confidence": "high", "readAsImage": False,
        },
    },
    "A/towing-clean": {
        "path": f"{A_CLEAN}/TowingReceipt-01-clean.pdf", "type": "Other",
        "prompt_context": "Expected document type: Other (towing). Claim CLM-2026-GFW103, vehicle TG11LK3607.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Other",
            "issuerName": "Miyapur Road Towing", "issuerQuote": "Miyapur Road Towing",
            "documentNumber": "MRT / 1164", "documentNumberQuote": "MRT / 1164",
            "documentDate": "2026-11-10", "documentDateQuote": "10 November 2026",
            "vehicleRegistration": "TG11LK3607", "vehicleRegistrationQuote": "TG11LK3607",
            "towedTo": "Meghna Auto Body Works, Survey 44/2, Miyapur X Roads",
            "towedToQuote": "Meghna Auto Body Works, Survey 44/2, Miyapur X Roads",
            "lineItems": [
                _li("Flatbed tow — 3 km", 1, 1400),
                _li("Door tie-down and safety film", 1, 350),
                _li("Loading assistance", 1, 250),
            ],
            "taxAmount": 0, "taxRates": [],
            "grandTotal": 2000.00, "grandTotalQuote": "Total ₹2,000.00",
            "amountPaid": 2000.00, "confidence": "high", "readAsImage": False,
        },
    },
    # ---------------------------------------------------------------- Lane A, defective
    "A/estimate-defect": {
        "path": f"{A_DEF}/RepairEstimate-02-defects.pdf", "type": "RepairEstimate",
        "prompt_context": "Expected document type: RepairEstimate. Claim CLM-2026-GFW104, vehicle TG11LK3607.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "RepairEstimate",
            "issuerName": "MEGHNA AUTO BODY WORKS", "issuerQuote": "MEGHNA AUTO BODY WORKS",
            "documentNumber": "MAB/EST/2026/0431", "documentNumberQuote": "MAB/EST/2026/0431",
            # plant 1: two days before the incident
            "documentDate": "2026-11-08", "documentDateQuote": "08 November 2026",
            "customerName": "Greenfield Fabrication Works Pvt Ltd",
            "customerNameQuote": "Greenfield Fabrication Works Pvt Ltd",
            # plant 2: a different vehicle
            "vehicleRegistration": "TG11LK3617", "vehicleRegistrationQuote": "TG11LK3617",
            "lineItems": [
                _li("Clutch plate assembly (OEM)", 1, 14800),
                _li("Pressure plate", 1, 9600),
                _li("Brake drum — rear pair", 2, 9800),
                _li("Gearbox removal and refit", 8, 6800),
                _li("Clutch replacement", 4, 3400),
                _li("Brake overhaul", 3, 2550),
                _li("Shop supplies and disposal", 1, 1200),
            ],
            "subtotalLines": [
                {"label": "Parts subtotal", "amount": 34200, "sourceText": "Parts subtotal ₹34,200.00"},
                {"label": "Labour subtotal", "amount": 12750, "sourceText": "Labour subtotal ₹12,750.00"},
            ],
            # plant 3: 18% of 48,150 is 8,667 — printed 11,160
            "taxAmount": 11160.00, "taxQuote": "Tax at 18% ₹11,160.00", "taxRates": [18],
            "grandTotal": 59310.00, "grandTotalQuote": "Estimated total ₹59,310.00",
            "confidence": "high", "readAsImage": False,
        },
    },
    "A/towing-defect": {
        "path": f"{A_DEF}/TowingReceipt-02-defects.pdf", "type": "Other",
        "prompt_context": "Expected document type: Other (towing). Claim CLM-2026-GFW104, vehicle TG11LK3607.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Other",
            "issuerName": "Miyapur Road Towing", "issuerQuote": "Miyapur Road Towing",
            "documentNumber": "MRT / 1188", "documentNumberQuote": "MRT / 1188",
            "documentDate": "2026-11-10", "documentDateQuote": "10 November 2026",
            "vehicleRegistration": "TG11LK3607", "vehicleRegistrationQuote": "TG11LK3607",
            # plant 4: a different workshop from the estimate issuer
            "towedTo": "Sri Kalyan Motors, Kukatpally",
            "towedToQuote": "Sri Kalyan Motors, Kukatpally",
            "lineItems": [
                _li("Flatbed tow — 3 km", 1, 1400),
                _li("Storage — 2 days", 1, 600),
            ],
            "taxAmount": 360.00, "taxQuote": "Tax (18%) ₹360.00", "taxRates": [18],
            "grandTotal": 2360.00, "grandTotalQuote": "Total ₹2,360.00",
            "amountPaid": 2360.00, "confidence": "high", "readAsImage": False,
        },
    },
    # ---------------------------------------------------------------- Lane B, clean
    "B/fir-clean": {
        "path": f"{B_CLEAN}/FIR-01-clean.pdf", "type": "FIR",
        "prompt_context": "Expected document type: FIR. Claim CLM-B-A, vehicle TG13MX4747.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Fir",
            "issuerName": "Kukatpally Police Station", "issuerQuote": "Kukatpally POLICE STATION",
            "documentNumber": "0264 / 2026", "documentNumberQuote": "0264 / 2026",
            "documentDate": "2026-11-05", "documentDateQuote": "05 November 2026",
            "vehicleRegistration": "TG13MX4747", "vehicleRegistrationQuote": "TG13MX4747",
            "lineItems": [], "confidence": "high", "readAsImage": False,
            "notes": "Occurrence 05-Nov-2026 10:10 to 10:40 hrs, place KPHB Phase 6 main road.",
        },
    },
    "B/estimate-clean": {
        "path": f"{B_CLEAN}/RepairEstimate-01-clean.pdf", "type": "RepairEstimate",
        "prompt_context": "Expected document type: RepairEstimate. Claim CLM-B-A, vehicle TG13MX4747.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "RepairEstimate",
            "issuerName": "SRI VENKATA SAI MOTORS", "issuerQuote": "SRI VENKATA SAI MOTORS",
            "documentNumber": "SVSM/EST/26/0614", "documentNumberQuote": "SVSM/EST/26/0614",
            "documentDate": "2026-11-05", "documentDateQuote": "05 November 2026",
            "customerName": "Coastal Spice Logistics Pvt Ltd",
            "customerNameQuote": "Coastal Spice Logistics Pvt Ltd",
            "vehicleRegistration": "TG13MX4747", "vehicleRegistrationQuote": "TG13MX4747",
            "lineItems": [
                _li("Front bumper assembly (OEM)", 1, 9600),
                _li("Bonnet edge panel", 1, 7450),
                _li("Headlamp assembly — right", 1, 12400),
                _li("Grille and clips", 1, 2410),
                _li("Bumper removal and refit", 4, 3120),
                _li("Bonnet edge repair and paint", 7, 6230),
                _li("Headlamp alignment", 2, 1560),
                _li("Paint booth — two panels", 5, 4660),
                _li("Shop supplies and disposal", 1, 2000),
            ],
            "subtotalLines": [
                {"label": "Parts subtotal", "amount": 31860, "sourceText": "Parts subtotal ₹31,860.00"},
                {"label": "Labour subtotal", "amount": 15570, "sourceText": "Labour subtotal ₹15,570.00"},
            ],
            "taxAmount": 8897.40, "taxQuote": "Tax at 18% ₹8,897.40", "taxRates": [18],
            "grandTotal": 58327.40, "grandTotalQuote": "Estimated total ₹58,327.40",
            "confidence": "high", "readAsImage": False,
        },
    },
    "B/towing-clean": {
        "path": f"{B_CLEAN}/TowingReceipt-01-clean.pdf", "type": "Other",
        "prompt_context": "Expected document type: Other (towing). Claim CLM-B-A, vehicle TG13MX4747.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Other",
            "issuerName": "Kukatpally Recovery Services", "issuerQuote": "Kukatpally Recovery Services",
            "documentNumber": "KPR / 2207", "documentNumberQuote": "KPR / 2207",
            "documentDate": "2026-11-05", "documentDateQuote": "05 November 2026",
            "vehicleRegistration": "TG13MX4747", "vehicleRegistrationQuote": "TG13MX4747",
            "towedTo": "Sri Venkata Sai Motors, Door 5-9-88, KPHB Colony",
            "towedToQuote": "Sri Venkata Sai Motors, Door 5-9-88, KPHB Colony",
            "lineItems": [
                _li("Flatbed tow — 2 km", 1, 1200),
                _li("Winch pull from kerb", 1, 400),
            ],
            "taxAmount": 0, "taxRates": [],
            "grandTotal": 1600.00, "grandTotalQuote": "Total ₹1,600.00",
            "amountPaid": 1600.00, "confidence": "high", "readAsImage": False,
        },
    },
    # ---------------------------------------------------------------- Lane B, defective
    "B/fir-defect": {
        "path": f"{B_DEF}/FIR-02-defects.pdf", "type": "FIR",
        "prompt_context": "Expected document type: FIR. Claim CLM-B-B, vehicle TG13MX4747.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Fir",
            "issuerName": "Kukatpally Police Station", "issuerQuote": "Kukatpally POLICE STATION",
            "documentNumber": "0291 / 2026", "documentNumberQuote": "0291 / 2026",
            # plant 5: registered on the 9th for a 4 Nov occurrence
            "documentDate": "2026-11-09", "documentDateQuote": "09 November 2026",
            # plant 6: transposed registration
            "vehicleRegistration": "TG13MX4477", "vehicleRegistrationQuote": "TG13MX4477",
            "lineItems": [], "confidence": "high", "readAsImage": False,
            "notes": "Occurrence 04-Nov-2026 14:00 to 15:00 hrs; reason for delay: No delay.",
        },
    },
    "B/estimate-defect": {
        "path": f"{B_DEF}/RepairEstimate-02-defects.pdf", "type": "RepairEstimate",
        "prompt_context": "Expected document type: RepairEstimate. Claim CLM-B-B, vehicle TG13MX4747.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "RepairEstimate",
            "issuerName": "SRI VENKATA SAI MOTORS", "issuerQuote": "SRI VENKATA SAI MOTORS",
            "documentNumber": "SVSM/EST/26/0602", "documentNumberQuote": "SVSM/EST/26/0602",
            # plant 7: dated before the incident
            "documentDate": "2026-11-03", "documentDateQuote": "03 November 2026",
            "customerName": "Coastal Spice Logistics Pvt Ltd",
            "customerNameQuote": "Coastal Spice Logistics Pvt Ltd",
            "vehicleRegistration": "TG13MX4747", "vehicleRegistrationQuote": "TG13MX4747",
            "lineItems": [
                _li("Rear bumper assembly (OEM)", 1, 12000),
                _li("Tailgate outer panel", 1, 8400),
                _li("Rear combination lamp — right", 1, 4300),
                # plant 8: the same part, again
                _li("Rear bumper assembly (OEM)", 1, 12000),
                _li("Bumper removal and refit", 3, 2400),
                _li("Tailgate dent and paint", 8, 6800),
                _li("Paint booth — two panels", 2, 1600),
                _li("Shop supplies and disposal", 1, 1500),
            ],
            "subtotalLines": [
                {"label": "Parts subtotal", "amount": 36700, "sourceText": "Parts subtotal ₹36,700.00"},
                {"label": "Labour subtotal", "amount": 10800, "sourceText": "Labour subtotal ₹10,800.00"},
            ],
            "taxAmount": 8820.00, "taxQuote": "Tax at 18% ₹8,820.00", "taxRates": [18],
            "grandTotal": 57820.00, "grandTotalQuote": "Estimated total ₹57,820.00",
            "confidence": "high", "readAsImage": False,
        },
    },
    "B/towing-defect": {
        "path": f"{B_DEF}/TowingReceipt-02-defects.pdf", "type": "Other",
        "prompt_context": "Expected document type: Other (towing). Claim CLM-B-B, vehicle TG13MX4747.",
        "truth": {
            "schemaVersion": "1.0", "documentKind": "Other",
            "issuerName": "Kukatpally Recovery Services", "issuerQuote": "Kukatpally Recovery Services",
            "documentNumber": "KPR / 2241", "documentNumberQuote": "KPR / 2241",
            # plant 9: the day AFTER the incident — legitimate for a tow, listed so the oracle
            # proves the engine does NOT flag it
            "documentDate": "2026-11-06", "documentDateQuote": "06 November 2026",
            "vehicleRegistration": "TG13MX4747", "vehicleRegistrationQuote": "TG13MX4747",
            "towedTo": "Sri Venkata Sai Motors, Door 5-9-88, KPHB Colony",
            "towedToQuote": "Sri Venkata Sai Motors, Door 5-9-88, KPHB Colony",
            "lineItems": [
                _li("Flatbed tow — 2 km", 1, 1200),
                _li("Storage — 1 day", 1, 400),
            ],
            "taxAmount": 288.00, "taxQuote": "Tax (18%) ₹288.00", "taxRates": [18],
            "grandTotal": 1888.00, "grandTotalQuote": "Total ₹1,888.00",
            "amountPaid": 1888.00, "confidence": "high", "readAsImage": False,
        },
    },
}

# The claims these documents belong to, with the verdict each document set deserves.
CLAIMS = [
    {
        "key": "1", "number": "CLM-2026-GFW103",
        "claimType": "Own Vehicle Damage", "vehicle": "TG11LK3607",
        "driver": "Karthik Iyer", "passenger": "Devi Priya",
        "incidentUtc": LANE_A_INCIDENT, "claimed": 71154.00,
        "documents": ["A/fir-clean", "A/estimate-clean", "A/towing-clean"],
        "expectedVerdict": "Consistent", "expectedCodes": [],
    },
    {
        "key": "2", "number": "CLM-2026-GFW104",
        "claimType": "Own Vehicle Damage", "vehicle": "TG11LK3607",
        "driver": "Prakash Menon", "passenger": "Anita Salve",
        "incidentUtc": LANE_A_DEFECT_INCIDENT, "claimed": 44500.00,
        "documents": ["A/estimate-defect", "A/towing-defect"],
        "expectedVerdict": "Inconsistent",
        "expectedCodes": ["VEHICLE_MISMATCH", "DATE_OUTSIDE_WINDOW",
                          "TAX_RATE_MISMATCH", "EXCEEDS_CLAIMED_AMOUNT", "EXTRACTION_DISAGREES"],
    },
    {
        "key": "3", "number": "CLM-B-A",
        "claimType": "Own Vehicle Damage", "vehicle": "TG13MX4747",
        "driver": "Suresh Pillai", "passenger": "Meera Chandran",
        "incidentUtc": LANE_B_INCIDENT, "claimed": 58327.40,
        "documents": ["B/fir-clean", "B/estimate-clean", "B/towing-clean"],
        "expectedVerdict": "Consistent", "expectedCodes": [],
    },
    {
        "key": "4", "number": "CLM-B-B",
        "claimType": "Own Vehicle Damage", "vehicle": "TG13MX4747",
        "driver": "Suresh Pillai", "passenger": "Anil Kumar",
        "incidentUtc": LANE_B_DEFECT_INCIDENT, "claimed": 52780.00,
        "documents": ["B/fir-defect", "B/estimate-defect", "B/towing-defect"],
        "expectedVerdict": "Inconsistent",
        "expectedCodes": ["VEHICLE_MISMATCH", "DATE_OUTSIDE_WINDOW",
                          "DUPLICATE_LINE", "EXCEEDS_CLAIMED_AMOUNT", "EXTRACTION_DISAGREES"],
    },
]


# --------------------------------------------------------------------------------------------
# WHERE EACH PLANTED DEFECT LIVES — the score sheet eval.py scores against.
# `expectedCodes` above is what the engine must raise. This maps each one to the document that
# carries it, so a reviewer can open the PDF and see the plant with their own eyes.
#
#   key                      defect                                         document
#   ----                     ------                                         --------
#   A/estimate-defect  #1    vehicle TG11LK3617, not TG11LK3607               header, top right
#   A/estimate-defect  #2    dated 08 Nov, two days before the incident      under "Estimate No."
#   A/estimate-defect  #3    "Tax at 18% ₹11,160.00" — 18% of 48,150 is 8,667  tax line, above total
#   A/estimate-defect  #4    total 59,310 vs 44,500 claimed                   bottom line
#   A/towing-defect    #5    towed to Sri Kalyan, estimate from Meghna        "Towed to" line
#   B/fir-defect       #6    TG13MX4477 — two digits transposed               vehicle field
#   B/fir-defect       #7    registered 09 Nov for a 04 Nov occurrence       "Date of report"
#   B/estimate-defect  #8    "Rear bumper assembly (OEM)" ₹12,000 twice       lines 1 and 4
#   B/estimate-defect  #9    dated 03 Nov, before the incident                under "Estimate No."
#   B/towing-defect    #10   dated 06 Nov — day after, and that is FINE      "Date"
#
# #10 is in the table on purpose. A checker that flags a next-day tow receipt is a checker that
# will be switched off within a week. The oracle run proves the engine stays silent on it.
PLANTED_DEFECTS = {
    "A/estimate-defect": ["VEHICLE_MISMATCH", "DATE_OUTSIDE_WINDOW",
                          "TAX_RATE_MISMATCH", "EXCEEDS_CLAIMED_AMOUNT"],
    "A/towing-defect": ["PROVIDER_MISMATCH"],
    "B/fir-defect": ["EXTRACTION_DISAGREES"],       # fires against the estimate's registration
    "B/estimate-defect": ["DUPLICATE_LINE", "DATE_OUTSIDE_WINDOW", "EXCEEDS_CLAIMED_AMOUNT"],
    "B/towing-defect": [],                          # the control: must stay silent
}
