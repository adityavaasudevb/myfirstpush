// xUnit tests for CheckEngine. The fixtures below encode what the generated PDFs actually print,
// so these tests are a regression harness for the demo documents as much as for the rules.
using InsuranceService.Application.Ai;
using InsuranceService.Domain.Constants;
using Xunit;

public class CheckEngineTests
{
    private static readonly DateTimeOffset LaneAIncident = new(2026, 11, 10, 5, 35, 0, TimeSpan.Zero); // 11:05 IST
    private static readonly DateTimeOffset LaneBIncident = new(2026, 11, 5, 4, 52, 0, TimeSpan.Zero);  // 10:22 IST

    // ---------------------------------------------------------------- helpers
    private static ExtractedLineItem L(string d, decimal qty, decimal amt) => new()
    {
        Description = d, Quantity = qty,
        UnitPrice = qty == 0 ? null : decimal.Round(amt / qty, 2),
        Amount = amt, Category = "charge", SourceText = d
    };

    private static ExtractedSubtotal S(string label, decimal amt) =>
        new() { Label = label, Amount = amt, SourceText = label };

    private static DocumentAudit Doc(string type, string file, ExtractedDocument e) => new()
    {
        DocumentId = Guid.NewGuid(), DocumentType = type, FileName = file, Status = AiStatuses.Completed, Extracted = e
    };

    private static ClaimAuditInput Claim(string number, string vehicle, string driver, string passenger,
        DateTimeOffset incident, decimal claimed, params DocumentAudit[] docs) => new()
    {
        ClaimId = Guid.NewGuid(), ClaimNumber = number, ClaimType = InsuranceClaimTypes.OwnVehicleDamage,
        VehicleNumber = vehicle, DriverName = driver, PassengerName = passenger,
        IncidentAtUtc = incident, ClaimedAmountInr = claimed, Documents = docs.ToList()
    };

    private static List<string> WarnCodes(ClaimAuditResult r) =>
        r.Findings.Where(f => f.Severity == AiFindingSeverities.Warn).Select(f => f.Code).ToList();

    // ================================================================ the demo documents
    [Fact]
    public void LaneA_CleanClaim_IsConsistent()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-2026-GFW103", "TG11LK3607", "Karthik Iyer", "Devi Priya",
            LaneAIncident, 71154.00m,
            Doc("FIR", "FIR-01-clean.pdf", new ExtractedDocument
            { DocumentKind = "Fir", DocumentDate = "2026-11-10", IssuerName = "Miyapur Police Station", VehicleRegistration = "TG11LK3607" }),
            Doc("RepairEstimate", "RepairEstimate-01-clean.pdf", new ExtractedDocument
            {
                DocumentKind = "RepairEstimate", IssuerName = "Meghna Auto Body Works",
                DocumentDate = "2026-11-10", VehicleRegistration = "TG11LK3607",
                LineItems = new()
                {
                    L("Door assembly — left (OEM)", 1, 24600), L("Mirror assembly — left", 1, 3950),
                    L("Side panel — load body", 1, 12200), L("Door lock and latch set", 1, 2350),
                    L("Dent and shape correction", 6, 5100), L("Refit and alignment of door", 4, 3400),
                    L("Paint booth — two panels", 6, 5400), L("Electrical refit", 2, 1500),
                    L("Shop supplies and disposal", 1, 1800)
                },
                SubtotalLines = new() { S("Parts subtotal", 43100), S("Labour subtotal", 15400) },
                TaxRates = new() { 18 }, TaxAmount = 10854, GrandTotal = 71154, AmountPaid = 71154
            }),
            Doc("Other", "TowingReceipt-01-clean.pdf", new ExtractedDocument
            {
                DocumentKind = "Other", IssuerName = "Miyapur Road Towing", DocumentDate = "2026-11-10",
                VehicleRegistration = "TG11LK3607", TowedTo = "Meghna Auto Body Works, Miyapur",
                LineItems = new() { L("Flatbed tow", 1, 1400), L("Door tie-down", 1, 350), L("Loading", 1, 250) },
                GrandTotal = 2000, AmountPaid = 2000
            })));

        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
        Assert.Empty(WarnCodes(r));
    }

    [Fact]
    public void LaneA_DefectiveClaim_IsInconsistent_WithThePlantedDefects()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-2026-GFW104", "TG11LK3607", "Prakash Menon", "Anita Salve",
            new DateTimeOffset(2026, 11, 10, 11, 10, 0, TimeSpan.Zero), 44500m,
            Doc("RepairEstimate", "RepairEstimate-02-defects.pdf", new ExtractedDocument
            {
                DocumentKind = "RepairEstimate", IssuerName = "Meghna Auto Body Works",
                DocumentDate = "2026-11-08",                 // planted: before the incident
                VehicleRegistration = "TG11LK3617",           // planted: wrong vehicle
                LineItems = new()
                {
                    L("Clutch plate assembly (OEM)", 1, 14800), L("Pressure plate", 1, 9600),
                    L("Brake drum — rear pair", 2, 9800), L("Gearbox removal and refit", 8, 6800),
                    L("Clutch replacement", 4, 3400), L("Brake overhaul", 3, 2550),
                    L("Shop supplies and disposal", 1, 1200)
                },
                SubtotalLines = new() { S("Parts subtotal", 34200), S("Labour subtotal", 12750) },
                TaxRates = new() { 18 }, TaxAmount = 11160,      // planted: 18% of 48,150 is 8,667
                GrandTotal = 59310
            }),
            Doc("Other", "TowingReceipt-02-defects.pdf", new ExtractedDocument
            {
                DocumentKind = "Other", IssuerName = "Miyapur Road Towing", DocumentDate = "2026-11-10",
                VehicleRegistration = "TG11LK3607", TowedTo = "Sri Kalyan Motors, Kukatpally",
                LineItems = new() { L("Flatbed tow", 1, 1400), L("Storage", 1, 600) },
                TaxRates = new() { 18 }, TaxAmount = 360, GrandTotal = 2360, AmountPaid = 2360
            })));

        Assert.Equal(AuditVerdicts.Inconsistent, r.Verdict);
        var warns = WarnCodes(r);
        Assert.Contains(AuditFindingCodes.VehicleMismatch, warns);
        Assert.Contains(AuditFindingCodes.DateOutsideWindow, warns);
        Assert.Contains(AuditFindingCodes.TaxRateMismatch, warns);
        Assert.Contains(AuditFindingCodes.ExceedsClaimedAmount, warns);
        Assert.Contains(AuditFindingCodes.ExtractionDisagrees, warns);
        Assert.Contains(r.Findings, f => f.Code == AuditFindingCodes.MissingExpectedDocument); // no FIR attached
    }

    [Fact]
    public void LaneB_CleanClaim_IsConsistent()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-B-A", "TG13MX4747", "Suresh Pillai", "Meera Chandran",
            LaneBIncident, 58327.40m,
            Doc("FIR", "FIR-01-clean.pdf", new ExtractedDocument
            { DocumentKind = "Fir", DocumentDate = "2026-11-05", VehicleRegistration = "TG13MX4747" }),
            Doc("RepairEstimate", "RepairEstimate-01-clean.pdf", new ExtractedDocument
            {
                DocumentKind = "RepairEstimate", IssuerName = "Sri Venkata Sai Motors",
                DocumentDate = "2026-11-05", VehicleRegistration = "TG13MX4747",
                LineItems = new()
                {
                    L("Front bumper assembly (OEM)", 1, 9600), L("Bonnet edge panel", 1, 7450),
                    L("Headlamp assembly — right", 1, 12400), L("Grille and clips", 1, 2410),
                    L("Bumper removal and refit", 4, 3120), L("Bonnet edge repair and paint", 7, 6230),
                    L("Headlamp alignment", 2, 1560), L("Paint booth — two panels", 5, 4660),
                    L("Shop supplies and disposal", 1, 2000)
                },
                SubtotalLines = new() { S("Parts subtotal", 31860), S("Labour subtotal", 15570) },
                TaxRates = new() { 18 }, TaxAmount = 8897.40m, GrandTotal = 58327.40m, AmountPaid = 58327.40m
            }),
            Doc("Other", "TowingReceipt-01-clean.pdf", new ExtractedDocument
            {
                DocumentKind = "Other", IssuerName = "Kukatpally Recovery Services", DocumentDate = "2026-11-05",
                VehicleRegistration = "TG13MX4747", TowedTo = "Sri Venkata Sai Motors, KPHB Colony",
                LineItems = new() { L("Flatbed tow", 1, 1200), L("Winch pull", 1, 400) },
                GrandTotal = 1600, AmountPaid = 1600
            })));

        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
        Assert.Empty(WarnCodes(r));
    }

    [Fact]
    public void LaneB_DefectiveClaim_CatchesTheDuplicateAndTheTransposedRegistration()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-B-B", "TG13MX4747", "Suresh Pillai", "Anil Kumar",
            new DateTimeOffset(2026, 11, 5, 11, 15, 0, TimeSpan.Zero), 52780m,
            Doc("FIR", "FIR-02-defects.pdf", new ExtractedDocument
            { DocumentKind = "Fir", DocumentDate = "2026-11-09", VehicleRegistration = "TG13MX4477" }),
            Doc("RepairEstimate", "RepairEstimate-02-defects.pdf", new ExtractedDocument
            {
                DocumentKind = "RepairEstimate", IssuerName = "Sri Venkata Sai Motors",
                DocumentDate = "2026-11-03", VehicleRegistration = "TG13MX4747",
                LineItems = new()
                {
                    L("Rear bumper assembly (OEM)", 1, 12000), L("Tailgate outer panel", 1, 8400),
                    L("Rear combination lamp — right", 1, 4300), L("Rear bumper assembly (OEM)", 1, 12000),
                    L("Bumper removal and refit", 3, 2400), L("Tailgate dent and paint", 8, 6800),
                    L("Paint booth — two panels", 2, 1600), L("Shop supplies and disposal", 1, 1500)
                },
                SubtotalLines = new() { S("Parts subtotal", 36700), S("Labour subtotal", 10800) },
                TaxRates = new() { 18 }, TaxAmount = 8820, GrandTotal = 57820
            }),
            Doc("Other", "TowingReceipt-02-defects.pdf", new ExtractedDocument
            {
                DocumentKind = "Other", IssuerName = "Kukatpally Recovery Services", DocumentDate = "2026-11-06",
                VehicleRegistration = "TG13MX4747", TowedTo = "Sri Venkata Sai Motors, KPHB Colony",
                LineItems = new() { L("Flatbed tow", 1, 1200), L("Storage", 1, 400) },
                TaxRates = new() { 18 }, TaxAmount = 288, GrandTotal = 1888, AmountPaid = 1888
            })));

        Assert.Equal(AuditVerdicts.Inconsistent, r.Verdict);
        var warns = WarnCodes(r);
        Assert.Contains(AuditFindingCodes.DuplicateLine, warns);
        Assert.Contains(AuditFindingCodes.VehicleMismatch, warns);
        Assert.Contains(AuditFindingCodes.DateOutsideWindow, warns);
        Assert.Contains(AuditFindingCodes.ExceedsClaimedAmount, warns);
        // the duplicate is named with its amount, which is the sentence the demo leans on
        Assert.Contains(r.Findings, f => f.Code == AuditFindingCodes.DuplicateLine && f.Message.Contains("12,000"));
    }

    // ================================================================ false-positive traps
    [Fact]
    public void UnreadableMoneyColumn_ProducesNoAccusation()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-BLUR", "TG13MX4747", "Suresh Pillai", "x", LaneBIncident, 58327.40m,
            Doc("RepairEstimate", "blurred.pdf", new ExtractedDocument
            {
                DocumentKind = "RepairEstimate", IssuerName = "Sri Venkata Sai Motors",
                DocumentDate = "2026-11-10", VehicleRegistration = "TG13MX4747", Confidence = "low"
            })));

        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
        Assert.Empty(WarnCodes(r));   // "not verifiable" must never become "wrong"
        Assert.Contains(r.Findings, f => f.Code == AuditFindingCodes.ExtractionIncomplete);
    }

    [Fact]
    public void TaxAlreadyInsideTheLines_SkipsTheIdentityInsteadOfFiring()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-INCL", "TG13MX4747", "Suresh Pillai", "x", LaneBIncident, 5782m,
            Doc("RentalInvoice", "rental.pdf", new ExtractedDocument
            {
                DocumentKind = "RentalInvoice", IssuerName = "DriveEasy Rentals", DocumentDate = "2026-11-06",
                VehicleRegistration = "TG13MX4747",
                LineItems = new() { L("Self-drive hatchback 2 days", 2, 4400), L("Delivery and pick-up", 1, 500) },
                SubtotalLines = new() { S("Subtotal", 4900) },
                TaxRates = new() { 18 }, TaxAmount = null, GrandTotal = 5782, AmountPaid = 5782
            })));

        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
    }

    [Fact]
    public void PassengerBill_IsNotTreatedAsTheWrongPatient()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-PAX", "TG11LK3607", "Karthik Iyer", "Devi Priya",
            LaneAIncident, 2700m,
            Doc("MedicalBill", "bill.pdf", new ExtractedDocument
            {
                DocumentKind = "MedicalBill", IssuerName = "Aadhya Multispeciality Hospital",
                DocumentDate = "2026-11-11", PatientName = "Devi Priya",
                AdmissionAt = "2026-11-10T14:30", DischargeAt = "2026-11-11T11:00",
                LineItems = new() { L("Consultation", 1, 900), L("Dressing", 2, 700), L("X-ray", 1, 1100) },
                SubtotalLines = new() { S("Total", 2700) }, GrandTotal = 2700, AmountPaid = 2700
            })));

        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
    }

    [Fact]
    public void AdmissionBeforeTheCrash_IsFlagged()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-EARLY", "TG11LK3607", "Karthik Iyer", "Devi Priya",
            LaneAIncident, 2700m,
            Doc("MedicalBill", "bill.pdf", new ExtractedDocument
            {
                DocumentKind = "MedicalBill", IssuerName = "Aadhya Multispeciality Hospital",
                DocumentDate = "2026-11-11", PatientName = "Karthik Iyer",
                AdmissionAt = "2026-11-09T20:10", DischargeAt = "2026-11-11T11:00",
                LineItems = new() { L("Consultation", 1, 900), L("Dressing", 2, 700), L("X-ray", 1, 1100) },
                SubtotalLines = new() { S("Total", 2700) }, GrandTotal = 2700, AmountPaid = 2700
            })));

        Assert.Equal(AuditVerdicts.NeedsReview, r.Verdict);
        Assert.Contains(AuditFindingCodes.AdmissionBeforeIncident, WarnCodes(r));
    }

    [Fact]
    public void OfflineRun_ReportsUnavailableWithoutInventingFindings()
    {
        var r = CheckEngine.Evaluate(Claim("CLM-OFFLINE", "TG13MX4747", "Suresh Pillai", "x", LaneBIncident, 58327.40m,
            new DocumentAudit { DocumentId = Guid.NewGuid(), DocumentType = "FIR", FileName = "f.pdf",
                Status = AiStatuses.Unavailable, Extracted = null, ErrorMessage = "no provider configured" }));

        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
        Assert.Empty(WarnCodes(r));
        Assert.All(r.Findings, f => Assert.Equal(AiFindingSeverities.Info, f.Severity));
    }

    // ================================================================ rule-level units
    [Theory]
    [InlineData("TS09AB4321", "ts09-ab-4321", true)]
    [InlineData("TG11LK3607", "TG11LK3617", false)]
    [InlineData("KA01AB1234", "KA01 AB 1234", true)]
    public void RegistrationComparisonIgnoresSpacingAndCase(string a, string b, bool same)
        => Assert.Equal(same, CheckEngine.SameRegistration(a, b));

    [Fact]
    public void VerdictThresholds_OneWarnIsNeedsReview_TwoIsInconsistent()
    {
        var one = new[] { new AuditFinding { Severity = AiFindingSeverities.Warn } };
        var two = new[] { new AuditFinding { Severity = AiFindingSeverities.Warn },
                          new AuditFinding { Severity = AiFindingSeverities.Warn } };
        var infos = new[] { new AuditFinding { Severity = AiFindingSeverities.Info },
                            new AuditFinding { Severity = AiFindingSeverities.Info } };

        Assert.Equal(AuditVerdicts.NeedsReview, CheckEngine.VerdictFor(one));
        Assert.Equal(AuditVerdicts.Inconsistent, CheckEngine.VerdictFor(two));
        Assert.Equal(AuditVerdicts.Consistent, CheckEngine.VerdictFor(infos));
    }

    // ================================================================ regressions from the eval run
    [Fact]
    public void DocumentNumbersAreNotCrossCompared_BecauseEachDocumentNumbersItself()
    {
        // The eval harness caught this: an FIR numbered "0218 / 2026" and an estimate numbered
        // "MAB/EST/2026/0418" are not in disagreement about anything. They are two different
        // documents, each with its own serial. This used to fire EXTRACTION_DISAGREES on every
        // clean claim and turn a Consistent verdict into NeedsReview.
        var claim = new ClaimAuditInput
        {
            ClaimId = Guid.NewGuid(), ClaimNumber = "CLM-T-1", ClaimType = "Own Vehicle Damage",
            VehicleNumber = "TG11LK3607", DriverName = "Karthik Iyer", PassengerName = "Devi Priya",
            IncidentAtUtc = LaneAIncident, ClaimedAmountInr = 71154m,
            Documents = new List<DocumentAudit>
            {
                new() { DocumentId = Guid.NewGuid(), DocumentType = "FIR", FileName = "fir.pdf",
                    Status = AiStatuses.Completed,
                    Extracted = new ExtractedDocument { DocumentKind = "Fir", DocumentNumber = "0218 / 2026",
                        DocumentDate = "2026-11-10", VehicleRegistration = "TG11LK3607", Confidence = "high" } },
                new() { DocumentId = Guid.NewGuid(), DocumentType = "RepairEstimate", FileName = "est.pdf",
                    Status = AiStatuses.Completed,
                    Extracted = new ExtractedDocument { DocumentKind = "RepairEstimate",
                        DocumentNumber = "MAB/EST/2026/0418", DocumentDate = "2026-11-10",
                        VehicleRegistration = "TG11LK3607", GrandTotal = 71154m, TaxAmount = 10854m,
                        TaxRates = new List<decimal> { 18m }, Confidence = "high",
                        LineItems = new List<ExtractedLineItem> { L("Door assembly", 1, 60300m) } } },
            }
        };

        var r = CheckEngine.Evaluate(claim);

        Assert.DoesNotContain(r.Findings, f => f.Code == AuditFindingCodes.ExtractionDisagrees);
        Assert.Equal(AuditVerdicts.Consistent, r.Verdict);
    }

    [Fact]
    public void TheSameRegistrationPrintedDifferentlyIsStillADisagreement()
    {
        // The narrowing above must not have removed the check that matters: two documents about
        // this crash that name two different vehicles.
        var claim = new ClaimAuditInput
        {
            ClaimId = Guid.NewGuid(), ClaimNumber = "CLM-T-2", ClaimType = "Own Vehicle Damage",
            VehicleNumber = "TG11LK3607", DriverName = "Karthik Iyer", PassengerName = "Devi Priya",
            IncidentAtUtc = LaneAIncident, ClaimedAmountInr = 71154m,
            Documents = new List<DocumentAudit>
            {
                new() { DocumentId = Guid.NewGuid(), DocumentType = "FIR", FileName = "fir.pdf",
                    Status = AiStatuses.Completed,
                    Extracted = new ExtractedDocument { DocumentKind = "Fir", DocumentDate = "2026-11-10",
                        VehicleRegistration = "TG11LK3607", Confidence = "high" } },
                new() { DocumentId = Guid.NewGuid(), DocumentType = "Other", FileName = "tow.pdf",
                    Status = AiStatuses.Completed,
                    Extracted = new ExtractedDocument { DocumentKind = "Other", DocumentDate = "2026-11-10",
                        VehicleRegistration = "TG11LK3617", GrandTotal = 2000m, Confidence = "high",
                        LineItems = new List<ExtractedLineItem> { L("Tow", 1, 2000m) } } },
            }
        };

        var r = CheckEngine.Evaluate(claim);

        Assert.Contains(r.Findings, f => f.Code == AuditFindingCodes.ExtractionDisagrees);
    }
}
