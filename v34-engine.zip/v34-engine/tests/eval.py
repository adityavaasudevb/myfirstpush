#!/usr/bin/env python3
"""
Eval harness for the v3.4 integrity check.

Three modes:
  oracle     no model. We hand the engine the extraction a perfect reader would produce, built
             from the ground truth of each generated PDF. This isolates the RULES: anything it
             misses is a rules bug, not a model bug.
  recorded   replays extractions captured from a live run (recorded/*.json). Deterministic, free,
             and the mode to run in CI or on stage.
  vertex     live calls. Needs ADC + a project id. Costs a couple of rupees.

What it prints: per-document field recall/precision, finding precision/recall, and whether the
verdict per claim is right. Ground truth lives in ground_truth.py, written from the same values
that generated the PDFs — so this measures the pipeline, not the author's optimism.

Usage:
    python3 eval.py --provider oracle
    python3 eval.py --provider recorded
    python3 eval.py --provider vertex --project my-proj --model gemini-3.8-flash
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import textwrap

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from ground_truth import CLAIMS, DOCUMENTS, PLANTED_DEFECTS  # noqa: E402


# --------------------------------------------------------------------------- engine bridge
ENGINE_DIR = os.path.join(HERE, "engine-runner")          # a tiny console app that calls CheckEngine
DLL = os.path.join(ENGINE_DIR, "bin", "Debug", "net8.0", "Runner.dll")


def ensure_runner():
    """Build the C# runner once. It compiles the engine files straight out of ../src."""
    if os.path.exists(DLL):
        return DLL

    dotnet = os.environ.get("DOTNET", "dotnet")
    print("• building the check-engine runner (first run only)…", file=sys.stderr)
    proc = subprocess.run([dotnet, "build", "-v", "q", "--nologo"], cwd=ENGINE_DIR,
                          capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stdout[-3000:], proc.stderr[-3000:], file=sys.stderr)
        raise SystemExit("could not build the engine runner — is the .NET 8 SDK on PATH?")
    return DLL


def run_engine(payload: dict) -> dict:
    """Send one claim (claim facts + per-document extractions) to CheckEngine, get the result."""
    dll = ensure_runner()
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as f:
        json.dump(payload, f)
        path = f.name
    try:
        proc = subprocess.run([os.environ.get("DOTNET", "dotnet"), dll, path],
                              capture_output=True, text=True)
        if proc.returncode != 0:
            raise SystemExit(f"engine failed:\n{proc.stdout}\n{proc.stderr}")
        return json.loads(proc.stdout)
    finally:
        os.unlink(path)


# --------------------------------------------------------------------------- extraction sources
def oracle_extraction(doc_key: str) -> dict:
    """The extraction a perfect reader produces: the ground-truth values, plus quotes taken from
    the PDF text so the reviewer-facing fields are realistic."""
    return DOCUMENTS[doc_key]["truth"]


def recorded_extraction(doc_key: str) -> dict | None:
    p = os.path.join(HERE, "recorded", doc_key.replace("/", "__") + ".json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def vertex_extraction(doc_key: str, model: str) -> dict:
    """Live call. Kept deliberately thin: this is the same request the C# provider makes."""
    import base64
    import urllib.request

    d = DOCUMENTS[doc_key]
    with open(doc_path(d), "rb") as f:
        b64 = base64.b64encode(f.read()).decode()

    token = subprocess.run(["gcloud", "auth", "application-default", "print-access-token"],
                           capture_output=True, text=True, check=True).stdout.strip()
    url = (f"https://aiplatform.googleapis.com/v1/projects/{PROJECT}/locations/global/"
           f"publishers/google/models/{model}:generateContent")
    body = {
        "contents": [{"role": "user", "parts": [
            {"text": d["prompt_context"]},
            {"inlineData": {"mimeType": "application/pdf", "data": b64}},
        ]}],
        "generationConfig": {"temperature": 0, "responseMimeType": "application/json",
                             "maxOutputTokens": 1500},
    }
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers={"Authorization": f"Bearer {token}",
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        payload = json.load(r)
    text = payload["candidates"][0]["content"]["parts"][0]["text"]
    return json.loads(text)


# --------------------------------------------------------------------------- scoring
def field_score(extraction: dict, truth: dict) -> tuple[int, int, int]:
    """(correct, returned, expected) across the fields we claim to extract."""
    watched = ["documentKind", "issuerName", "documentNumber", "documentDate", "customerName",
               "vehicleRegistration", "discountAmount", "taxAmount", "grandTotal", "amountPaid",
               "patientName", "admissionAt", "dischargeAt"]
    correct = returned = expected = 0
    for k in watched:
        tv = truth.get(k)
        if tv is not None:
            expected += 1
        ev = extraction.get(k)
        if ev is not None:
            returned += 1
            if tv is not None and _same(ev, tv):
                correct += 1
    # line items: compare as multiset of (normalised description, amount)
    tl = truth.get("lineItems") or []
    el = extraction.get("lineItems") or []
    expected += len(tl)
    returned += len(el)
    pool = [(li["description"].strip().lower(), round(float(li["amount"]), 2)) for li in tl]
    for li in el:
        key = (str(li.get("description", "")).strip().lower(), round(float(li.get("amount", 0)), 2))
        if key in pool:
            correct += 1
            pool.remove(key)
    return correct, returned, expected


def _same(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) < 0.51
    return str(a).strip().lower() == str(b).strip().lower()


def score(extractions: dict, mode: str) -> dict:
    claims_out = []
    fields_c = fields_r = fields_e = 0

    for claim in CLAIMS:
        docs = []
        for doc_key in claim["documents"]:
            ex = extractions.get(doc_key)
            docs.append({
                "documentId": doc_key, "documentType": DOCUMENTS[doc_key]["type"],
                "fileName": os.path.basename(DOCUMENTS[doc_key]["path"]),
                "status": "Completed" if ex else "Unavailable",
                "extracted": ex,
                "errorMessage": None if ex else "not recorded",
            })
            if ex:
                c, r, e = field_score(ex, DOCUMENTS[doc_key]["truth"])
                fields_c += c; fields_r += r; fields_e += e

        payload = {
            "claimId": claim["key"], "claimNumber": claim["number"],
            "claimType": claim["claimType"], "vehicleNumber": claim["vehicle"],
            "driverName": claim["driver"], "passengerName": claim["passenger"],
            "incidentAtUtc": claim["incidentUtc"], "claimedAmountInr": claim["claimed"],
            "documents": docs,
        }
        result = run_engine(payload)
        expected_codes = set(claim["expectedCodes"])
        got_codes = {f["code"] for f in result["findings"] if f["severity"] == "Warn"}
        claims_out.append({
            "claim": claim["number"],
            "verdict": result["verdict"],
            "expectedVerdict": claim["expectedVerdict"],
            "hit": got_codes & expected_codes,
            "missed": expected_codes - got_codes,
            "spurious": got_codes - expected_codes,
            "findings": result["findings"],
        })

    hit = sum(len(c["hit"]) for c in claims_out)
    missed = sum(len(c["missed"]) for c in claims_out)
    spurious = sum(len(c["spurious"]) for c in claims_out)
    verdicts_ok = sum(1 for c in claims_out if c["verdict"] == c["expectedVerdict"])

    return {
        "mode": mode,
        "fields": (fields_c, fields_r, fields_e),
        "findings": (hit, hit + spurious, hit + missed),   # correct, raised, expected
        "claims": claims_out,
        "verdicts": (verdicts_ok, len(claims_out)),
    }


# --------------------------------------------------------------------------- reporting
def report(s: dict):
    c, r, e = s["fields"]
    fp, raised, expected = s["findings"]
    recall = 100 * fp / expected if expected else 100
    precision = 100 * fp / raised if raised else 100
    field_recall = 100 * c / e if e else 0
    field_precision = 100 * c / r if r else 0

    print(f"\n{'='*78}")
    print(f"  mode: {s['mode']}")
    print(f"{'='*78}")
    print(f"  fields    correct {c:3d} / expected {e:3d}   recall {field_recall:5.1f}%"
          f"   precision {field_precision:5.1f}%")
    print(f"  findings  correct {fp:3d} / expected {expected:3d}   recall {recall:5.1f}%"
          f"   precision {precision:5.1f}%")
    vok, vt = s["verdicts"]
    print(f"  verdicts  {vok}/{vt} claims correct\n")

    for cl in s["claims"]:
        mark = "OK " if cl["verdict"] == cl["expectedVerdict"] and not cl["missed"] else "!! "
        print(f"  {mark}{cl['claim']:<18} {cl['verdict']:<13} (expected {cl['expectedVerdict']})")
        for f in cl["findings"]:
            if f["severity"] == "Warn":
                print(f"       · {f['code']:<28} {textwrap.shorten(f['message'], 86)}")
        if cl["missed"]:
            print(f"       MISSED: {', '.join(sorted(cl['missed']))}")
        if cl["spurious"]:
            print(f"       SPURIOUS: {', '.join(sorted(cl['spurious']))}")

    ok = (vok == vt and not any(c["missed"] or c["spurious"] for c in s["claims"]))
    print(f"\n  RESULT: {'ALL CLAIMS CORRECT' if ok else 'MISMATCHES ABOVE'}\n")
    return ok


def html_report(s: dict, path: str):
    rows = []
    for cl in s["claims"]:
        fs = "".join(
            f"<li><b>{f['code']}</b> — {f['message']}"
            + (f"<br><code>{f['documentValue']}</code>" if f.get("documentValue") else "")
            + "</li>" for f in cl["findings"] if f["severity"] == "Warn")
        rows.append(f"""<tr><td>{cl['claim']}</td>
            <td class="{'ok' if cl['verdict']==cl['expectedVerdict'] else 'bad'}">{cl['verdict']}</td>
            <td>{cl['expectedVerdict']}</td><td><ul>{fs or '<li class="muted">no warnings</li>'}</ul></td></tr>""")

    c, r, e = s["fields"]; fp, raised, expected = s["findings"]
    plants = "".join(
        f"<tr><td><code>{k}</code></td><td>{', '.join(v) or '<span class=muted>none — control</span>'}</td></tr>"
        for k, v in PLANTED_DEFECTS.items())

    html = f"""<!doctype html><meta charset="utf-8"><title>v3.4 integrity eval</title>
<style>
 body{{font:15px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;margin:40px;color:#111;max-width:1100px}}
 h1{{font-size:20px;margin:0 0 4px}} .sub{{color:#666;margin-bottom:24px}}
 table{{border-collapse:collapse;width:100%;margin:16px 0}}
 th,td{{text-align:left;padding:10px 12px;border-bottom:1px solid #e5e7eb;vertical-align:top}}
 th{{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#6b7280}}
 .ok{{color:#047857;font-weight:600}} .bad{{color:#b91c1c;font-weight:600}}
 ul{{margin:0;padding-left:18px}} li{{margin:3px 0}} code{{background:#f3f4f6;padding:1px 5px;border-radius:3px}}
 .muted{{color:#9ca3af}} .kpi{{display:flex;gap:28px;margin:20px 0 8px}}
 .kpi div{{background:#f9fafb;border:1px solid #eef0f3;border-radius:8px;padding:14px 18px}}
 .kpi b{{display:block;font-size:22px}} .kpi span{{font-size:12px;color:#6b7280;text-transform:uppercase}}
</style>
<h1>Claim integrity check — evaluation</h1>
<div class="sub">mode <b>{s['mode']}</b> · {len(s['claims'])} claims · generated by eval.py</div>
<div class="kpi">
 <div><span>field recall</span><b>{100*c/e if e else 0:.1f}%</b></div>
 <div><span>finding recall</span><b>{100*fp/expected if expected else 0:.1f}%</b></div>
 <div><span>finding precision</span><b>{100*fp/raised if raised else 0:.1f}%</b></div>
 <div><span>verdicts</span><b>{s['verdicts'][0]}/{s['verdicts'][1]}</b></div>
</div>
<table><tr><th>Claim</th><th>Verdict</th><th>Expected</th><th>Warnings raised</th></tr>
{''.join(rows)}</table>
<h2 style="font-size:15px;margin:30px 0 6px">Where each planted defect is</h2>
<p class="sub" style="margin:0 0 10px">Every defect the eval expects is visible on the PDF. Open the
document named here and the plant is on the line described — the engine is not detecting things that
are not there.</p>
<table><tr><th>Document</th><th>Expected code</th></tr>{plants}</table>
<p class="sub" style="margin-top:18px">One row above is a control, not a defect: the next-day tow
receipt in Lane B. It stays silent on purpose.</p>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"  wrote {path}")


# --------------------------------------------------------------------------- main
PROJECT = None

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", choices=["oracle", "recorded", "vertex"], default="oracle")
    ap.add_argument("--project", default=os.environ.get("GOOGLE_CLOUD_PROJECT"))
    ap.add_argument("--model", default="gemini-3.8-flash")
    ap.add_argument("--html", default=os.path.join(HERE, "eval-report.html"))
    args = ap.parse_args()
    PROJECT = args.project

    ex = {}
    rec_dir = os.path.join(HERE, "recorded")
    for key in DOCUMENTS:
        if args.provider == "oracle":
            ex[key] = oracle_extraction(key)
        elif args.provider == "recorded":
            got = recorded_extraction(key)
            if got is not None:
                ex[key] = got
        else:
            if not PROJECT:
                raise SystemExit("--project (or GOOGLE_CLOUD_PROJECT) is required for vertex mode")
            ex[key] = vertex_extraction(key, args.model)
            os.makedirs(rec_dir, exist_ok=True)
            with open(os.path.join(rec_dir, key.replace("/", "__") + ".json"), "w",
                      encoding="utf-8") as f:
                json.dump(ex[key], f, indent=2, ensure_ascii=False)

    s = score(ex, args.provider)
    ok = report(s)
    html_report(s, args.html)
    sys.exit(0 if ok else 1)
