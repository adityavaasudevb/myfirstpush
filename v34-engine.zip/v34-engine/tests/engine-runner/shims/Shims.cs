// Stand-ins for members that already exist in the solution's v3.3 InsuranceConstants.cs.
// Only the eval runner compiles this file — it never ships.
namespace InsuranceService.Domain.Constants;

public static class InsuranceClaimTypes
{
    public const string ThirdPartyLiability = "Third-Party Liability";
    public const string OwnVehicleDamage = "Own Vehicle Damage";
    public const string UninsuredMotorist = "Uninsured Motorist";
    public const string MedicalExpense = "Medical Expense";
    public const string RentalCar = "Rental Car";
}

public static class ClaimStatuses
{
    public const string Submitted = "Submitted";
    public const string AwaitingSurveyorPickup = "AwaitingSurveyorPickup";
    public const string UnderInvestigation = "UnderInvestigation";
    public const string SurveyorReportSubmitted = "SurveyorReportSubmitted";
    public const string Paid = "Paid";
    public const string Rejected = "Rejected";
}
