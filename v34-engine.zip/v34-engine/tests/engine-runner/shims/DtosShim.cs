// Empty namespace so CheckEngine.cs's `using InsuranceService.Application.Dtos;` resolves
// outside the solution. In the real project this namespace holds the DTOs.
namespace InsuranceService.Application.Dtos;

internal static class NamespaceMarker { }
