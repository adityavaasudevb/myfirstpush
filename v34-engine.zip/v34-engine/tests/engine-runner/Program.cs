// Eval bridge: reads a claim payload from a JSON file, runs CheckEngine, prints the result.
// Deliberately dumb — it exists so eval.py exercises the SAME compiled rules the service ships,
// not a Python reimplementation that could drift.
using System.Text.Json;
using System.Text.Json.Serialization;
using InsuranceService.Application.Ai;

var options = new JsonSerializerOptions
{
    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    PropertyNameCaseInsensitive = true,
    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
};

if (args.Length == 0)
{
    Console.Error.WriteLine("usage: Runner <payload.json>");
    return 2;
}

var input = JsonSerializer.Deserialize<Payload>(File.ReadAllText(args[0]), options);
if (input is null)
{
    Console.Error.WriteLine("could not parse payload");
    return 2;
}

var claim = new ClaimAuditInput
{
    ClaimId = Guid.TryParse(input.ClaimId, out var g) ? g : Guid.NewGuid(),
    ClaimNumber = input.ClaimNumber ?? "CLM-UNKNOWN",
    ClaimType = input.ClaimType ?? "",
    VehicleNumber = input.VehicleNumber ?? "",
    DriverName = input.DriverName ?? "",
    PassengerName = input.PassengerName ?? "",
    IncidentAtUtc = DateTimeOffset.Parse(input.IncidentAtUtc ?? "2026-01-01T00:00:00+00:00"),
    ClaimedAmountInr = input.ClaimedAmountInr,
    Documents = (input.Documents ?? new()).Select(d => new DocumentAudit
    {
        DocumentId = Guid.TryParse(d.DocumentId, out var dg) ? dg : Guid.NewGuid(),
        DocumentType = d.DocumentType ?? "",
        FileName = d.FileName ?? "",
        Status = d.Status ?? "Completed",
        Extracted = d.Extracted,
        ErrorMessage = d.ErrorMessage
    }).ToList()
};

var result = CheckEngine.Evaluate(claim);

Console.WriteLine(JsonSerializer.Serialize(new
{
    result.Verdict,
    result.Summary,
    findings = result.Findings.Select(f => new
    {
        f.Code, f.Severity, f.Message, f.ClaimValue, f.DocumentValue, f.Evidence,
        documentId = f.DocumentId?.ToString()
    })
}, options));

return 0;

record Payload(
    string? ClaimId, string? ClaimNumber, string? ClaimType, string? VehicleNumber,
    string? DriverName, string? PassengerName, string? IncidentAtUtc, decimal ClaimedAmountInr,
    List<DocPayload>? Documents);

record DocPayload(string? DocumentId, string? DocumentType, string? FileName, string? Status,
    ExtractedDocument? Extracted, string? ErrorMessage);
