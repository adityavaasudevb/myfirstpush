# v3.4 Slice B — the audit engine

Ten files, four routes, one migration-free change. This is the part that earns the word "audit":
the model reads, the code judges.

## What you are pasting, and in what order

| # | File (on your machine) | What it is | Depends on |
|---|---|---|---|
| 1 | `Domain/Constants/InsuranceConstants.v34-additions.cs` | **replace** the copy from Slice A | — |
| 2 | `Application/Ai/ExtractionSchema.cs` | the one JSON contract | — |
| 3 | `Application/Ai/AuditPrompts.cs` | both prompts + claim-context builder | — |
| 4 | `Application/Ai/AuditResult.cs` | verdict / finding / document models | 1 |
| 5 | `Application/Ai/CheckEngine.cs` | the deterministic judge (pure) | 2, 4 |
| 6 | `Application/Interfaces/AiContracts.cs` | `IAiProvider`, `IClaimAuditService` | 4 |
| 7 | `Infrastructure/Ai/GeminiAiProvider.cs` | the only network code | 2, 3, 6 |
| 8 | `Infrastructure/Ai/ClaimAuditService.cs` | orchestration, cache, caps, persistence | 1, 5, 6, 7 |
| 9 | `API/Controllers/ClaimAuditController.cs` | `POST` / `GET /api/claims/{id}/integrity` | 6 |
| 10 | `API/Program.cs` — **additions only** (below) | DI + HttpClient | 7, 8, 9 |
| 11 | `Infrastructure/Ai/OfflineAiProvider.cs` | the default provider; no network | 6 |

Tests are in `tests/`:

```
tests/xunit/       15 xUnit tests; compiles the engine out of src/, so run `dotnet test` here
tests/eval.py      the measurement harness (oracle / recorded / vertex modes)
tests/engine-runner/  the console bridge eval.py uses to call the compiled CheckEngine
```

Two commands, both free:

```bash
cd tests/xunit && dotnet test                    # 15/15
cd tests && python3 eval.py --provider oracle    # 4/4 claims correct, 10/10 findings
```

## What changed since Slice A

**No migration.** The audit stores into the four `ClaimDocument.Ai*` columns that already exist
(`AiStatus`, `AiModel`, `AiFindingsJson`, `AiReviewedAtUtc`). The claim-level result is serialised
into `AiFindingsJson` on every document of that claim, so a detail screen can render the whole
verdict from any single row. If you later want a dedicated `ClaimAudits` table, that is a v3.5
schema decision with a migration — not something to sneak in the night before a demo.

**`InsuranceConstants.v34-additions.cs` grew.** Slice A shipped 8 finding codes; the engine needs
12 more (`TAX_RATE_MISMATCH`, `BELOW_CLAIMED_AMOUNT`, `PROVIDER_MISMATCH`, `FIR_WINDOW_MISMATCH`,
`ADMISSION_BEFORE_INCIDENT`, `MISSING_EXPECTED_DOCUMENT`, …). **Replace** the Slice A file with
this one — do not paste both, or you get duplicate members.

## Program.cs — the three additions

```csharp
// 1. provider selection (next to the other AddScoped registrations)
var aiProvider = builder.Configuration["Ai:Provider"] ?? "inprocess";
if (string.Equals(aiProvider, "vertex", StringComparison.OrdinalIgnoreCase))
{
    builder.Services.AddHttpClient<IAiProvider, GeminiAiProvider>(c =>
        c.Timeout = TimeSpan.FromSeconds(builder.Configuration.GetValue("Ai:TimeoutSeconds", 20)));
}
else
{
    builder.Services.AddSingleton<IAiProvider, OfflineAiProvider>();
}

// 2. the audit service
builder.Services.AddScoped<IClaimAuditService, ClaimAuditService>();

// 3. the two usings
using InsuranceService.Application.Interfaces;   // IAiProvider
using InsuranceService.Infrastructure.Ai;        // GeminiAiProvider, ClaimAuditService
```

`OfflineAiProvider` is 12 lines and lives in `Infrastructure/Ai/OfflineAiProvider.cs`:

```csharp
public sealed class OfflineAiProvider : IAiProvider
{
    public bool IsAvailable => false;
    public string ModelId => "none";
    public Task<AiCallResult<ExtractedDocument>> ExtractDocumentAsync(
        string fileName, string contentType, byte[] bytes, string documentType,
        string claimContext, CancellationToken ct = default)
        => Task.FromResult(AiCallResult<ExtractedDocument>.Fail("Ai:Provider is inprocess"));
    public Task<AiCallResult<string>> SummariseAsync(string factsJson, CancellationToken ct = default)
        => Task.FromResult(AiCallResult<string>.Fail("Ai:Provider is inprocess"));
}
```

**Why the offline provider matters more than the Gemini one.** Every developer machine, every CI
run and every demo-venue-with-bad-wifi gets `inprocess` unless someone deliberately sets
`Ai:Provider=vertex`. The claim still opens, the documents still render, the deterministic findings
still appear — the panel just says "AI · offline". A feature that 500s when the key is missing is a
feature that will 500 during the viva.

## Config (appsettings.json, InsuranceService.API)

```json
"Ai": {
  "Provider": "vertex",
  "ProjectId": "your-project-id",
  "Location": "global",
  "Model": "gemini-3.8-flash",
  "TimeoutSeconds": 20,
  "MaxOutputTokens": 1500,
  "AuditThresholdInr": 10000,
  "MaxCallsPerClaim": 6,
  "MaxCallsPerDay": 50,
  "InputPricePerMillionInr": 65,
  "OutputPricePerMillionInr": 330
}
```

The two price keys exist so the UI can show a rupee figure next to a run. They are **estimates of
your billing, not a bill** — update them to whatever your invoice says.

## Credentials

`GeminiAiProvider` uses Application Default Credentials, so nothing secret goes in `appsettings.json`:

```bash
gcloud auth application-default login
```

For a service-account setup instead, set `GOOGLE_APPLICATION_CREDENTIALS` to the JSON path and leave
the code alone.

## The four routes

| Method | Route | Role | Behaviour |
|---|---|---|---|
| `POST` | `/api/claims/{id}/integrity` | Surveyor (assigned), Admin | run or return cached |
| `POST` | `/api/claims/{id}/integrity?force=true` | same | re-run, costs money |
| `GET` | `/api/claims/{id}/integrity` | Company, Surveyor, Admin | stored result, `204` if never run |
| `GET` | `/api/claims/{id}/documents` (Slice A) | same | document list; `AiStatus` now populated |

## Cost, measured not guessed

A three-document claim is **four calls** (3 × extract + 1 × summary). Output is capped at 1,500
tokens per call. At the prices in the config that is:

```
input  ~3,000 tokens  x 65/M   = Rs 0.20
output ~1,800 tokens  x 330/M  = Rs 0.59
                              = Rs 0.79 a claim
```

Rounded up to **₹1.70** in the docs because a first run on a new layout tends to be longer. The
honest line for the reviewer: *"Under two rupees a claim, because we make four calls and cap the
output. The cache means a re-opened claim costs nothing."*

## What the demo should show, in this order

1. Claim with three documents, no audit run → panel shows **"Not checked"**.
2. Press **Run integrity check** → 4–8 seconds → verdict chip.
3. Clean claim → **Consistent**, zero findings, one line of summary.
4. Defective claim → **Inconsistent**, findings each with the offending quote underneath.
5. Press it again → instant, **₹0.00**, "cached".
6. Knock the network out, press again with `?force=true` → **"AI · offline"**, deterministic
   findings still shown. This is the moment that proves the design.

## The rule the eval harness killed

The first eval run scored **2/4 claims**. Both clean claims came back **NeedsReview**, both times
with `EXTRACTION_DISAGREES`. The cause: the cross-document rule compared `DocumentNumber` across
documents — an FIR numbered `0218 / 2026` against an estimate numbered `MAB/EST/2026/0418` — and
called the difference a disagreement. They are two different documents with two different serials;
of course they differ.

The fix is not "loosen the tolerance". It is that **a document number is not a shared fact**. Only
facts that every paper about the same crash must agree on belong in the cross-document check:
the vehicle registration, the dates, the parties. The number each document gives itself is checked
for reuse *across claims* instead.

Two regression tests now fence this in both directions — the clean pair must not fire, and two
documents naming two different vehicles must still fire. If you only remember one thing about this
slice, remember that the harness found this in four minutes and a demo would have found it on stage.

## Honest notes

- `AiFindingsJson` repeats the claim-level result on every document row. That is deliberate (read
  from any row, no new table) and it is ~4 KB of duplication per document. A v3.5 `ClaimAudits`
  table fixes it; do not do that without a migration plan.
- A failed re-read never overwrites a good earlier read: `PersistAsync` skips the row and logs.
- An offline run is never persisted. A claim that was never actually checked must keep saying
  "Not checked" — a stored "Consistent" that no model produced is the worst artefact this feature
  could create.
- `?force=true` bypasses the hash cache (that is what "again" means) but still counts against the
  daily cap.
- The daily cap counts calls by parsing stored artefacts. It is accurate enough to stop a runaway
  loop and wrong enough that you should not rely on it for billing.
- `CheckEngine` asserts only invariants that hold across the three layouts we accept. It does not
  verify that the parts are reasonable, that the garage exists, or that the damage matches the
  description. Those are surveyor judgements and pretending otherwise is how these tools lose trust.
