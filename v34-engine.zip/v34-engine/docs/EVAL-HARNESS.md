# Eval harness — measuring the answer to "how accurate is this without your own CNN?"

The reviewer question is never answered by an adjective. It is answered by a table with a
denominator. This harness produces that table, and it can be re-run in under a minute.

## What it measures

For each of the 11 synthetic documents, we know the ground truth because we generated them:

| | Meaning |
|---|---|
| **Field-level recall** | of the fields the document actually prints, how many did extraction recover |
| **Field-level precision** | of the fields extraction returned, how many were correct |
| **Finding precision** | of the findings the engine raised, how many correspond to a planted defect |
| **Finding recall** | of the planted defects, how many did the engine raise |
| **Verdict accuracy** | does the claim get the verdict its document set deserves |

Held-out: none of these documents was used to tune the prompt beyond the three layouts we had to
support. Say that out loud — it is the difference between an evaluation and a demo.

## Three modes

```bash
cd v34-engine/tests

# 1. Deterministic only: no model. Hands the engine the extraction a perfect reader produces,
#    which is the number to quote for the rules engine in isolation. This is the mode that runs.
python3 eval.py --provider oracle

# 2. Live: sends each PDF to the model once. ~Rs 2 for all 11. Needs ADC + a project id.
python3 eval.py --provider vertex --project <your-project> --model gemini-3.8-flash

# 3. Recorded: replays extractions captured from a live run. Free, deterministic, CI-safe.
#    Populate recorded/ by running mode 2 and keeping its output (the harness prints where).
python3 eval.py --provider recorded
```

Set `DOTNET=/path/to/dotnet` if the SDK is not on `PATH`. The harness builds
`tests/engine-runner` on first use and compiles the engine straight out of `../src`, so it can never
score a stale copy of the rules.

`oracle` is the honest split: it feeds the engine the extraction a perfect reader would produce.
When that scores 100 %, any shortfall in `vertex` mode is the model's, not the rules'.

## The eleven documents and what each is for

| Document | Type | Planted | Expected engine response |
|---|---|---|---|
| FIR-01-clean (A) | FIR | — | no findings |
| RepairEstimate-01-clean (A) | estimate | — | no findings |
| TowingReceipt-01-clean (A) | towing | — | no findings |
| RepairEstimate-02-defects (A) | estimate | wrong vehicle, dated before incident, tax at 23.18 % printed as 18 %, total above claim | 4 warns |
| TowingReceipt-02-defects (A) | towing | different workshop than the estimate | 1 info |
| FIR-01-clean (B) | FIR | — | no findings |
| RepairEstimate-01-clean (B) | estimate | — | no findings |
| TowingReceipt-01-clean (B) | towing | — | no findings |
| FIR-02-defects (B) | FIR | registration transposed, occurrence a day early, no-delay claim | 1 warn (cross-doc) |
| RepairEstimate-02-defects (B) | estimate | duplicate line, dated before incident, total above claim | 3 warns |
| TowingReceipt-02-defects (B) | towing | dated a day after the incident | 0 (legitimate) |

Two documents in the set are deliberately *not* defects even though they look odd: a towing
receipt the day after an incident is normal, and the pharmacy invoice has no patient name at all
(it is a counter sale). A checker that flags either of those is worse than no checker.

## What the run prints

```
mode: oracle
fields    correct 121 / expected 121   recall 100.0%   precision 100.0%
findings  correct  10 / expected  10   recall 100.0%   precision 100.0%
verdicts  4/4 claims correct
RESULT: ALL CLAIMS CORRECT
```

That is the measured result on the eleven documents, today. Quote it as *"the rules reproduce every
planted defect and stay silent on the two controls"*, not as an accuracy claim about the model —
mode `vertex` is the one that measures the model, and it has not been run here.

## The first run scored 2/4, and that is the point

The clean claims came back `NeedsReview` because a cross-document rule compared document numbers
across different document types. The harness found it; the fix is described in `README-V34-B.md`.
An evaluation that has never failed is a demonstration.

Run it before the demo, print it, and put it in the appendix. The moment a reviewer asks "and how
do you know", the answer is a command they can run themselves.

## Known limits to state before anyone else finds them

- **Handwritten bills are out of scope.** Not "poorly supported" — out of scope. Ten of eleven
  demo documents are digitally generated PDFs; the eleventh is a phone photograph of a printed
  pharmacy invoice, which is the realistic upper bound of what we claim.
- **A flatbed scan misreads digits.** 8 → 3, 5 → 6. The recomputation catches most of these because
  the total stops reconciling, which converts a silent misread into a visible finding.
- **The model never decides.** If extraction returns a wrong number that happens to reconcile with
  every other wrong number on the page, no rule will catch it and no rule should pretend to.
  That is what the surveyor's signature is for.
