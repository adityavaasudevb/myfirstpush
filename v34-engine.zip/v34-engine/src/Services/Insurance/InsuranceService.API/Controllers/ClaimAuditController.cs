// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.API/Controllers/ClaimAuditController.cs
using System.Security.Claims;
using InsuranceService.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceService.API.Controllers;

/// <summary>
/// v3.4 — the audit endpoints. Two routes, both nested under the claim so the gateway's
/// /api/claims/{**rest} rule forwards them without a new route (same reason the documents
/// controller is nested).
///
/// Deliberately NOT part of ClaimsController: the audit is a separate capability with its own
/// service, its own caps and its own failure modes. Mixing it into ClaimsController would make
/// that class the place where two unrelated lifecycles meet.
/// </summary>
[ApiController]
[Route("api/claims/{claimId:guid}/integrity")]
[Authorize]
public class ClaimAuditController : ControllerBase
{
    private readonly IClaimAuditService _audit;
    public ClaimAuditController(IClaimAuditService audit) => _audit = audit;

    private string CallerId =>
        User.FindFirstValue("sub") ?? throw new UnauthorizedAccessException("Missing sub claim.");
    private string CallerRole => User.FindFirst("role")?.Value ?? string.Empty;

    /// <summary>
    /// v3.4 — run the check. Surveyor (assigned) and Admin. The Company does not run it: the
    /// audit is part of the investigation, and letting the claimant trigger spend is wrong even
    /// when it is only ₹1.70.
    ///
    /// 200 with the stored result when nothing changed; ?force=true re-runs and costs money.
    /// 409 when the claim is already decided or has no evidence; 403 when not assigned.
    /// </summary>
    [HttpPost]
    [Authorize(Roles = "Surveyor,Admin")]
    public async Task<IActionResult> Run(Guid claimId, [FromQuery] bool force, CancellationToken ct)
        => Ok(await _audit.AuditAsync(claimId, CallerId, CallerRole, force, ct));

    /// <summary>
    /// The stored result, or 204 when the audit has never run. Every role that may see the claim
    /// may see its audit — 204 is what the UI renders as "not checked yet".
    /// </summary>
    [HttpGet]
    [Authorize(Roles = "Company,Surveyor,Admin")]
    public async Task<IActionResult> Get(Guid claimId, CancellationToken ct)
    {
        var result = await _audit.GetStoredAsync(claimId, CallerId, CallerRole, ct);
        return result is null ? NoContent() : Ok(result);
    }
}
