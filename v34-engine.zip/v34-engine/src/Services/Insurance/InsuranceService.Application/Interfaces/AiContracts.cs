// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Interfaces/AiContracts.cs
using InsuranceService.Application.Ai;

namespace InsuranceService.Application.Interfaces;

/// <summary>
/// v3.4 — the two things the audit needs from the outside world. Both are interfaces so the
/// whole feature can be exercised with no network: AiProvider.None is the deterministic path
/// and the eval harness uses FakeAiProvider to replay recorded extractions.
/// </summary>
public interface IAiProvider
{
    /// <summary>True when a real model will be called. False for the in-process/offline provider.</summary>
    bool IsAvailable { get; }

    string ModelId { get; }

    /// <summary>
    /// ONE call per document. Returns the extraction, or null plus a reason when the model could
    /// not be reached — never throws for provider failures, because a claim must still be
    /// reviewable when the network is down.
    /// </summary>
    Task<AiCallResult<ExtractedDocument>> ExtractDocumentAsync(
        string fileName, string contentType, byte[] bytes,
        string documentType, string claimContext, CancellationToken ct = default);

    /// <summary>ONE call per claim: two neutral sentences from the checker's facts.</summary>
    Task<AiCallResult<string>> SummariseAsync(
        string factsJson, CancellationToken ct = default);
}

public sealed class AiCallResult<T>
{
    public T? Value { get; init; }
    public bool Succeeded => Value is not null && Error is null;
    public string? Error { get; init; }
    public long PromptTokens { get; init; }
    public long OutputTokens { get; init; }
    public long DurationMs { get; init; }

    public static AiCallResult<T> Ok(T value, long prompt, long output, long ms) =>
        new() { Value = value, PromptTokens = prompt, OutputTokens = output, DurationMs = ms };

    public static AiCallResult<T> Fail(string error, long ms = 0) =>
        new() { Error = error, DurationMs = ms };
}

/// <summary>
/// The claim-integrity audit. Runs the whole pipeline for one claim, enforces the caps, caches by
/// document hash, and records everything the UI needs. Registered scoped.
/// </summary>
public interface IClaimAuditService
{
    /// <summary>
    /// Audit one claim. Idempotent: a second call with unchanged documents and a Completed
    /// AiStatus returns the stored result without spending a token.
    /// force = true re-runs even when cached (the "run it again" button, costs money).
    /// </summary>
    Task<ClaimAuditResult> AuditAsync(
        Guid claimId, string callerUserId, string callerRole, bool force = false,
        CancellationToken ct = default);

    /// <summary>The stored result for a claim, or null when it has never been run.</summary>
    Task<ClaimAuditResult?> GetStoredAsync(
        Guid claimId, string callerUserId, string callerRole, CancellationToken ct = default);
}

public static class AiProviderNames
{
    /// <summary>No network. Deterministic checks still run; the UI says "AI · offline".</summary>
    public const string InProcess = "inprocess";
    /// <summary>Live Gemini through Vertex AI using the machine's ADC.</summary>
    public const string Vertex = "vertex";
    /// <summary>Replays recorded extractions — used by the eval harness and tests only.</summary>
    public const string Fake = "fake";
}
