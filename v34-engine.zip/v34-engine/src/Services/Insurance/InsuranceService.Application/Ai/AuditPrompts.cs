// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Ai/AuditPrompts.cs
namespace InsuranceService.Application.Ai;

/// <summary>
/// v3.4 — the two prompts. Both are deliberately short: output tokens dominate the bill
/// (₹3.75 per million vs ₹0.75 for input on gemini-3.8-flash), and a long prompt that "coaches"
/// the model also makes its answers harder to compare across documents.
///
/// Division of labour: THE MODEL READS, THE CODE JUDGES.
/// The model is never asked whether anything is wrong. It is asked what the paper says.
/// </summary>
public static class AuditPrompts
{
    /// <summary>System instruction for the single extraction call. One call per document.</summary>
    public const string ExtractionSystem =
        """
        You extract fields from Indian insurance claim documents. Return JSON only, matching the
        provided schema exactly.

        Rules:
        1. Transcribe, do not interpret. If a value is not printed on the document, omit it — never
           infer, never calculate, never carry a number over from another field.
        2. Every field ending in "Quote" must contain the verbatim text you read the value from,
           copied character for character. Do not translate, tidy or abbreviate it.
        3. Amounts: the numbers as printed, in rupees, digits only. Indian digit grouping
           (1,23,456.78) must be converted to a plain number. Do not deduct, add or round.
        4. lineItems is every printed charge, in printed order, from EVERY table and every
           free-standing row. A charge printed outside the itemised tables — "Shop supplies and
           disposal", "Loading assistance", a delivery fee — is still a charge and must be a row.
           Rows that are a subtotal, a discount, a tax line or a grand total go in lineItems too,
           with category subtotal / discount / tax / total, so the caller can tell a charge from a total.
        5. Dates: ISO yyyy-MM-dd. Keep the printed time in admissionAt / dischargeAt as
           yyyy-MM-ddTHH:mm when a time is shown.
        6. documentKind is RepairEstimate for a garage quotation, MedicalBill for a hospital or
           pharmacy bill, RentalInvoice for a vehicle rental invoice, Fir for a police report.
        7. If the page is a scan or photograph with no text layer, read it as an image and set
           readAsImage true.
        8. If a field is illegible or absent, leave it out and say so in notes. Do not guess.
        9. confidence is your own: high when every money field was read cleanly from legible text,
           medium when some values needed image reading, low when any money value was ambiguous.
        """;

    /// <summary>
    /// One user turn per document: the document type we expected, plus the claim facts the
    /// document is supposed to be about. Passing the claim facts is what lets the model notice
    /// it is looking at the wrong vehicle — but note the checker still decides, because the model
    /// is told the facts only as CONTEXT, not as a target to agree with.
    /// </summary>
    public static string ExtractionUser(string expectedKind, string claimContext) =>
        $"""
         Expected document type: {expectedKind}.
         Claim under review (context only — extract what the document SAYS, even where it disagrees):
         {claimContext}

         Extract this document into the schema.
         """;

    /// <summary>
    /// The single claim-level narrative call. Input: the compact factual summary the checker
    /// produced (never the raw documents). Output: two sentences a human reads before the findings
    /// table. It is NOT permitted to change a verdict — the verdict is computed in C#.
    /// </summary>
    public const string VerdictSystem =
        """
        You write a two-sentence neutral summary of an evidence check for an insurance surveyor
        in India. You are given structured facts extracted from documents and the deterministic
        checks that already ran.

        Rules:
        - Do not decide anything. Do not use the words fraud, fraudulent or dishonest.
        - Do not invent facts that are not in the input.
        - Sentence 1: what the documents agree on. Sentence 2: what does not reconcile, named
          concretely (amounts, dates, registration numbers).
        - If everything reconciles, sentence 2 says so plainly.
        - Maximum 60 words total. No markdown, no lists, no preamble.
        """;

    /// <summary>
    /// Keeps the per-document prompt honest about what the claim actually asserts. Only the
    /// fields a document could contradict — deliberately excludes the description and anything
    /// the model might try to "improve".
    /// </summary>
    public static string ClaimContext(
        string claimNumber, string claimType, string vehicleNumber, string driverName,
        DateTimeOffset incidentAtUtc, decimal claimedAmountInr) =>
        $"Claim {claimNumber} ({claimType}); vehicle {vehicleNumber}; driver {driverName}; " +
        $"incident {incidentAtUtc:yyyy-MM-dd HH:mm} UTC; amount claimed INR {claimedAmountInr:0.##}.";
}
