// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Ai/AuditResult.cs
using System.Text.Json.Serialization;
using InsuranceService.Domain.Constants;

namespace InsuranceService.Application.Ai;

/// <summary>
/// v3.4 — what the audit returns for one claim, and what gets serialised into
/// ClaimDocument.AiFindingsJson on each document plus the claim-level summary.
/// The verdict is ALWAYS computed here in C#; the model's only contribution to it is the
/// extraction (and one optional narrative sentence).
/// </summary>
public sealed class ClaimAuditResult
{
    public string SchemaVersion { get; set; } = ExtractionSchemaVersion.Current;
    public Guid ClaimId { get; set; }
    public string ClaimNumber { get; set; } = string.Empty;

    /// <summary>Consistent | NeedsReview | Inconsistent. Never a score, never a percentage.</summary>
    public string Verdict { get; set; } = AuditVerdicts.NeedsReview;

    /// <summary>Two neutral sentences. Written by the model, or by CheckEngine when offline.</summary>
    public string Summary { get; set; } = string.Empty;

    public List<AuditFinding> Findings { get; set; } = new();
    public List<DocumentAudit> Documents { get; set; } = new();

    // ---- cost / operational facts, surfaced in the UI footer -----------------
    public string? Model { get; set; }
    public bool Offline { get; set; }                 // true when no provider ran
    public int ModelCallsMade { get; set; }
    public long PromptTokens { get; set; }
    public long OutputTokens { get; set; }
    public decimal EstimatedCostInr { get; set; }
    public long DurationMs { get; set; }
    public DateTimeOffset GeneratedAtUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class DocumentAudit
{
    public Guid DocumentId { get; set; }
    public string DocumentType { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    /// <summary>Completed | Failed | Unavailable — mirrors AiStatuses.</summary>
    public string Status { get; set; } = "Completed";
    public ExtractedDocument? Extracted { get; set; }
    public List<AuditFinding> Findings { get; set; } = new();
    public string? ErrorMessage { get; set; }
}

/// <summary>
/// One finding. `Code` is stable and testable; `Message` is the sentence a surveyor reads.
/// Severity: Warn moves the verdict, Info never does.
/// </summary>
public sealed class AuditFinding
{
    public string Code { get; set; } = string.Empty;
    public string Severity { get; set; } = AiFindingSeverities.Warn;

    /// <summary>Which document produced it — null when the finding is cross-document.</summary>
    public Guid? DocumentId { get; set; }

    public string Message { get; set; } = string.Empty;

    /// <summary>What the claim says, what the document says, both as strings so the UI can
    /// render any pair (a date, a rupee amount, a registration number) without special cases.</summary>
    public string? ClaimValue { get; set; }
    public string? DocumentValue { get; set; }

    /// <summary>The exact text on the page this finding rests on. Empty for cross-document ones.</summary>
    public string? Evidence { get; set; }
}

/// <summary>
/// Deterministic check codes. Deliberately a superset of the eight codes shipped in
/// InsuranceConstants.v34-additions.cs — the new ones are added there in the same paste.
/// Nothing here is model-generated; every code has a unit test in CheckEngineTests.
/// </summary>
public static class AuditFindingCodes
{
    // money
    public const string ArithmeticMismatch     = "ARITHMETIC_MISMATCH";      // lines -> subtotal -> total
    public const string DuplicateLine          = "DUPLICATE_LINE";
    public const string TaxRateMismatch        = "TAX_RATE_MISMATCH";        // printed tax != rate x base
    public const string ExceedsClaimedAmount   = "EXCEEDS_CLAIMED_AMOUNT";
    public const string BelowClaimedAmount     = "BELOW_CLAIMED_AMOUNT";     // claimed > document, Info
    public const string BalanceNotSettled      = "BALANCE_NOT_SETTLED";      // printed balance > 0, Info

    // identity
    public const string VehicleMismatch        = "VEHICLE_MISMATCH";
    public const string PatientNameMismatch    = "PATIENT_NAME_MISMATCH";
    public const string DocumentNumberReused   = "DOCUMENT_NUMBER_REUSED";   // same invoice no. on 2 claims

    // time
    public const string DateOutsideWindow      = "DATE_OUTSIDE_WINDOW";      // document dated before incident
    public const string DocumentAfterIncident  = "DOCUMENT_AFTER_INCIDENT";  // towed/settled before it happened
    public const string FirWindowMismatch      = "FIR_WINDOW_MISMATCH";      // incident outside FIR occurrence
    public const string AdmissionBeforeIncident= "ADMISSION_BEFORE_INCIDENT";
    public const string LateRegistration       = "LATE_REGISTRATION";        // FIR filed days later, "no delay"

    // completeness / content
    public const string MissingExpectedDocument= "MISSING_EXPECTED_DOCUMENT";
    public const string NonMedicalItem         = "NON_MEDICAL_ITEM";
    public const string DescriptionNotInClaim  = "DESCRIPTION_NOT_IN_CLAIM";
    public const string ProviderMismatch       = "PROVIDER_MISMATCH";        // towed to X, estimate from Y
    public const string ExtractionIncomplete   = "EXTRACTION_INCOMPLETE";     // a money field was null
    public const string ExtractionDisagrees    = "EXTRACTION_DISAGREES";      // 2 docs, same fact, different value
}

public static class AuditVerdicts
{
    public const string Consistent = "Consistent";
    public const string NeedsReview = "NeedsReview";
    public const string Inconsistent = "Inconsistent";
}
