// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Ai/ExtractionSchema.cs
using System.Text.Json.Serialization;

namespace InsuranceService.Application.Ai;

/// <summary>
/// v3.4 — the ONE contract every document is mapped into, whatever it looks like.
///
/// Why a fixed schema: the three money documents we accept (garage estimate, hospital bill,
/// pharmacy invoice) share no layout, no column order, no tax convention and often not even
/// the same set of columns between two garages in the same city. Asking a model to "check this
/// invoice" gives an answer that changes shape per document and cannot be tested. Asking it to
/// FILL THIS RECORD gives us something a unit test can assert on.
///
/// Rules baked into the shape:
///  * Every field is nullable. A field the model cannot find is null — never guessed, never "".
///  * Every nullable field has a twin `...Quote`: the verbatim text it was read from. The UI shows
///    the quote beside the value so a surveyor can see the read, not trust it.
///  * Nothing here is computed. Line amounts are what is PRINTED. The C# check engine recomputes
///    every total from the lines; if the printed total disagrees, that is a finding, not a parse error.
/// </summary>
public sealed class ExtractedDocument
{
    /// <summary>Set by us before the call, echoed back so a mixed-up response can be rejected.</summary>
    public string SchemaVersion { get; set; } = ExtractionSchemaVersion.Current;

    // ---- identity of the document -------------------------------------------
    public string? DocumentKind { get; set; }        // RepairEstimate | MedicalBill | RentalInvoice | Fir | Other
    public string? IssuerName { get; set; }          // garage / hospital / pharmacy / rental company
    public string? IssuerQuote { get; set; }
    public string? DocumentNumber { get; set; }      // estimate no. / bill no. / invoice no.
    public string? DocumentNumberQuote { get; set; }

    /// <summary>Printed date, ISO yyyy-MM-dd. Null when the document has no date or it is illegible.</summary>
    public string? DocumentDate { get; set; }
    public string? DocumentDateQuote { get; set; }

    // ---- the parties --------------------------------------------------------
    public string? CustomerName { get; set; }        // the party being billed (company or patient)
    public string? CustomerNameQuote { get; set; }
    public string? VehicleRegistration { get; set; } // normalised: upper case, no spaces or hyphens
    public string? VehicleRegistrationQuote { get; set; }

    /// <summary>Where a towing/recovery document says the vehicle was taken. Separate field so the
    /// cross-document "towed to X but estimated by Y" check never parses free text.</summary>
    public string? TowedTo { get; set; }
    public string? TowedToQuote { get; set; }

    // ---- money --------------------------------------------------------------
    /// <summary>Every printed line item, in printed order. Do not merge, do not total.</summary>
    public List<ExtractedLineItem>? LineItems { get; set; }

    /// <summary>The printed subtotal(s). A Vyapar hospital bill prints two section subtotals; an
    /// estimate prints parts and labour separately. All of them go here, labelled.</summary>
    public List<ExtractedSubtotal>? SubtotalLines { get; set; }

    public decimal? DiscountAmount { get; set; }
    public string? DiscountQuote { get; set; }
    public decimal? TaxAmount { get; set; }          // total tax printed anywhere on the document
    public string? TaxQuote { get; set; }
    /// <summary>Printed tax rate(s) as they appear, e.g. 18, 6, or [6,6] for CGST+SGST.</summary>
    public List<decimal>? TaxRates { get; set; }
    public decimal? GrandTotal { get; set; }
    public string? GrandTotalQuote { get; set; }
    public decimal? AmountPaid { get; set; }
    public string? AmountPaidQuote { get; set; }

    // ---- medical-only facts -------------------------------------------------
    public string? PatientName { get; set; }
    public string? PatientNameQuote { get; set; }
    /// <summary>ISO date-time, local as printed. Admission/discharge are how a medical bill is
    /// tied to the incident: a bill cannot be admitted before the crash.</summary>
    public string? AdmissionAt { get; set; }
    public string? AdmissionAtQuote { get; set; }
    public string? DischargeAt { get; set; }
    public string? DischargeAtQuote { get; set; }

    // ---- quality signals ----------------------------------------------------
    /// <summary>True when the model had to read an image because there was no text layer.</summary>
    public bool ReadAsImage { get; set; }
    /// <summary>Model's own confidence that the money fields are right: "high" | "medium" | "low".
    /// Used for the UI badge only; no rule depends on it.</summary>
    public string? Confidence { get; set; }

    /// <summary>Anything the model saw that the schema has no home for. Shown, never parsed.</summary>
    public string? Notes { get; set; }

    // ---- helpers (not serialised) -------------------------------------------
    [JsonIgnore]
    public bool HasMoney => GrandTotal is not null || (LineItems?.Count > 0);
}

/// <summary>One printed line. `Category` is the ONLY field the model interprets rather than reads:
/// it lets the checker know that a "Line total" row is a subtotal, not a charge — the single
/// biggest source of false ARITHMETIC_MISMATCH findings when a document is read naively.</summary>
public sealed class ExtractedLineItem
{
    public string? Description { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? UnitPrice { get; set; }
    /// <summary>Amount as PRINTED for this line. Null if the document does not print one.</summary>
    public decimal? Amount { get; set; }
    /// <summary>GST % printed ON this line, if the layout carries it per line (pharmacy, Vyapar).</summary>
    public decimal? TaxRate { get; set; }
    /// <summary>charge | subtotal | discount | tax | total | other</summary>
    public string? Category { get; set; }
    public string? SourceText { get; set; }          // the raw line, for the reviewer
}

/// <summary>A subtotal that is printed but is not a charge (parts subtotal, professional fees subtotal).</summary>
public sealed class ExtractedSubtotal
{
    public string? Label { get; set; }
    public decimal? Amount { get; set; }
    public string? SourceText { get; set; }
}

public static class ExtractionSchemaVersion
{
    public const string Current = "1.0";

    /// <summary>
    /// The JSON Schema sent to the model. Kept as a string literal rather than a generated
    /// schema so the prompt and the contract can be read side by side in review.
    /// ResponseMimeType application/json + this schema is what makes the model return
    /// parseable output; do NOT rely on prompting alone.
    /// </summary>
    public const string Json =
    """
    {
      "type": "object",
      "properties": {
        "schemaVersion":   { "type": "string" },
        "documentKind":    { "type": "string", "enum": ["RepairEstimate","MedicalBill","RentalInvoice","Fir","Other"] },
        "issuerName":      { "type": "string" },
        "issuerQuote":     { "type": "string" },
        "documentNumber":  { "type": "string" },
        "documentNumberQuote": { "type": "string" },
        "documentDate":    { "type": "string", "description": "ISO yyyy-MM-dd, as printed on the document" },
        "documentDateQuote": { "type": "string" },
        "customerName":    { "type": "string" },
        "customerNameQuote": { "type": "string" },
        "vehicleRegistration": { "type": "string", "description": "uppercase, no spaces or hyphens" },
        "vehicleRegistrationQuote": { "type": "string" },
        "towedTo":         { "type": "string", "description": "destination the vehicle was towed to, as printed" },
        "towedToQuote":    { "type": "string" },
        "lineItems": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "description": { "type": "string" },
              "quantity":    { "type": "number" },
              "unitPrice":   { "type": "number" },
              "amount":      { "type": "number", "description": "as printed on this line" },
              "taxRate":     { "type": "number" },
              "category":    { "type": "string", "enum": ["charge","subtotal","discount","tax","total","other"] },
              "sourceText":  { "type": "string" }
            },
            "required": ["description","category","sourceText"]
          }
        },
        "subtotalLines": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": { "label": {"type":"string"}, "amount": {"type":"number"}, "sourceText": {"type":"string"} },
            "required": ["label","amount"]
          }
        },
        "discountAmount":  { "type": "number" },
        "discountQuote":   { "type": "string" },
        "taxAmount":       { "type": "number" },
        "taxQuote":        { "type": "string" },
        "taxRates":        { "type": "array", "items": { "type": "number" } },
        "grandTotal":      { "type": "number" },
        "grandTotalQuote": { "type": "string" },
        "amountPaid":      { "type": "number" },
        "amountPaidQuote": { "type": "string" },
        "patientName":     { "type": "string" },
        "patientNameQuote":{ "type": "string" },
        "admissionAt":     { "type": "string" },
        "admissionAtQuote":{ "type": "string" },
        "dischargeAt":     { "type": "string" },
        "dischargeAtQuote":{ "type": "string" },
        "readAsImage":     { "type": "boolean" },
        "confidence":      { "type": "string", "enum": ["high","medium","low"] },
        "notes":           { "type": "string" }
      },
      "required": ["schemaVersion","documentKind","confidence"]
    }
    """;
}
