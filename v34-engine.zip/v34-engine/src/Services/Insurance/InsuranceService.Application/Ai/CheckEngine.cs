// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Ai/CheckEngine.cs
using InsuranceService.Application.Dtos;
using InsuranceService.Domain.Constants;

namespace InsuranceService.Application.Ai;

/// <summary>
/// v3.4 — THE JUDGE. Pure, deterministic, no I/O, no model, no clock beyond what is passed in.
///
/// Every rule here answers one question: does this document, as printed, reconcile with itself
/// and with the claim? A rule either fires with a quotable piece of evidence or stays silent.
/// There is no scoring and no confidence — three findings is three findings.
///
/// Design constraints that shaped this file:
///  * Amounts are recomputed from the printed lines. The model never returns a total we trust.
///  * A field it could not read is null, and null means "not verifiable" — never "mismatch".
///    Saying a document is wrong because a scan was blurry is the one unforgivable failure here.
///  * Tolerances are explicit and in rupees (see MoneyTolerance), because Indian invoices round
///    in three different places (per line, per section, at the foot).
/// </summary>
public static class CheckEngine
{
    /// <summary>Rounding allowance when comparing two printed rupee figures. 1 rupee covers
    /// per-line rounding on bills with dozens of small GST lines; anything larger is a real gap.</summary>
    public const decimal MoneyTolerance = 1.00m;

    /// <summary>Relative allowance on a tax-rate check, so 18% of 48,150 (8,667) is not "wrong"
    /// against a printed 8,667.00 by a paisa.</summary>
    private const decimal TaxToleranceRatio = 0.01m;

    /// <summary>An FIR filed more than this many days after the occurrence, while claiming no
    /// delay, is worth a surveyor's attention. Section 3 uses 7 for late intimation.</summary>
    private const int LateFirDays = 2;

    public static ClaimAuditResult Evaluate(ClaimAuditInput input)
    {
        var result = new ClaimAuditResult
        {
            ClaimId = input.ClaimId,
            ClaimNumber = input.ClaimNumber,
            Findings = new(),
            Documents = input.Documents.Select(d => new DocumentAudit
            {
                DocumentId = d.DocumentId,
                DocumentType = d.DocumentType,
                FileName = d.FileName,
                Status = d.Status,
                Extracted = d.Extracted,
                ErrorMessage = d.ErrorMessage
            }).ToList()
        };

        foreach (var doc in result.Documents)
        {
            var findings = new List<AuditFinding>();

            if (doc.Extracted is null)
            {
                // No extraction at all (network, quota, unreadable). This is not a claim defect.
                findings.Add(new AuditFinding
                {
                    Code = AuditFindingCodes.ExtractionIncomplete,
                    Severity = AiFindingSeverities.Info,
                    DocumentId = doc.DocumentId,
                    Message = doc.Status == AiStatuses.Unavailable
                        ? "The model was unavailable, so this document was not read. Nothing was checked against it."
                        : $"This document could not be read ({doc.ErrorMessage ?? "no output"}). Nothing was checked against it."
                });
            }
            else
            {
                findings.AddRange(CheckDocument(doc.Extracted, doc.DocumentId, input));
            }

            doc.Findings = findings;
            result.Findings.AddRange(findings);
        }

        result.Findings.AddRange(CheckCrossDocument(input, result.Documents));
        result.Findings.AddRange(CheckCompleteness(input));

        result.Verdict = VerdictFor(result.Findings);
        return result;
    }

    // ========================================================================
    //  Per-document checks
    // ========================================================================
    private static IEnumerable<AuditFinding> CheckDocument(
        ExtractedDocument d, Guid documentId, ClaimAuditInput claim)
    {
        // ---- identity -------------------------------------------------------
        if (IsPresent(d.VehicleRegistration) &&
            !SameRegistration(d.VehicleRegistration!, claim.VehicleNumber))
        {
            yield return Warn(AuditFindingCodes.VehicleMismatch, documentId,
                $"The document is for vehicle {d.VehicleRegistration}, but the claim is for {claim.VehicleNumber}.",
                claim.VehicleNumber, d.VehicleRegistration, d.VehicleRegistrationQuote);
        }

        if (IsPresent(d.PatientName) && IsPresent(claim.DriverName) &&
            !SamePerson(d.PatientName!, claim.DriverName!) &&
            !SamePerson(d.PatientName!, claim.PassengerName))
        {
            yield return Info(AuditFindingCodes.PatientNameMismatch, documentId,
                $"The bill names {d.PatientName} as the patient; the claim is in the name of {claim.DriverName}.",
                claim.DriverName, d.PatientName, d.PatientNameQuote);
        }

        // ---- time -----------------------------------------------------------
        var docDate = ParseDate(d.DocumentDate);
        if (docDate is not null)
        {
            var incidentDate = DateOnly.FromDateTime(claim.IncidentAtUtc.UtcDateTime);

            if (docDate.Value < incidentDate)
            {
                yield return Warn(AuditFindingCodes.DateOutsideWindow, documentId,
                    $"The document is dated {docDate:dd MMM yyyy}, before the incident on {incidentDate:dd MMM yyyy}.",
                    incidentDate.ToString("dd MMM yyyy"), docDate.Value.ToString("dd MMM yyyy"), d.DocumentDateQuote);
            }
            else if (docDate.Value > DateOnly.FromDateTime(DateTime.UtcNow.AddDays(1)))
            {
                yield return Info(AuditFindingCodes.DocumentAfterIncident, documentId,
                    $"The document is dated {docDate:dd MMM yyyy}, in the future.",
                    null, docDate.Value.ToString("dd MMM yyyy"), d.DocumentDateQuote);
            }
        }

        // A hospital admission that predates the crash is the cleanest impossible fact on a
        // medical bill: you were not admitted for an accident that had not happened yet.
        var admitted = ParseDateTime(d.AdmissionAt);
        if (admitted is not null && admitted.Value < claim.IncidentAtUtc.AddHours(-1))
        {
            yield return Warn(AuditFindingCodes.AdmissionBeforeIncident, documentId,
                $"The patient was admitted {Fmt(admitted.Value)} UTC, before the incident at {Fmt(claim.IncidentAtUtc)} UTC.",
                Fmt(claim.IncidentAtUtc), Fmt(admitted.Value), d.AdmissionAtQuote);
        }

        // ---- money ----------------------------------------------------------
        foreach (var f in CheckArithmetic(d, documentId))
            yield return f;

        foreach (var f in CheckDuplicateLines(d, documentId))
            yield return f;

        // The claim-amount comparisons belong to the money document only. A ₹2,000 towing
        // receipt is not "less than the claim" — it is a component of it.
        var isMoneyDocument = d.DocumentKind is ClaimDocumentTypes.RepairEstimate
                              or ClaimDocumentTypes.MedicalBill or ClaimDocumentTypes.RentalInvoice;

        if (isMoneyDocument && d.GrandTotal is { } total)
        {
            if (total > claim.ClaimedAmountInr + MoneyTolerance)
            {
                yield return Warn(AuditFindingCodes.ExceedsClaimedAmount, documentId,
                    $"The document totals {Money(total)}, above the {Money(claim.ClaimedAmountInr)} claimed.",
                    Money(claim.ClaimedAmountInr), Money(total), d.GrandTotalQuote);
            }
            // Claiming MORE than the paperwork supports is the more interesting direction, but
            // only warn when the gap is material — a claim rounded up by a rupee is normal.
            else if (total < claim.ClaimedAmountInr - MoneyTolerance)
            {
                var gap = claim.ClaimedAmountInr - total;
                if (gap > Math.Max(100m, claim.ClaimedAmountInr * 0.02m))
                {
                    yield return Warn(AuditFindingCodes.BelowClaimedAmount, documentId,
                        $"The claim asks for {Money(claim.ClaimedAmountInr)} but the documents support only {Money(total)}.",
                        Money(claim.ClaimedAmountInr), Money(total), d.GrandTotalQuote);
                }
            }
        }

        // ---- content --------------------------------------------------------
        if (d.DocumentKind == ClaimDocumentTypes.MedicalBill && d.LineItems is { Count: > 0 })
        {
            var nonMedical = d.LineItems
                .Where(l => !string.IsNullOrWhiteSpace(l.Description))
                .Where(l => Mentions(l.Description!, "towing", "tow ", "flatbed", "recovery", "body shop",
                                     "repair", "paint", "spare", "bumper", "garage"))
                .ToList();
            foreach (var l in nonMedical)
            {
                yield return Warn(AuditFindingCodes.NonMedicalItem, documentId,
                    $"A medical bill contains a non-medical line: \"{Trim(l.Description!)}\".",
                    null, l.Description, l.SourceText ?? l.Description);
            }
        }

        // A money document with nothing readable in it cannot support a payout, and we say so
        // rather than silently passing it. An FIR legitimately carries no money, so it is exempt.
        if (isMoneyDocument && !d.HasMoney)
        {
            yield return Info(AuditFindingCodes.ExtractionIncomplete, documentId,
                "No line items or total could be read from this document.",
                null, null, null);
        }
    }

    // ------------------------------------------------------------------------
    //  Arithmetic: lines -> subtotals -> tax -> total
    //  Written against the three layouts we actually accept:
    //    estimation : parts subtotal + labour subtotal + supplies  (+/- discount) + tax = total
    //    Vyapar     : two section subtotals, per-line GST included, one discount, final/paid/balance
    //    pharmacy   : per-line MRP + CGST + SGST, taxable column, total, discount at foot
    //  We assert only invariants that hold in all three.
    // ------------------------------------------------------------------------
    private static IEnumerable<AuditFinding> CheckArithmetic(ExtractedDocument d, Guid documentId)
    {
        var lines = d.LineItems?.Where(l => l.Amount is not null).ToList() ?? new();
        if (lines.Count == 0) yield break;

        // (1) every charge line: qty x price must equal the printed amount, when both are printed.
        foreach (var l in lines.Where(l => l.Category is null or "charge"))
        {
            if (l.Quantity is { } q && l.UnitPrice is { } up && l.Amount is { } amt && q > 0 && up > 0)
            {
                var expected = q * up;
                if (Math.Abs(expected - amt) > MoneyTolerance)
                {
                    yield return Warn(AuditFindingCodes.ArithmeticMismatch, documentId,
                        $"Line \"{Trim(l.Description ?? "item")}\": {q:0.##} x {Money(up)} = {Money(expected)}, but the line shows {Money(amt)}.",
                        null, Money(amt), l.SourceText ?? l.Description);
                }
            }
        }

        // (2) charges -> the single printed subtotal, when there is exactly one.
        //     With two or more section subtotals we cannot know which lines belong to which
        //     section without layout knowledge, so we do not guess — the grand-total identity
        //     in (3) still catches a document that does not add up.
        var charges = lines.Where(l => l.Category is null or "charge").Sum(l => l.Amount!.Value);
        if (d.SubtotalLines is { Count: 1 } oneSubtotal && oneSubtotal[0].Amount is { } printedSubtotal)
        {
            if (Math.Abs(printedSubtotal - charges) > MoneyTolerance)
            {
                yield return Warn(AuditFindingCodes.ArithmeticMismatch, documentId,
                    $"The printed subtotal is {Money(printedSubtotal)}, but the lines add to {Money(charges)} ({Money(charges - printedSubtotal)} apart).",
                    null, Money(printedSubtotal), QuoteOf(oneSubtotal));
            }
        }

        // (3) subtotal - discount + tax = grand total.
        if (d.GrandTotal is { } grand)
        {
            var baseAmount = charges;
            var expected = baseAmount - (d.DiscountAmount ?? 0m) + (d.TaxAmount ?? 0m);

            // Skip when the layout bakes tax into the lines and prints no separate tax row:
            // in that case tax is null and the identity above is simply not asserted.
            var taxIsSeparate = d.TaxAmount is null;
            if (!taxIsSeparate && Math.Abs(expected - grand) > MoneyTolerance)
            {
                yield return Warn(AuditFindingCodes.ArithmeticMismatch, documentId,
                    $"{Money(baseAmount)} {(d.DiscountAmount is { } dz ? $"- {Money(dz)} " : "")}+ {Money(d.TaxAmount ?? 0m)} tax = {Money(expected)}, but the document totals {Money(grand)}.",
                    null, Money(grand), d.GrandTotalQuote);
            }
        }

        // (4) printed tax vs printed rate. This is the one a human never does by hand and the
        //     reason an inflated tax line survives an office review.
        if (d.TaxAmount is { } tax && tax > 0 && d.TaxRates is { Count: > 0 } rates)
        {
            var baseAmount = charges;
            if (baseAmount > 0)
            {
                var rate = rates.Sum(); // CGST 9 + SGST 9 = 18
                var expected = baseAmount * rate / 100m;
                var allowed = Math.Max(MoneyTolerance, expected * TaxToleranceRatio);
                if (Math.Abs(expected - tax) > allowed)
                {
                    yield return Warn(AuditFindingCodes.TaxRateMismatch, documentId,
                        $"Tax is printed as {Money(tax)}, but {rate:0.##}% of {Money(baseAmount)} is {Money(expected)} ({Money(tax - expected)} out).",
                        null, Money(tax), d.TaxQuote);
                }
            }
        }

        // (5) paid + balance must equal the total when both are printed.
        // Only when the document prints an amount paid. An estimate that prints no payment
        // line is not "unpaid" — it is not a payment document at all.
        if (d.GrandTotal is { } gt && d.AmountPaid is { } paid && paid > 0)
        {
            var balance = gt - paid;
            if (balance > MoneyTolerance)
            {
                yield return Info(AuditFindingCodes.BalanceNotSettled, documentId,
                    $"{Money(balance)} of the {Money(gt)} total is shown as unpaid.",
                    null, Money(balance), d.AmountPaidQuote);
            }
        }
    }

    // ------------------------------------------------------------------------
    //  Duplicates: the same part billed twice. Compares normalised descriptions AND amounts,
    //  so "Rear bumper assembly (OEM)" at 12,000 twice fires, but two different oil filters
    //  at different prices do not.
    // ------------------------------------------------------------------------
    private static IEnumerable<AuditFinding> CheckDuplicateLines(ExtractedDocument d, Guid documentId)
    {
        if (d.LineItems is not { Count: > 1 }) yield break;

        var seen = new Dictionary<string, ExtractedLineItem>(StringComparer.Ordinal);
        foreach (var l in d.LineItems.Where(l => l.Category is null or "charge" && l.Amount is > 0))
        {
            var key = Normalise(l.Description) + "|" + l.Amount!.Value.ToString("0.00");
            if (seen.ContainsKey(key))
            {
                // One duplicate pair is one finding, however many times it repeats.
                yield return Warn(AuditFindingCodes.DuplicateLine, documentId,
                    $"\"{Trim(l.Description ?? "line")}\" at {Money(l.Amount!.Value)} appears twice on the same document ({Money(l.Amount.Value * 2)} billed for it).",
                    null, Money(l.Amount.Value), l.SourceText ?? l.Description);
                yield break;
            }
            seen[key] = l;
        }
    }

    // ========================================================================
    //  Cross-document checks — the ones no single-page review can do
    // ========================================================================
    private static IEnumerable<AuditFinding> CheckCrossDocument(ClaimAuditInput claim, List<DocumentAudit> docs)
    {
        var read = docs.Where(d => d.Extracted is not null).ToList();

        // (1) the same fact printed differently on two documents of the same claim.
        //
        // Only facts that are genuinely SHARED across a document set belong here. A vehicle
        // registration is shared: every paper about this crash names the same vehicle. An
        // invoice number is NOT shared — an FIR numbers its own report, the garage numbers its
        // estimate, the tow operator numbers its receipt. Comparing those used to fire on every
        // clean claim (caught by the eval harness, which is precisely why it exists). Each
        // document's own number is still checked for reuse elsewhere; see CheckDocument.
        foreach (var group in new (string Label, Func<ExtractedDocument, string?> Get)[]
                 {
                     ("registration number", e => e.VehicleRegistration),
                 })
        {
            var values = read
                .Select(d => (Doc: d, Value: group.Get(d.Extracted!)))
                .Where(x => IsPresent(x.Value))
                .Select(x => (x.Doc, Value: NormaliseRegistration(x.Value!)))
                .DistinctBy(x => x.Value, StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (values.Count > 1)
            {
                var detail = string.Join("; ", read
                    .Where(d => IsPresent(group.Get(d.Extracted!)))
                    .Select(d => $"{Trim(d.FileName)}: {group.Get(d.Extracted!)}"));
                yield return Warn(AuditFindingCodes.ExtractionDisagrees, null,
                    $"Two documents in this claim disagree on the {group.Label} — {detail}.",
                    null, detail, null);
            }
        }

        // (2) the tow destination should be the workshop that issued the estimate.
        var estimate = read.FirstOrDefault(d => d.Extracted!.DocumentKind == ClaimDocumentTypes.RepairEstimate)?.Extracted;
        var tow = read.FirstOrDefault(d => IsPresent(d.Extracted!.TowedTo));

        if (estimate is not null && tow is not null)
        {
            // TowedTo is its own field on the extraction, not free-text notes, so this comparison
            // never has to guess at prose.
            var towedTo = tow.Extracted!.TowedTo;
            if (IsPresent(estimate.IssuerName) && IsPresent(towedTo) &&
                !SharesName(towedTo!, estimate.IssuerName!))
            {
                yield return new AuditFinding
                {
                    Code = AuditFindingCodes.ProviderMismatch,
                    Severity = AiFindingSeverities.Info,
                    DocumentId = tow.DocumentId,
                    Message = $"The vehicle was taken to \"{Trim(towedTo!)}\" but the repair estimate is from \"{estimate.IssuerName}\".",
                    ClaimValue = estimate.IssuerName,
                    DocumentValue = towedTo,
                    Evidence = tow.Extracted!.TowedToQuote
                };
            }
        }

    }

    // ------------------------------------------------------------------------
    //  Completeness: what the claim type requiries vs what is attached.
    //  Data-driven so a new claim type is a row, not an if-chain.
    // ------------------------------------------------------------------------
    private static readonly IReadOnlyDictionary<string, string[]> RequiredDocuments = new Dictionary<string, string[]>
    {
        [InsuranceClaimTypes.OwnVehicleDamage]  = new[] { ClaimDocumentTypes.Fir, ClaimDocumentTypes.RepairEstimate },
        [InsuranceClaimTypes.MedicalExpense]    = new[] { ClaimDocumentTypes.MedicalBill },
        [InsuranceClaimTypes.RentalCar]         = new[] { ClaimDocumentTypes.RentalInvoice },
        [InsuranceClaimTypes.ThirdPartyLiability] = new[] { ClaimDocumentTypes.Fir },
        [InsuranceClaimTypes.UninsuredMotorist] = new[] { ClaimDocumentTypes.Fir },
    };

    private static IEnumerable<AuditFinding> CheckCompleteness(ClaimAuditInput claim)
    {
        if (!RequiredDocuments.TryGetValue(claim.ClaimType, out var required)) yield break;

        var present = claim.Documents.Select(d => d.DocumentType).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var type in required.Where(t => !present.Contains(t)))
        {
            yield return new AuditFinding
            {
                Code = AuditFindingCodes.MissingExpectedDocument,
                Severity = AiFindingSeverities.Info,
                Message = $"A {LabelFor(type)} is normally required for a {claim.ClaimType} claim and none is attached.",
                ClaimValue = claim.ClaimType,
                DocumentValue = null
            };
        }
    }

    // ========================================================================
    //  Verdict — two Warns make a claim Inconsistent, one Warn is NeedsReview.
    //  Rationale: a single warn is often a layout quirk or a typo that a surveyor
    //  clears in seconds; two independent warns on different facts is a pattern.
    // ========================================================================
    public static string VerdictFor(IEnumerable<AuditFinding> findings)
    {
        var warns = findings.Count(f => f.Severity == AiFindingSeverities.Warn);
        var infos = findings.Count(f => f.Severity == AiFindingSeverities.Info);

        if (warns >= 2) return AuditVerdicts.Inconsistent;
        if (warns == 1) return AuditVerdicts.NeedsReview;
        return AuditVerdicts.Consistent;
    }

    // ---- helpers ----------------------------------------------------------

    private static AuditFinding Warn(string code, Guid? docId, string msg,
        string? claimValue = null, string? documentValue = null, string? evidence = null) => new()
    {
        Code = code, Severity = AiFindingSeverities.Warn, DocumentId = docId, Message = msg,
        ClaimValue = claimValue, DocumentValue = documentValue, Evidence = evidence
    };

    private static AuditFinding Info(string code, Guid? docId, string msg,
        string? claimValue = null, string? documentValue = null, string? evidence = null) => new()
    {
        Code = code, Severity = AiFindingSeverities.Info, DocumentId = docId, Message = msg,
        ClaimValue = claimValue, DocumentValue = documentValue, Evidence = evidence
    };

    private static bool IsPresent(string? s) => !string.IsNullOrWhiteSpace(s);

    internal static bool SameRegistration(string a, string b) =>
        NormaliseRegistration(a) == NormaliseRegistration(b);

    private static string NormaliseRegistration(string s) =>
        string.Concat(s.Where(char.IsLetterOrDigit)).ToUpperInvariant();

    private static bool SamePerson(string a, string b) =>
        Normalise(a) == Normalise(b) || Normalise(a).Contains(Normalise(b)) || Normalise(b).Contains(Normalise(a));

    private static string Normalise(string? s) =>
        string.Concat((s ?? string.Empty).Where(char.IsLetterOrDigit)).ToLowerInvariant();

    private static bool SharesName(string a, string b) =>
        Normalise(a).Contains(Normalise(b)) || Normalise(b).Contains(Normalise(a));

    private static bool Mentions(string text, params string[] needles)
    {
        var n = text.ToLowerInvariant();
        return needles.Any(x => n.Contains(x));
    }

    private static DateOnly? ParseDate(string? s) =>
        DateOnly.TryParse(s, out var d) ? d : null;

    private static DateTimeOffset? ParseDateTime(string? s) =>
        DateTimeOffset.TryParse(s, out var d) ? d : null;

    private static string QuoteOf(IEnumerable<ExtractedSubtotal> subs) =>
        string.Join(" | ", subs.Select(x => x.SourceText ?? x.Label ?? "subtotal"));

    private static string Fmt(DateTimeOffset v) => v.ToString("dd MMM yyyy HH:mm");

    private static string Money(decimal v) => "\u20b9" + v.ToString("N2", new System.Globalization.CultureInfo("en-IN"));

    private static string Trim(string s, int max = 60) => s.Length <= max ? s : s[..max] + "…";

    private static string LabelFor(string documentType) => documentType switch
    {
        ClaimDocumentTypes.Fir => "FIR / police report",
        ClaimDocumentTypes.RepairEstimate => "repair estimate",
        ClaimDocumentTypes.MedicalBill => "medical bill",
        ClaimDocumentTypes.RentalInvoice => "rental invoice",
        _ => documentType
    };
}

/// <summary>
/// The input to the judge: the claim's own facts plus whatever was extracted. Deliberately a
/// plain record — no EF entity is passed into this assembly, so the rules stay unit-testable.
/// </summary>
public sealed class ClaimAuditInput
{
    public Guid ClaimId { get; set; }
    public string ClaimNumber { get; set; } = string.Empty;
    public string ClaimType { get; set; } = string.Empty;
    public string VehicleNumber { get; set; } = string.Empty;
    public string DriverName { get; set; } = string.Empty;
    public string PassengerName { get; set; } = string.Empty;
    public DateTimeOffset IncidentAtUtc { get; set; }
    public decimal ClaimedAmountInr { get; set; }
    public List<DocumentAudit> Documents { get; set; } = new();
}
