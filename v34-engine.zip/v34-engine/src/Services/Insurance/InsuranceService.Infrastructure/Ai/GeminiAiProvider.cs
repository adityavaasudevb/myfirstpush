// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Infrastructure/Ai/GeminiAiProvider.cs
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using InsuranceService.Application.Ai;
using InsuranceService.Application.Interfaces;
using Google.Apis.Auth.OAuth2;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace InsuranceService.Infrastructure.Ai;

/// <summary>
/// v3.4 — the only place in the system that talks to a model.
///
/// Why this shape:
///  * It calls the Vertex AI generateContent REST endpoint directly with HttpClient instead of
///    taking a dependency on a client SDK. The SDK you verified on your machine (Google.GenAI)
///    is fine, but the REST call needs no package, no version pin and no project id in code —
///    everything comes from configuration and the ambient credential.
///  * responseMimeType=application/json + responseSchema is what makes the answer parseable.
///    Prompting alone does not; models wrap JSON in prose under load, and a wrapped answer
///    would fail extraction at the worst possible moment.
///  * temperature 0. Deterministic reading is the whole point; creativity here is a defect.
///  * Every failure returns AiCallResult.Fail — the claim must remain reviewable offline.
///
/// Cost note: one call per document + one per claim. A three-document claim is four calls.
/// At gemini-3.8-flash list prices that is roughly ₹1.70 a claim. The caps in AiOptions exist
/// because a retry loop is the only way this becomes expensive.
/// </summary>
public sealed class GeminiAiProvider : IAiProvider
{
    private readonly HttpClient _http;
    private readonly IConfiguration _config;
    private readonly ILogger<GeminiAiProvider> _log;

    public GeminiAiProvider(HttpClient http, IConfiguration config, ILogger<GeminiAiProvider> log)
    {
        _http = http;
        _config = config;
        _log = log;
    }

    public bool IsAvailable => true;
    public string ModelId => _config["Ai:Model"] ?? "gemini-3.8-flash";

    private string Location => _config["Ai:Location"] ?? "global";
    private string ProjectId => _config["Ai:ProjectId"] ?? throw new InvalidOperationException("Ai:ProjectId is not configured.");
    private int TimeoutSeconds => _config.GetValue("Ai:TimeoutSeconds", 20);

    public async Task<AiCallResult<ExtractedDocument>> ExtractDocumentAsync(
        string fileName, string contentType, byte[] bytes,
        string documentType, string claimContext, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            var parts = new List<object>
            {
                new { text = AuditPrompts.ExtractionUser(documentType, claimContext) },
                new { inlineData = new { mimeType = contentType, data = Convert.ToBase64String(bytes) } }
            };

            var body = new
            {
                systemInstruction = new { parts = new[] { new { text = AuditPrompts.ExtractionSystem } } },
                contents = new[] { new { role = "user", parts } },
                generationConfig = new
                {
                    temperature = 0,
                    maxOutputTokens = _config.GetValue("Ai:MaxOutputTokens", 1500),
                    responseMimeType = "application/json",
                    responseSchema = JsonSerializer.Deserialize<JsonElement>(ExtractionSchemaVersion.Json)
                }
            };

            var (text, promptTokens, outputTokens) = await CallAsync(body, ct);
            sw.Stop();

            if (text is null) return AiCallResult<ExtractedDocument>.Fail("empty response", sw.ElapsedMilliseconds);

            var extracted = JsonSerializer.Deserialize<ExtractedDocument>(text, JsonOpts);
            if (extracted is null) return AiCallResult<ExtractedDocument>.Fail("response was not valid JSON", sw.ElapsedMilliseconds);

            // A response that forgot the schema we sent is not trustworthy; treat it as unread.
            if (string.IsNullOrWhiteSpace(extracted.SchemaVersion))
                extracted.SchemaVersion = ExtractionSchemaVersion.Current;

            _log.LogInformation("Extracted {File} ({Type}) in {Ms} ms — {In}/{Out} tokens.",
                fileName, documentType, sw.ElapsedMilliseconds, promptTokens, outputTokens);

            return AiCallResult<ExtractedDocument>.Ok(extracted, promptTokens, outputTokens, sw.ElapsedMilliseconds);
        }
        catch (TaskCanceledException)
        {
            _log.LogWarning("Extraction timed out after {S}s for {File}.", TimeoutSeconds, fileName);
            return AiCallResult<ExtractedDocument>.Fail($"timed out after {TimeoutSeconds}s", sw.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Extraction failed for {File}.", fileName);
            return AiCallResult<ExtractedDocument>.Fail(ex.Message, sw.ElapsedMilliseconds);
        }
    }

    public async Task<AiCallResult<string>> SummariseAsync(string factsJson, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            var body = new
            {
                systemInstruction = new { parts = new[] { new { text = AuditPrompts.VerdictSystem } } },
                contents = new[] { new { role = "user", parts = new[] { new { text = factsJson } } } },
                generationConfig = new { temperature = 0.2, maxOutputTokens = 200 }
            };

            var (text, promptTokens, outputTokens) = await CallAsync(body, ct);
            sw.Stop();
            return text is null
                ? AiCallResult<string>.Fail("empty response", sw.ElapsedMilliseconds)
                : AiCallResult<string>.Ok(text.Trim(), promptTokens, outputTokens, sw.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Summary call failed.");
            return AiCallResult<string>.Fail(ex.Message, sw.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// One HTTP call with a hard timeout. Returns the concatenated text of the first candidate.
    /// Kept private: the rest of the service never sees HTTP.
    /// </summary>
    private async Task<(string? Text, long PromptTokens, long OutputTokens)> CallAsync(object body, CancellationToken ct)
    {
        var url = Location == "global"
            ? $"https://aiplatform.googleapis.com/v1/projects/{ProjectId}/locations/global/publishers/google/models/{ModelId}:generateContent"
            : $"https://{Location}-aiplatform.googleapis.com/v1/projects/{ProjectId}/locations/{Location}/publishers/google/models/{ModelId}:generateContent";

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TimeSpan.FromSeconds(TimeoutSeconds));

        using var request = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json")
        };

        // ADC: the local gcloud credential. On Cloud Run this would be the metadata token;
        // for the demo machine `gcloud auth application-default login` is enough.
        // Google.Apis.Auth is referenced by the Infrastructure project (it comes with the
        // Google.Cloud.* / Google.Apis.* packages you already restored).
        var credential = await GoogleCredential.GetApplicationDefaultAsync(cts.Token);
        var token = await credential.UnderlyingCredential.GetAccessTokenForRequestAsync(cancellationToken: cts.Token);
        request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

        using var response = await _http.SendAsync(request, cts.Token);
        var json = await response.Content.ReadAsStringAsync(cts.Token);

        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException($"Vertex returned {(int)response.StatusCode}: {Truncate(json, 300)}");

        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        var text = root.GetProperty("candidates")[0]
                       .GetProperty("content")
                       .GetProperty("parts")[0]
                       .GetProperty("text")
                       .GetString();

        long prompt = 0, output = 0;
        if (root.TryGetProperty("usageMetadata", out var usage))
        {
            if (usage.TryGetProperty("promptTokenCount", out var p)) prompt = p.GetInt64();
            if (usage.TryGetProperty("candidatesTokenCount", out var o)) output = o.GetInt64();
        }
        return (text, prompt, output);
    }

    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        Converters = { new JsonStringEnumConverter() }
    };

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max] + "…";
}
