// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Infrastructure/Ai/OfflineAiProvider.cs
using InsuranceService.Application.Ai;
using InsuranceService.Application.Interfaces;

namespace InsuranceService.Infrastructure.Ai;

/// <summary>
/// v3.4 — the provider used when Ai:Provider is "inprocess" (the default).
///
/// It exists so that a missing key, a blocked network or a laptop in a viva hall degrades to
/// "no model ran" rather than a 500. The audit still runs: CheckEngine executes against whatever
/// was extracted (nothing), which yields no findings and an explicit Info line per document.
/// The UI renders that as "AI · offline" instead of pretending a clean result is a pass.
/// </summary>
public sealed class OfflineAiProvider : IAiProvider
{
    public bool IsAvailable => false;
    public string ModelId => "none";

    public Task<AiCallResult<ExtractedDocument>> ExtractDocumentAsync(
        string fileName, string contentType, byte[] bytes, string documentType,
        string claimContext, CancellationToken ct = default)
        => Task.FromResult(AiCallResult<ExtractedDocument>.Fail("Ai:Provider is inprocess — no model configured."));

    public Task<AiCallResult<string>> SummariseAsync(string json, CancellationToken ct = default)
        => Task.FromResult(AiCallResult<string>.Fail("Ai:Provider is inprocess — no model configured."));
}
