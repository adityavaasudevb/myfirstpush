<#
    COPY-DOCS.ps1  —  Lane A (SQL lane)
    ------------------------------------------------------------------------
    Puts the generated PDFs where ClaimDocumentService reads them:

        <this folder>\documents  ->  <API content root>\App_Data\uploads\<claimId N>\

    Claim 103 (CLM-2026-GFW103) = the clean set.  Claim 104 (CLM-2026-GFW104) = the missing-FIR,
    two-document defective set. These ids are the fixed GUIDs used by seed-lane-a.sql.

    Usage:
        powershell -ExecutionPolicy Bypass -File .\COPY-DOCS.ps1
        powershell -ExecutionPolicy Bypass -File .\COPY-DOCS.ps1 -UploadsRoot "D:\demo\uploads"
#>
param(
    [string]$UploadsRoot = "$PSScriptRoot\..\..\src\Services\Insurance\InsuranceService.API\App_Data\uploads"
)

$ErrorActionPreference = "Stop"

$claims = @{
    "9f1c0a1000084a019000000000000008" = @("FIR-01-clean.pdf","RepairEstimate-01-clean.pdf","TowingReceipt-01-clean.pdf")
    "9f1c0a1000094a019000000000000009" = @("RepairEstimate-02-defects.pdf","TowingReceipt-02-defects.pdf")
}
# Claims A1 (Paid) and A2 (flagged) carry no evidence rows on purpose.

if (-not (Test-Path $UploadsRoot)) { New-Item -ItemType Directory -Path $UploadsRoot -Force | Out-Null }

$copied = 0
foreach ($claimId in $claims.Keys) {
    $dest = Join-Path $UploadsRoot $claimId
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    foreach ($file in $claims[$claimId]) {
        $src = Join-Path "$PSScriptRoot\documents" $file
        if (-not (Test-Path $src)) { throw "Missing source file: $src" }
        Copy-Item $src $dest -Force
        $copied++
    }
    Write-Host ("  {0}  <-  {1} file(s)" -f $claimId, $claims[$claimId].Count)
}

Write-Host ""
Write-Host "Copied $copied document(s) into $UploadsRoot" -ForegroundColor Green
Write-Host "GFW103 = clean set · GFW104 = defective set" -ForegroundColor Gray
Write-Host "Different layout? re-run with -UploadsRoot 'C:\path\to\App_Data\uploads'"
