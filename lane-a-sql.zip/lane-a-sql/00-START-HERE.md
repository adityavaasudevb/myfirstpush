# Lane A in 6 steps

Everything here is SQL. Nothing is typed into the UI.

```
1.  Register the company account (UI or API)
        company.greenfield@lynxforge.in / GFW#2026Test

2.  (Recommended) Complete the Company Profile once in the UI, or skip it — the seed creates one.

3.  Open seed-lane-a.sql in SSMS and press F5.
        It resolves the profile by email, inserts 2 policies + 4 claims + children,
        and prints what the UI should show. Safe to re-run.

4.  powershell -ExecutionPolicy Bypass -File .\COPY-DOCS.ps1
        Copies the PDFs into App_Data\uploads\<claimId>\ so the API can serve them.

5.  Log in as company.greenfield@lynxforge.in → My Policies (2 or 3, all Active)
        My Claims → 4 rows, one Paid, one flagged, two AwaitingSurveyorPickup

6.  Pick up CLM-2026-GFW103 (clean) and CLM-2026-GFW104 (defective) as the surveyor,
        press "Run integrity check" on both. Expect Consistent vs Inconsistent.
```

**Surveyor:** `surveyor.kavya@claimgrid.in` / `Kavya@2026Survey` (must be approved by Admin first).
**Admin:** your existing admin account.

Read `README-A.md` for the full check sheet, the planted defects, and troubleshooting.
