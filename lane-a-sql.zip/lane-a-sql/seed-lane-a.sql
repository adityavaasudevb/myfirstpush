/* ============================================================================
   LANE A — SQL SEED  ·  Greenfield Fabrication Works  ·  TEST
   ----------------------------------------------------------------------------
   Purpose : deterministic test data, no UI. 2 policies, 4 claims, all children.
   Company : Greenfield Fabrication Works Pvt Ltd  (company.greenfield@lynxforge.in)
   Quote   : quote.greenfield@lynxforge.in  (same password)
   Surveyor: surveyor.kavya@claimgrid.in    (role Surveyor, Approved)
   Admin   : the admin account you already log into /api/... as.

   NO IDS ARE PASTED. Nothing here reads a user table — the profile is found by
   email or created by this script, so an Auth-store assumption cannot break it.
   Re-running is safe: it deletes only the 2 policies and 4 claims it owns (fixed
   GUIDs below) and reinserts them. The company profile is never deleted.

   DBs     : TncCustomers · TncQuotes · TncInsurance  (SQL Server)
   UTC     : every timestamp below is UTC (+00:00). IST = UTC+5:30.
   Timeline: policy term 01 Oct 2026 -> 30 Sep 2027 (active today, 18 Nov 2026)
   ============================================================================
   BEFORE YOU RUN (nothing here is a hard dependency — the script self-heals)
   OPTIONAL, for a fully clickable login: create the accounts through the UI/API
   and let the script reuse the profile it finds by email.
      POST /api/auth/register  { "email": "company.greenfield@lynxforge.in", "password": "GFW#2026Test" }
      POST /api/auth/register  { "email": "quote.greenfield@lynxforge.in",  "password": "GFW#2026Test" }
      POST /api/surveyors/register { ... surveyor.kavya@claimgrid.in ... }  (Admin approves her)
   The QUOTES need a real owner user id (OwnerUserId feeds "My Quotes"), so the
   script takes it from the company profile's UserId when one exists. If you did
   not create the account first, the profile is seeded with a placeholder UserId
   and the quote will not appear under My Quotes — everything else works.
   Run the PRE-FLIGHT SELECT in section 0 first; it tells you which case you are in.
   ============================================================================ */

SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ---------------------------------------------------------------------------
   0. PRE-FLIGHT — run these on their own first, read the results, then run all
   --------------------------------------------------------------------------- */
-- SELECT Id, UserId, Name, Email FROM TncCustomers.dbo.CompanyProfiles WHERE Email = N'company.greenfield@lynxforge.in';
-- SELECT Id, CreatedAtUtc, StartDateUtc, EndDateUtc, Status FROM TncInsurance.dbo.Policies WHERE PolicyNumber IN ('POL-2026-GFW001','POL-2026-GFW002');

/* ---------------------------------------------------------------------------
   1. COMPANY PROFILE — resolved by email, created if missing
      Deliberately does NOT read AspNetUsers: in this solution Identity lives in
      AuthService's own store (SQLite by default, SQL Server in some builds), so
      querying it from here is how a seed script breaks on someone else's machine.
      Nothing below needs a user id. If you would rather create the profile in the
      UI (Company Profile page, 6 fields), do that first — this block will find it
      and leave it alone.
   --------------------------------------------------------------------------- */
DECLARE @Profile uniqueidentifier = '9F1C0A10-0001-4A01-9000-000000000001';

IF NOT EXISTS (SELECT 1 FROM TncCustomers.dbo.CompanyProfiles WHERE Email = N'company.greenfield@lynxforge.in')
BEGIN
    INSERT INTO TncCustomers.dbo.CompanyProfiles
        (Id, UserId, Name, RegistrationNo, ContactPerson, Email, Phone, FleetSize, CreatedAt, UpdatedAt)
    VALUES (@Profile, N'seed-greenfield-owner', N'Greenfield Fabrication Works Pvt Ltd',
            N'U28999TG2017PTC109224', N'Meenakshi Sundaram', N'company.greenfield@lynxforge.in',
            N'9849012214', 12, '2026-09-26T06:00:00+00:00', '2026-09-26T06:00:00+00:00');
    PRINT 'Company profile created by the seed.';
END
ELSE
BEGIN
    SET @Profile = (SELECT TOP 1 Id FROM TncCustomers.dbo.CompanyProfiles WHERE Email = N'company.greenfield@lynxforge.in');
    PRINT 'Existing company profile found — reusing it, not touching it.';
END
DECLARE @QuoteOwner nvarchar(64) =
    (SELECT TOP 1 UserId FROM TncCustomers.dbo.CompanyProfiles WHERE Id = @Profile);

-- If your CustomerService migration names these columns differently, this is the ONE
-- block to adjust. Everything after it only uses @Profile / @QuoteOwner.

/* ---------------------------------------------------------------------------
   2. FIXED IDS for everything this script owns (safe to hard-code — new rows)
   --------------------------------------------------------------------------- */
DECLARE @QuoteA    uniqueidentifier = '9F1C0A10-0002-4A01-9000-000000000002';
DECLARE @QuoteB    uniqueidentifier = '9F1C0A10-0003-4A01-9000-000000000003';
DECLARE @PolicyA   uniqueidentifier = '9F1C0A10-0004-4A01-9000-000000000004';
DECLARE @PolicyB   uniqueidentifier = '9F1C0A10-0005-4A01-9000-000000000005';
DECLARE @ClaimA1   uniqueidentifier = '9F1C0A10-0006-4A01-9000-000000000006'; -- paid, 21 Oct
DECLARE @ClaimA2   uniqueidentifier = '9F1C0A10-0007-4A01-9000-000000000007'; -- flagged boundary, awaiting pickup
DECLARE @ClaimB1   uniqueidentifier = '9F1C0A10-0008-4A01-9000-000000000008'; -- clean, 10 Nov -> Consistent
DECLARE @ClaimB2   uniqueidentifier = '9F1C0A10-0009-4A01-9000-000000000009'; -- defective, 10 Nov -> findings

/* ---------------------------------------------------------------------------
   3. RESET — delete only what this script creates (children first)
   --------------------------------------------------------------------------- */
USE TncInsurance;
IF OBJECT_ID(N'dbo.ClaimDocuments', N'U') IS NOT NULL
    EXEC sp_executesql N'DELETE FROM ClaimDocuments WHERE ClaimId IN (@a,@b,@c,@d)',
         N'@a uniqueidentifier,@b uniqueidentifier,@c uniqueidentifier,@d uniqueidentifier',
         @a = @ClaimA1, @b = @ClaimA2, @c = @ClaimB1, @d = @ClaimB2;
DELETE FROM ClaimStatusHistories WHERE ClaimId IN (@ClaimA1,@ClaimA2,@ClaimB1,@ClaimB2);
DELETE FROM FieldVerifications  WHERE ClaimId IN (@ClaimA1,@ClaimA2,@ClaimB1,@ClaimB2);
DELETE FROM SurveyorReports     WHERE ClaimId IN (@ClaimA1,@ClaimA2,@ClaimB1,@ClaimB2);
DELETE FROM TripEvents          WHERE ClaimId IN (@ClaimA1,@ClaimA2,@ClaimB1,@ClaimB2);
DELETE FROM Claims              WHERE Id      IN (@ClaimA1,@ClaimA2,@ClaimB1,@ClaimB2);
DELETE FROM Policies            WHERE Id      IN (@PolicyA,@PolicyB);

USE TncQuotes;
DELETE FROM Quotes WHERE Id IN (@QuoteA,@QuoteB);



/* ---------------------------------------------------------------------------
   4. QUOTES (owner = the company user, so they show up on My Quotes)
   Premium = fleet x 15,000 x tier x (1 + add-on rates)
     A: 12 x 15,000 x 1.6 x 1.17 = 336,960   (PD .12 + UM .05)
     B: 12 x 15,000 x 1.6 x 1.21 = 348,480   (PD .12 + MedPay .06 + Rental .03)
   Both quotes are created 25 Sep 2026 so that the seeded CreatedAtUtc of every
   policy (and a renewal) lands afterwards. The script is not a UI simulation —
   it is a fixture, and those fields are only ever displayed, never validated.
   --------------------------------------------------------------------------- */
USE TncQuotes;
INSERT INTO Quotes (Id, QuoteNumber, OwnerUserId, FleetSize, Tier, AddOns, PremiumInr, Status, CreatedAtUtc, ExpiresAtUtc)
VALUES
(@QuoteA, N'Q-2026-GFW181', @QuoteOwner, 12, N'Tier B',
 N'["Physical Damage","Uninsured Motorist"]', 336960.00, N'Converted',
 '2026-09-25T05:30:00+00:00', '2026-10-02T05:30:00+00:00'),
(@QuoteB, N'Q-2026-GFW182', @QuoteOwner, 12, N'Tier B',
 N'["Physical Damage","Medical Payments","Rental Car"]', 348480.00, N'Active',
 '2026-09-25T05:40:00+00:00', '2026-10-02T05:40:00+00:00');

/* ---------------------------------------------------------------------------
   5. POLICIES — both Active today.
      Policy B ends 20 Nov 2026 => the renewal button is inside its 30-day window
      *without* touching config, and its 29 days of paid claims give a 15% surcharge.
      Policy A's term started 01 Oct, so the 21 Oct incident is inside it.
   --------------------------------------------------------------------------- */
USE TncInsurance;
INSERT INTO Policies
(Id, PolicyNumber, CompanyProfileId, OriginQuoteId, Tier, AddOns, FleetSize, PremiumInr, Status,
 StartDateUtc, EndDateUtc, CreatedAtUtc, RenewedFromPolicyId, ReviewRequired)
VALUES
(@PolicyA, N'POL-2026-GFW001', @Profile, @QuoteA, N'Tier B',
 N'["Physical Damage","Uninsured Motorist"]', 12, 336960.00, N'Active',
 '2026-10-01T10:00:00+00:00', '2027-09-30T10:00:00+00:00', '2026-09-30T06:00:00+00:00', NULL, 0),
(@PolicyB, N'POL-2026-GFW002', @Profile, @QuoteB, N'Tier B',
 N'["Physical Damage","Medical Payments","Rental Car"]', 12, 348480.00, N'Active',
 '2025-11-21T10:00:00+00:00', '2026-11-20T10:00:00+00:00', '2025-11-21T06:00:00+00:00', NULL, 0);

/* ---------------------------------------------------------------------------
   6. CLAIMS
      A1/A2 sit on Policy A, B1/B2 on Policy B.
      Trip logs below are all Period 3 except A2 (Period 2, boundary-flagged).
      Claim types: Own Vehicle Damage requires the Physical Damage add-on; both
      policies have it, so nothing is rejected on coverage grounds by accident.
   --------------------------------------------------------------------------- */
USE TncInsurance;
INSERT INTO Claims
(Id, ClaimNumber, PolicyId, DriverName, DriverLicenceNumber, PassengerName, PassengerContact,
 PassengerCount, AdditionalPassengersNotes, VehicleNumber, IncidentAtUtc, IncidentLocation, Description,
 ClaimedAmountInr, ClaimType, DocumentLink, AppNotInUseDeclared, DerivedPeriod, PreliminaryDecision,
 PreliminaryAmountInr, IsFlagged, FlagReason, Status, AssignedSurveyorId, FinalPayoutAmountInr, CreatedAtUtc)
VALUES

-- A1 — PAID. Drives Policy A's renewal ratio later (if you renew A).
(@ClaimA1, N'CLM-2026-GFW101', @PolicyA, N'Arjun Ravikumar', N'TG0320190112233', N'Latha Krishnan', N'9491027781',
 2, N'Second passenger: minor, no separate details recorded.', N'TG12KQ8890',
 '2026-10-21T06:40:00+00:00', N'Uppal Ring Road, near Genpact junction, Hyderabad - 500039',
 N'Rear-end collision at a signal; passenger aboard; bumper and boot lid damage. Surveyor negotiated the estimate.',
 412000.00, N'Own Vehicle Damage', N'https://evidence.internal/greenfield/CLM-GFW101', 0,
 N'Period3', N'Approve', 412000.00, 0, NULL, N'Paid', NULL, 368000.00, '2026-10-21T09:15:00+00:00'),

-- A2 — FLAGGED, waiting in the surveyor queue. Incident 1 min after RideAccepted
--      => boundary flag (FR5.6). Period 2 on Tier B approves but stays flagged.
(@ClaimA2, N'CLM-2026-GFW102', @PolicyA, N'Sandeep Varma', N'TG0320210077661', N'Ritika Bose', N'9848036612',
 1, NULL, N'TG12KQ4417',
 '2026-11-02T13:31:00+00:00', N'LB Nagar flyover, descending ramp, Hyderabad - 500074',
 N'Low-speed contact with a divider while en route to pick up the passenger; left door scuffed.',
 96000.00, N'Own Vehicle Damage', N'https://evidence.internal/greenfield/CLM-GFW102', 0,
 N'Period2', N'Approve', 96000.00, 1, N'Incident time within 2 min of a period boundary',
 N'AwaitingSurveyorPickup', NULL, NULL, '2026-11-02T15:00:00+00:00'),

-- B1 — THE CLEAN ONE. 10 Nov 13:22 UTC = 18:52 IST. Documents match field for field.
(@ClaimB1, N'CLM-2026-GFW103', @PolicyB, N'Karthik Iyer', N'TG1120180044129', N'Devi Priya', N'9003321144',
 2, N'Second passenger: colleague from the loading site.', N'TG11LK3607',
 '2026-11-10T13:22:00+00:00', N'Miyapur X Roads, Hyderabad - 500049',
 N'Left-side collision with an overtaking pick-up while turning into the service lane; door and mirror damaged.',
 71154.00, N'Own Vehicle Damage', N'https://evidence.internal/greenfield/CLM-GFW103', 0,
 N'Period3', N'Approve', 71154.00, 0, NULL, N'AwaitingSurveyorPickup', NULL, NULL, '2026-11-10T14:40:00+00:00'),

-- B2 — THE DEFECTIVE ONE. Same day, 11:10 UTC (16:40 IST) => >2h from B1, no 409 risk.
(@ClaimB2, N'CLM-2026-GFW104', @PolicyB, N'Prakash Menon', N'TG1120200033118', N'Anita Salve', N'9705588120',
 1, NULL, N'TG11LK3607',
 '2026-11-10T11:10:00+00:00', N'Miyapur X Roads, Hyderabad - 500049',
 N'Breakdown and collision on the same stretch; vehicle towed for clutch and body repair.',
 44500.00, N'Own Vehicle Damage', N'https://evidence.internal/greenfield/CLM-GFW104', 0,
 N'Period3', N'Approve', 44500.00, 0, NULL, N'AwaitingSurveyorPickup', NULL, NULL, '2026-11-10T12:30:00+00:00');

/* ---------------------------------------------------------------------------
   7. TRIP EVENTS
   A1: 06:10 / 06:20 / 06:30 / 07:15  -> incident 06:40 = Period 3
   A2: 13:30 / 13:30 / 13:45 / 14:30  -> incident 13:31 = Period 2, boundary flag
   B1: 13:02 / 13:10 / 13:18 / 13:55  -> incident 13:22 = Period 3
   B2: 10:50 / 11:00 / 11:05 / 11:50  -> incident 11:10 = Period 3
   --------------------------------------------------------------------------- */
INSERT INTO TripEvents (Id, ClaimId, EventType, OccurredAtUtc) VALUES
(NEWID(), @ClaimA1, N'AppOnline',         '2026-10-21T06:10:00+00:00'),
(NEWID(), @ClaimA1, N'RideAccepted',      '2026-10-21T06:20:00+00:00'),
(NEWID(), @ClaimA1, N'PassengerPickedUp', '2026-10-21T06:30:00+00:00'),
(NEWID(), @ClaimA1, N'RideCompleted',     '2026-10-21T07:15:00+00:00'),

(NEWID(), @ClaimA2, N'AppOnline',         '2026-11-02T13:00:00+00:00'),
(NEWID(), @ClaimA2, N'RideAccepted',      '2026-11-02T13:30:00+00:00'),
(NEWID(), @ClaimA2, N'PassengerPickedUp', '2026-11-02T13:45:00+00:00'),
(NEWID(), @ClaimA2, N'RideCompleted',     '2026-11-02T14:30:00+00:00'),

(NEWID(), @ClaimB1, N'AppOnline',         '2026-11-10T13:02:00+00:00'),
(NEWID(), @ClaimB1, N'RideAccepted',      '2026-11-10T13:10:00+00:00'),
(NEWID(), @ClaimB1, N'PassengerPickedUp', '2026-11-10T13:18:00+00:00'),
(NEWID(), @ClaimB1, N'RideCompleted',     '2026-11-10T13:55:00+00:00'),

(NEWID(), @ClaimB2, N'AppOnline',         '2026-11-10T10:50:00+00:00'),
(NEWID(), @ClaimB2, N'RideAccepted',      '2026-11-10T11:00:00+00:00'),
(NEWID(), @ClaimB2, N'PassengerPickedUp', '2026-11-10T11:05:00+00:00'),
(NEWID(), @ClaimB2, N'RideCompleted',     '2026-11-10T11:50:00+00:00');

/* ---------------------------------------------------------------------------
   8. FIELD VERIFICATIONS — invariant: a claim UnderInvestigation has EXACTLY four,
      all Pending, until the surveyor marks them. A1 is finished (all Verified).
   --------------------------------------------------------------------------- */
INSERT INTO FieldVerifications (Id, ClaimId, FieldName, Status, Note) VALUES
(NEWID(), @ClaimA1, N'DriverInfo',    N'Verified', N'DL checked against Parivahan; driver on the fleet roster.'),
(NEWID(), @ClaimA1, N'PassengerInfo', N'Verified', N'Passenger statement matches the trip log.'),
(NEWID(), @ClaimA1, N'TripEventLog',  N'Verified', N'Timestamps plausible; Period 3 confirmed.'),
(NEWID(), @ClaimA1, N'Documents',     N'Verified', N'FIR copy, estimate and towing receipt on file.');

/* ---------------------------------------------------------------------------
   9. SURVEYOR REPORT for A1 (notes >= 1 char; amount required for an Approve)
   --------------------------------------------------------------------------- */
INSERT INTO SurveyorReports (Id, ClaimId, OverallOutcome, Recommendation, RecommendedAmountInr, Notes, SubmittedAtUtc)
VALUES (NEWID(), @ClaimA1, N'Genuine', N'Approve', 368000.00,
        N'Site inspected at the workshop. Estimate Rs 4,12,000; depreciation and betterment deducted, Rs 3,68,000 recommended. Damage pattern consistent with the FIR.',
        '2026-10-23T09:00:00+00:00');

/* ---------------------------------------------------------------------------
   10. STATUS HISTORY — A1 full trail to Paid; A2/B1/B2 intake pair only.
       ChangedByUserId is the JWT sub of whoever caused the transition. The seed
       uses the company user for intake and the surveyor for report steps; the
       admin's own sub is not needed (the demo never labels the history by email).
   --------------------------------------------------------------------------- */
INSERT INTO ClaimStatusHistories (Id, ClaimId, FromStatus, ToStatus, ChangedAtUtc, ChangedByUserId) VALUES
(NEWID(), @ClaimA1, NULL,                       N'Submitted',               '2026-10-21T09:15:00+00:00', NULL),
(NEWID(), @ClaimA1, N'Submitted',               N'AwaitingSurveyorPickup',  '2026-10-21T09:15:00+00:00', NULL),
(NEWID(), @ClaimA1, N'AwaitingSurveyorPickup',  N'UnderInvestigation',      '2026-10-22T05:00:00+00:00', NULL),
(NEWID(), @ClaimA1, N'UnderInvestigation',      N'SurveyorReportSubmitted', '2026-10-23T09:00:00+00:00', NULL),
(NEWID(), @ClaimA1, N'SurveyorReportSubmitted', N'Paid',                    '2026-10-24T07:30:00+00:00', NULL),

(NEWID(), @ClaimA2, NULL, N'Submitted',              '2026-11-02T15:00:00+00:00', NULL),
(NEWID(), @ClaimA2, N'Submitted', N'AwaitingSurveyorPickup', '2026-11-02T15:00:00+00:00', NULL),

(NEWID(), @ClaimB1, NULL, N'Submitted',              '2026-11-10T14:40:00+00:00', NULL),
(NEWID(), @ClaimB1, N'Submitted', N'AwaitingSurveyorPickup', '2026-11-10T14:40:00+00:00', NULL),

(NEWID(), @ClaimB2, NULL, N'Submitted',              '2026-11-10T12:30:00+00:00', NULL),
(NEWID(), @ClaimB2, N'Submitted', N'AwaitingSurveyorPickup', '2026-11-10T12:30:00+00:00', NULL);

/* ---------------------------------------------------------------------------
   11. EVIDENCE ROWS (v3.4) — copied onto disk by COPY-DOCS.ps1 afterwards.
       StoredFileName MUST equal the file name in lane-a-sql/documents/.
       AiStatus stays NULL: the audit has not run yet. Press the button in the UI.
   --------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.ClaimDocuments', N'U') IS NOT NULL
BEGIN
    INSERT INTO ClaimDocuments (Id, ClaimId, DocumentType, OriginalFileName, StoredFileName, ContentType, SizeBytes, Sha256, UploadedByUserId, UploadedAtUtc, AiStatus, AiModel, AiFindingsJson, AiReviewedAtUtc)
    VALUES
    (NEWID(), @ClaimB1, N'FIR',
     N'FIR-01-clean.pdf', N'FIR-01-clean.pdf', N'application/pdf', 46723,
     N'f7554dd1bc7015287eb5e935934253190d7f206934f2fdba4905759487609168', NULL, '2026-11-10T14:35:00+00:00', NULL, NULL, NULL, NULL),
    (NEWID(), @ClaimB1, N'RepairEstimate',
     N'RepairEstimate-01-clean.pdf', N'RepairEstimate-01-clean.pdf', N'application/pdf', 46872,
     N'76f70ac5d4b925317b7143a618492bd8121a84e722b2624667f6d5e898d50f7f', NULL, '2026-11-10T14:36:00+00:00', NULL, NULL, NULL, NULL),
    (NEWID(), @ClaimB1, N'Other',
     N'TowingReceipt-01-clean.pdf', N'TowingReceipt-01-clean.pdf', N'application/pdf', 46117,
     N'd3103865c972b3b097f06cf554052e2234b70cf2f58fa513d8e3fc20e707b63a', NULL, '2026-11-10T14:37:00+00:00', NULL, NULL, NULL, NULL),

    (NEWID(), @ClaimB2, N'RepairEstimate',
     N'RepairEstimate-02-defects.pdf', N'RepairEstimate-02-defects.pdf', N'application/pdf', 46608,
     N'957cf52f6430bca91f6255f3a41cb8f9cfe678e5de38bbe5f23ef37fe24b7c85', NULL, '2026-11-10T12:25:00+00:00', NULL, NULL, NULL, NULL),
    (NEWID(), @ClaimB2, N'Other',
     N'TowingReceipt-02-defects.pdf', N'TowingReceipt-02-defects.pdf', N'application/pdf', 46062,
     N'e8e9632b3641fd090d05caa5409778a652736a90891ed8233bbef5d2c8039827', NULL, '2026-11-10T12:26:00+00:00', NULL, NULL, NULL, NULL);
    PRINT '5 evidence rows inserted.';
END
ELSE
    PRINT 'ClaimDocuments table not found (v3.4 Slice A not migrated) — claims seeded without evidence rows.';

/* ---------------------------------------------------------------------------
   12. EXPECTED RESULT — check the UI against this after COPY-DOCS.ps1
   --------------------------------------------------------------------------- */
PRINT '================================================================';
PRINT 'LANE A SEEDED — Greenfield Fabrication Works';
PRINT '  Policies : POL-2026-GFW001 (Active) · POL-2026-GFW002 (Active, renewable now)';
PRINT '  Claims   : GFW101 Paid 3,68,000 · GFW102 flagged/Awaiting · GFW103 clean · GFW104 defective';
PRINT '  Documents: 5 rows (3 clean on GFW103, 2 on GFW104) — run COPY-DOCS.ps1 next';
PRINT '';
PRINT '  Surveyor queue should show exactly: GFW102 (flagged), GFW103, GFW104';
PRINT '  Company My Claims: 4 rows, statuses Paid / AwaitingSurveyorPickup x3';
PRINT '  Admin dashboard  : activePolicies 2, payouts 3,68,000';
PRINT '================================================================';
