# Lane A — the SQL seed lane (testing, screenshots, regression)

**One file, one batch, no pasted GUIDs.** The script resolves every foreign key by email or by
joining rows it just inserted, and it **throws before writing anything** if a user is missing.

**Company:** Greenfield Fabrication Works Pvt Ltd
**Result:** 2 active policies, 4 claims in every useful state, 5 evidence documents already attached.

> Everything in this lane is different from Lane B: company, people, vehicles, workshops, policy
> numbers, even the incident city side. Nothing collides.

---

## 1. Prerequisites (10 minutes, mostly clicking)

1. All services up (gateway `:5000`, Auth `:5001`, Customer `:5002`, Quote `:5003`, Insurance `:5004`).
2. Databases exist and are migrated: `TncCustomers`, `TncQuotes`, `TncInsurance`, plus Auth SQLite.
3. **Create the accounts (recommended, not required).** The seed never reads a user table — it
finds the company profile by email, or creates one. Register first so the profile has your real
`UserId` (that is what makes the quotes appear under *My Quotes*):

```http
POST http://localhost:5000/api/auth/register
{ "email": "company.greenfield@lynxforge.in", "password": "GFW#2026Test" }
```

Then complete the profile once in the UI (Company Profile → 6 fields), or let the seed insert it.

> Registering as a **Company** grants the Company role. A second company account
> (`quote.greenfield@…`) is optional and adds nothing to this lane — the quotes are owned by the
> profile's `UserId`, which is the company account.

4. **Create + approve the surveyor** (role is granted by the endpoint, not by SQL):

```http
POST http://localhost:5000/api/surveyors/register
{
  "email": "surveyor.kavya@claimgrid.in",
  "password": "Kavya@2026Survey",
  "name": "Kavya Raghavan",
  "contactInfo": "+91-90008-44120",
  "irdaiLicenseNumber": "IRDAI/SLA/2023/009112",
  "licenseValidUntil": "2028-03-31"
}
```

Then, logged in as Admin: `GET /api/surveyors/pending` → `POST /api/surveyors/{id}/approve`.

5. **Pre-flight check** — one SELECT, run alone:

```sql
SELECT Id, UserId, Name, Email FROM TncCustomers.dbo.CompanyProfiles
WHERE Email = N'company.greenfield@lynxforge.in';
```

- **No row** → the seed creates the profile for you. Everything works except *My Quotes* (no real
  `UserId` to own them).
- **One row** → the seed reuses it and gives the quotes that `UserId`. This is the case you want.
- **Error: invalid object name** → your CustomerService migration named the table differently.
  Fix the one INSERT in section 1 of the seed and nothing else.

---

## 2. Run the seed

Open `seed-lane-a.sql` in SSMS → **Execute** (F5). It prints `LANE A SEEDED` with the expected UI
state at the bottom.

Re-running is safe: it deletes only the four claim GUIDs and two policy GUIDs it owns, then reinserts
them. It never touches other companies' rows.

### What lands where

| Table | Rows | Note |
|---|---|---|
| `CompanyProfiles` (TncCustomers) | 1 | fleet 12 |
| `Quotes` (TncQuotes) | 2 | one `Converted`, one `Active` with a live expiry |
| `Policies` | 2 | both **Active today** |
| `Claims` | 4 | Paid · flagged/awaiting · clean · defective |
| `TripEvents` | 16 | 4 per claim, canonical order |
| `FieldVerifications` | 4 | only on the Paid claim (the rest get theirs at pickup) |
| `SurveyorReports` | 1 | on the Paid claim |
| `ClaimStatusHistories` | 11 | full trail for Paid, intake pair for the rest |
| `ClaimDocuments` | 5 | 3 on the clean claim, 2 on the defective one |

---

## 3. Copy the documents onto disk (30 seconds)

`ClaimDocumentService` streams from `DocumentStorage:RootPath`, not from the database. Run:

```powershell
cd <this folder>
powershell -ExecutionPolicy Bypass -File .\COPY-DOCS.ps1
```

Default target: `src\Services\Insurance\InsuranceService.API\App_Data\uploads\<claimIdN>\`.
Different layout? Pass it: `-UploadsRoot "D:\demo\uploads"`.

The script copies into four folders keyed by the claim GUIDs baked into the seed — nothing to look up.

---

## 4. Sign in and check

| Login | Password | Look at |
|---|---|---|
| `company.greenfield@lynxforge.in` | `GFW#2026Test` | My Policies: 2 Active · My Claims: 4 · My Quotes: 1 Converted, 1 Active |
| `surveyor.kavya@claimgrid.in` | `Kavya@2026Survey` | Queue: 3 claims — one **flagged**, two plain |
| Admin | your existing admin | Dashboard: 2 active policies, ₹3,68,000 paid |

### The two claims you will work with

| Claim | Incident (UTC) | Amount | Documents | Expected audit |
|---|---|---|---|---|
| `CLM-2026-GFW103` | 10 Nov 13:22 | ₹71,154 | FIR + estimate + towing | **Consistent** |
| `CLM-2026-GFW104` | 10 Nov 11:10 | ₹44,500 | estimate + towing (no FIR) | **Inconsistent — 5 findings** |

Claim 104's planted defects, and where each lives:

| # | Defect | File |
|---|---|---|
| 1 | Vehicle `TG11LK3617` ≠ claimed `TG11LK3607` | RepairEstimate-02 |
| 2 | Estimate dated **08 Nov**, two days before the 10 Nov incident | RepairEstimate-02 |
| 3 | "Tax at 18 %" printed as ₹11,160; 18 % of the ₹48,150 base is ₹8,667 → **₹2,493 overstated** | RepairEstimate-02 |
| 4 | Total ₹59,310 > claimed ₹44,500 | RepairEstimate-02 |
| 5 | Tow drops the vehicle at **Sri Kalyan Motors**, but the estimate is from **Meghna Auto Body Works** | TowingReceipt-02 vs estimate |

Note claim 103's deliberate absence of a **fourth** field check: it has **3 documents**, not 4 — the
"3 documents per claim" rule from the design, and the upload endpoint allows up to 10.

---

## 5. What to test with this lane

1. **Upload path** — try a `.exe` → 400; try a 6 MB PDF → 400; upload a duplicate → 201 (allowed).
2. **Frozen evidence** — pick up 103 in the surveyor app, then try uploading from the company side
   → **409** ("frozen at pickup"). That is FR5.16 working.
3. **Audit** — run the integrity check on both claims; 103 should produce zero findings, 104 the five
   above. Same button, same model, different verdict.
4. **Duplicate guard** — file a *new* claim on policy 002 with an incident at 16:41 IST on 10 Nov
   (within ±2 h of claim 104's 16:40) → **409** naming claim 104.
5. **Renewal** — policy `POL-2026-GFW002` ends **20 Nov 2026**, so Renew is live **today** with no
   config changes. Claims ratio 368,000 / 348,480 = 1.056 → **Surcharge15**, premium
   ₹348,480 × 1.15 = **₹4,00,752**, and `ReviewRequired` is **not** set (ratio ≤ 1.00 is surcharge;
   > 1.00 is review — read your own code before narrating this one, both branches are one click apart).
   If you want the review branch instead, change claim A1's `FinalPayoutAmountInr` to `400000`.

> The renewal band is the one place where the demo script can lie if you improvise. Say the number
> the UI shows, not the number you expect.

---

## 6. Files

```
lane-a-sql/
├─ README-A.md              ← this file
├─ seed-lane-a.sql          ← one batch, email-resolved, safe to re-run
├─ COPY-DOCS.ps1            ← puts PDFs where the API reads them
└─ documents/
   ├─ FIR-01-clean.pdf                    (clean claim 103)
   ├─ RepairEstimate-01-clean.pdf
   ├─ TowingReceipt-01-clean.pdf
   ├─ RepairEstimate-02-defects.pdf       (defective claim 104)
   ├─ TowingReceipt-02-defects.pdf
   ├─ MedicalBill-01-clean.pdf            (medical flow, unused by this lane)
   └─ MedicalBill-03-pharmacy.pdf         (second money layout, unused by this lane)
```

---

## 7. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Invalid object name 'CompanyProfiles'` | CustomerService table/columns differ from the pack | adjust section 1 only — it is the single schema-dependent block |
| Profile row exists but My Policies is empty | policy `CompanyProfileId` ≠ the profile the API resolves for you | `SELECT Id, Email FROM CompanyProfiles` and compare with `Policies` |
| Login works, `/api/policies/company` empty | policy `CompanyProfileId` ≠ your profile id | `SELECT Id, Email FROM CompanyProfiles` and compare with `Policies` |
| Documents list empty but rows exist | wrong claim id or the API is pointed elsewhere | check `DocumentStorage:RootPath` and re-run `COPY-DOCS.ps1` |
| Audit button missing | claim amount below `Ai:AuditThresholdInr` (10,000) or status not `AwaitingSurveyorPickup` | both claims here are above the threshold |
