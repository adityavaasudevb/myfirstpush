import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { QuoteService } from '../../../core/services/quote.service';
import { Quote } from '../../../core/models/quote.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

type StatusFilter = 'All' | 'Active' | 'Converted' | 'Expired';

@Component({
  selector: 'app-my-quotes',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './my-quotes.html',
  styleUrl: './my-quotes.css',
})
export class MyQuotes {
  private readonly quotesApi = inject(QuoteService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly quotes = signal<Quote[]>([]);
  readonly statusFilter = signal<StatusFilter>('All');

  readonly filters: StatusFilter[] = ['All', 'Active', 'Converted', 'Expired'];

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.quotesApi.mine().subscribe({
      next: (qs) => {
        this.quotes.set([...qs].sort((a, b) => (a.createdAtUtc < b.createdAtUtc ? 1 : -1)));
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  filtered(): Quote[] {
    const f = this.statusFilter();
    return f === 'All' ? this.quotes() : this.quotes().filter((q) => q.status === f);
  }

  countFor(f: StatusFilter): number {
    return f === 'All' ? this.quotes().length : this.quotes().filter((q) => q.status === f).length;
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Converted':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }
}
