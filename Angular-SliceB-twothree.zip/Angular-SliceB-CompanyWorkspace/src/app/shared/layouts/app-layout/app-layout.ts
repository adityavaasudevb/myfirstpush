import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { Role } from '../../../core/constants/roles';

interface NavLink {
  label: string;
  route: string;
  exact?: boolean;
}

// Role-based navbar links — extended as more workspace pages are built.
const ROLE_NAV: Record<Role, NavLink[]> = {
  Company: [
    { label: 'Workspace', route: '/company', exact: true },
    { label: 'New quote', route: '/company/quotes/new' },
  ],
  Surveyor: [{ label: 'Workspace', route: '/surveyor', exact: true }],
  Admin: [{ label: 'Workspace', route: '/admin', exact: true }],
};

@Component({
  selector: 'app-app-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app-layout.html',
  styleUrl: './app-layout.css',
})
export class AppLayout {
  readonly auth = inject(AuthService);

  links(): NavLink[] {
    const r = this.auth.role();
    return r ? ROLE_NAV[r] : [];
  }
}
