import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApplyPolicyRequest,
  ApplyPolicyResponse,
  PayPolicyResponse,
  PolicyDetails,
  PolicyListItem,
  RenewalResponse,
} from '../models/policy.model';

const API = environment.apiBaseUrl;

// InsuranceService client (doc §6.4). Company ownership is always resolved
// server-side from the caller's token — the client never sends a company ID.
@Injectable({ providedIn: 'root' })
export class PolicyService {
  private readonly http = inject(HttpClient);

  /** FR4.1 — straight-through application; 201 Created. Starts Pending. */
  apply(body: ApplyPolicyRequest): Observable<ApplyPolicyResponse> {
    return this.http.post<ApplyPolicyResponse>(`${API}/policies/apply`, body);
  }

  /** FR4.6/FR9.4 — caller's policies, optional status + created-date filters (server-side). */
  mine(filter?: { status?: string; from?: string; to?: string }): Observable<PolicyListItem[]> {
    let params = new HttpParams().set('pageSize', 50);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.from) params = params.set('from', filter.from);
    if (filter?.to) params = params.set('to', filter.to);
    return this.http
      .get<unknown>(`${API}/policies/company`, { params })
      .pipe(map((res) => unwrapList(res).map(normalizePolicy)));
  }

  get(id: string): Observable<PolicyDetails> {
    return this.http.get<unknown>(`${API}/policies/${id}`).pipe(map(normalizePolicy)) as Observable<PolicyDetails>;
  }

  /** FR4.4/FR6.1 — simulated payment; activates with a 365-day term. */
  pay(id: string): Observable<PayPolicyResponse> {
    return this.http.post<PayPolicyResponse>(`${API}/policies/${id}/pay`, {});
  }

  /** FR4.5 — cancel a Pending policy (also how a renewal offer is declined). */
  cancel(id: string): Observable<void> {
    return this.http.delete<void>(`${API}/policies/${id}`);
  }

  /** FR4.7 — claims-ratio-priced renewal offer (409 if one is already pending). */
  renew(id: string): Observable<RenewalResponse> {
    return this.http.post<RenewalResponse>(`${API}/policies/${id}/renew`, {});
  }
}

type Raw = Record<string, any>;

// Defensive: company list may come back paged ({ items: [...] }) or bare.
function unwrapList(res: unknown): Raw[] {
  if (Array.isArray(res)) return res;
  const r = res as Raw;
  return (r?.items ?? r?.data ?? r?.results ?? []) as Raw[];
}

function normalizePolicy(p: Raw): PolicyListItem {
  return {
    ...p,
    addOns: Array.isArray(p.addOns)
      ? p.addOns
      : typeof p.addOns === 'string' && p.addOns.length
        ? p.addOns.split(',').map((s: string) => s.trim())
        : [],
    startDateUtc: p.startDateUtc ?? null,
    endDateUtc: p.endDateUtc ?? null,
  } as PolicyListItem;
}
