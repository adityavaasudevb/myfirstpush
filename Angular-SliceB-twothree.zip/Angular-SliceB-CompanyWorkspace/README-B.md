# Slice B — Company Workspace · Steps B2+B3 (My Quotes · Apply + Pay)

Everything in this zip is shaped to the **real** DTOs you pasted
(ApplyPolicyRequest / ApplyPolicyResponse / PayPolicyResponse / PolicyListItemDto /
PolicyDetailsDto / RenewalResponse + PoliciesController routes). No guessing left.

## 1 · Generate
```
ng g c features/quotes/my-quotes
ng g c features/policies/apply-policy
ng g s core/services/policy
```
Replace the three CLI-generated spec files with the zip versions (they add the
router/http providers). New model file goes at `core/models/policy.model.ts`.

## 2 · Routes
Inside the `companyShell` children in `app.routes.ts`:
```
{ path: 'quotes', component: MyQuotes },
{ path: 'quotes/new', component: NewQuote },
{ path: 'policies/apply', component: ApplyPolicy },
```
(order matters: `quotes` before `quotes/new` is not required, but keep exact paths;
imports: `features/quotes/my-quotes/my-quotes`, `features/policies/apply-policy/apply-policy`)

## 3 · Re-paste
- `features/quotes/new-quote/new-quote.html` — Apply button is now live
  ([routerLink] + [queryParams] quoteId).
- `features/dashboard/company-dashboard/company-dashboard.html` — My quotes card live.
- `core/services/quote.service.ts` if not already on the adapter version.

## 4 · Verify
1. **My Quotes**: login → Workspace → My quotes → all your test estimates listed
   (they were persisted all along), status chips + filters work, Apply only on Active.
2. **From-quote apply**: click Apply on the 25/Tier B/PD+UM quote → summary locked,
   submit → 201 → amber "Pending" + ₹ final premium → **Pay now** → green panel,
   Active, 365-day window.
3. Check My Quotes again → that quote is now **Converted**.
4. `ng test` → all green.
