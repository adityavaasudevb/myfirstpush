import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CompanyProfileService } from '../services/company-profile.service';
import { CompanyProfile } from '../models/company-profile.model';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';

// FR2.2/FR2.3 — the company profile page: view (GET /api/companies/me) and
// edit (PUT /api/companies/{id}). The registration number (CIN) is shown but
// not editable; it is still sent back in the body because the update request
// mirrors the create shape.
@Component({
  selector: 'app-profile',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './profile.html',
  styleUrl: './profile.css',
})
export class Profile {
  private readonly fb = inject(FormBuilder);
  private readonly profiles = inject(CompanyProfileService);
  private readonly alerts = inject(AlertService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly loadError = signal<string | null>(null);
  readonly editing = signal(false);
  readonly busy = signal(false);
  readonly saveError = signal<string | null>(null);

  readonly profile = this.profiles.profile;

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    registrationNo: [{ value: '', disabled: true }],
    contactPerson: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    fleetSize: [1, [Validators.required, Validators.min(1)]],
  });

  constructor() {
    const existing = this.profile();
    if (existing) {
      this.prefill(existing);
      this.loading.set(false);
    } else {
      this.refresh();
    }
  }

  /** Fetch our own profile (deep link / page refresh case). */
  refresh(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.profiles.loadMe().subscribe({
      next: (p) => {
        this.prefill(p);
        this.loading.set(false);
      },
      error: (err) => {
        if (err?.status === 404) {
          // No profile yet — the profile page is meaningless before onboarding.
          this.router.navigateByUrl('/company/onboarding');
          return;
        }
        this.loadError.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  startEdit(): void {
    const p = this.profile();
    if (p) this.prefill(p);
    this.saveError.set(null);
    this.editing.set(true);
  }

  cancelEdit(): void {
    const p = this.profile();
    if (p) this.prefill(p);
    this.saveError.set(null);
    this.editing.set(false);
  }

  save(): void {
    const p = this.profile();
    if (!p || this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.saveError.set(null);

    this.profiles.update(p.id, this.form.getRawValue()).subscribe({
      next: () => {
        this.busy.set(false);
        this.editing.set(false);
        this.alerts.success('Profile updated.');
      },
      error: (err) => {
        this.busy.set(false);
        this.saveError.set(responseErrorText(err));
      },
    });
  }

  private prefill(p: CompanyProfile): void {
    this.form.setValue({
      name: p.name,
      registrationNo: p.registrationNo,
      contactPerson: p.contactPerson,
      email: p.email,
      phone: p.phone,
      fleetSize: p.fleetSize,
    });
  }
}
