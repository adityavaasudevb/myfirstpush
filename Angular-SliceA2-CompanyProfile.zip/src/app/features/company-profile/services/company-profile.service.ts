import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { CompanyProfile, CompanyProfileRequest } from '../models/company-profile.model';
import { environment } from '../../../environments/environment';

const API = environment.apiBaseUrl;

// Company profile state — 404 from /api/companies/me means "no profile yet"
// (fresh registrations) and drives the onboarding redirect.
@Injectable({ providedIn: 'root' })
export class CompanyProfileService {
  private readonly http = inject(HttpClient);
  readonly profile = signal<CompanyProfile | null>(null);

  /** FR2.3 — the caller's own profile (also backs the profile page). */
  loadMe(): Observable<CompanyProfile> {
    return this.http.get<CompanyProfile>(`${API}/companies/me`).pipe(
      tap((p) => this.profile.set(p)),
    );
  }

  /** FR2.1 — one profile per user (409 on duplicates). */
  create(body: CompanyProfileRequest): Observable<CompanyProfile> {
    return this.http.post<CompanyProfile>(`${API}/companies`, body).pipe(
      tap((p) => this.profile.set(p)),
    );
  }

  /** FR2.2 — update own profile; the PUT returns the updated profile.
   *  The server only accepts the caller's own id (403 otherwise). */
  update(id: string, body: CompanyProfileRequest): Observable<CompanyProfile> {
    return this.http.put<CompanyProfile>(`${API}/companies/${id}`, body).pipe(
      tap((p) => this.profile.set(p)),
    );
  }

  clear(): void {
    this.profile.set(null);
  }
}
