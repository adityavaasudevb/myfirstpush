# Slice A2 — Company Profile page (FR2.2 / FR2.3)

Small addendum to Slice A. The onboarding page covered **create**; the FRs
also require the company to **view and update** its profile:

- **FR2.2:** "A company can view and update only its own profile."
- **FR2.3:** "GET /api/companies/me … backs the Angular profile page."

## Why now — Customer API usage audit

| Endpoint | Used before | Used after this pack |
|---|---|---|
| `POST /api/companies` | ✅ onboarding | ✅ |
| `GET /api/companies/me` | ✅ profile guard | ✅ + this page's view mode |
| `GET /api/companies/{id}` | — | — (UI never needs it: own profile always comes via `/me`; the id route exists so the server can 403 cross-tenant reads) |
| `PUT /api/companies/{id}` | ❌ **was unwired** | ✅ this page's edit mode |

## Files

| File | Action |
|---|---|
| `src/app/features/company-profile/services/company-profile.service.ts` | **Replace** (adds `update()`) |
| `src/app/features/company-profile/profile/profile.ts` | **New** |
| `src/app/features/company-profile/profile/profile.html` | **New** |

Scaffold first (creates `profile.css` / spec):

```bash
ng g c features/company-profile/profile
```

## Route

In `app.routes.ts`, inside the `company` children:

```ts
{ path: 'profile', component: Profile, canActivate: [companyProfileGuard] },
```

(with `import { Profile } from './features/company-profile/profile/profile';`)

## Nav link

The **cumulative `app-layout.ts` ships in the Slice D pack** and already
includes `Profile` under the Company menu. If you paste Slice D at the same
time you don't need to touch the layout at all; until then the page is
reachable at `/company/profile`.

## Behaviour

- View mode renders the profile already cached by the guard; on a hard refresh
  it fetches `/me` itself. A `404` (no profile) redirects to onboarding.
- Edit mode pre-fills every field; the CIN is shown disabled but still sent in
  the PUT body (the update request mirrors the create shape; unknown fields
  would be ignored either way).
- Validators match onboarding exactly (10-digit phone, valid email, fleet ≥ 1).
- Success → toast + signal updated, so the dashboard greeting reflects new
  data instantly.
