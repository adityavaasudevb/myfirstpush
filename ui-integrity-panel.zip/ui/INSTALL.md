# v3.4 — complete drop-in: files, paths, commands

Every file below is the **entire** file. Copy, overwrite, build. No searching for a line to edit.

## Final structure

```
src/app/
├── core/
│   ├── models/
│   │   ├── ai-integrity.model.ts              ← existing (panel contract)
│   │   ├── claim-document.model.ts           ★ NEW
│   │   └── claim.model.ts                    ← REPLACED (link now optional)
│   └── services/
│       ├── claims-documents-api.service.ts   ★ NEW
│       └── integrity-api.service.ts           ← existing
├── shared/ui/document-list/
│   ├── document-list.ts                      ★ NEW
│   └── document-list.html                    ★ NEW
└── features/claims/
    ├── file-claim/
    │   ├── file-claim.ts                     ← REPLACED
    │   └── file-claim.html                   ← REPLACED
    ├── claim-details/
    │   ├── claim-details.ts                  ← REPLACED
    │   └── claim-details.html                ← REPLACED
    ├── investigate-claim/
    │   ├── investigate-claim.ts              ← REPLACED (styleUrl removed)
    │   ├── investigate-claim.html            ← REPLACED
    │   ├── integrity-panel.ts                ← existing
    │   └── integrity-panel.html              ← existing
    └── claim-review/
        ├── claim-review.ts                   ← REPLACED
        └── claim-review.html                 ← REPLACED
```

★ = new file. All `src/app/...` paths sit under
`C:\Users\AB13410\dotnet101\TNCInsurance\frontend\tnc-insurance-ui\`.

---

## Order of work

Do the frontend first, then the backend. The backend change is what lets a filing without
a `documentLink` succeed; without it the app builds and then 400s on submit.

### Step 1 — copy the eight changed files and the four new ones

```powershell
cd C:\Users\AB13410\dotnet101\TNCInsurance\frontend\tnc-insurance-ui
$src = "C:\Users\AB13410\Downloads\ui-integrity-panel\ui\src\app"
$app = "src\app"

# new
Copy-Item "$src\core\models\claim-document.model.ts"            "$app\core\models\"          -Force
Copy-Item "$src\core\services\claims-documents-api.service.ts"  "$app\core\services\"        -Force
New-Item -ItemType Directory -Force -Path "$app\shared\ui\document-list" | Out-Null
Copy-Item "$src\shared\ui\document-list\document-list.ts"       "$app\shared\ui\document-list\" -Force
Copy-Item "$src\shared\ui\document-list\document-list.html"     "$app\shared\ui\document-list\" -Force

# replaced
Copy-Item "$src\core\models\claim.model.ts"                     "$app\core\models\"          -Force
Copy-Item "$src\features\claims\file-claim\file-claim.ts"       "$app\features\claims\file-claim\"       -Force
Copy-Item "$src\features\claims\file-claim\file-claim.html"     "$app\features\claims\file-claim\"       -Force
Copy-Item "$src\features\claims\claim-details\claim-details.ts"   "$app\features\claims\claim-details\"   -Force
Copy-Item "$src\features\claims\claim-details\claim-details.html" "$app\features\claims\claim-details\"   -Force
Copy-Item "$src\features\claims\investigate-claim\investigate-claim.ts"   "$app\features\claims\investigate-claim\" -Force
Copy-Item "$src\features\claims\investigate-claim\investigate-claim.html" "$app\features\claims\investigate-claim\" -Force
Copy-Item "$src\features\claims\claim-review\claim-review.ts"    "$app\features\claims\claim-review\"     -Force
Copy-Item "$src\features\claims\claim-review\claim-review.html"  "$app\features\claims\claim-review\"     -Force
```

You do **not** need `ng g c` for `document-list` — `New-Item` above makes the folder, and a
standalone component needs no module registration. There is no `.css` and no `.spec.ts` to
delete.

### Step 2 — confirm nothing references the old CSS

```powershell
Select-String -Path "src\app\features\claims\investigate-claim\investigate-claim.ts" -Pattern "styleUrl"
```

No output. (`claim-details`, `file-claim` and `claim-review` keep their `styleUrl` — those
`.css` files exist and are untouched.)

### Step 3 — build

```powershell
ng build
```

### Step 4 — backend (required)

Follow `BACKEND-EDITS.md`: three lines in `ClaimService.cs` and one in `ClaimDtos.cs`, then
`dotnet build`. Skipping this means every new claim fails with
`Missing required fields: documentLink.`

---

## Verification

### Files landed

```powershell
@(
  "src\app\core\models\claim-document.model.ts",
  "src\app\core\services\claims-documents-api.service.ts",
  "src\app\shared\ui\document-list\document-list.ts",
  "src\app\shared\ui\document-list\document-list.html",
  "src\app\features\claims\file-claim\file-claim.html",
  "src\app\features\claims\claim-details\claim-details.html",
  "src\app\features\claims\investigate-claim\investigate-claim.html",
  "src\app\features\claims\claim-review\claim-review.html"
) | ForEach-Object { "{0,-88} {1}" -f $_, (Test-Path $_) }
```

Eight `True`.

### The bundle link is gone from every screen

```powershell
Select-String -Path "src\app\features\**\*.html" -Pattern "documentLink|document bundle"
```

No output.

### The two components are declared where they are used

```powershell
Select-String -Path "src\app\features\**\*.ts" -Pattern "DocumentList|IntegrityPanel" | Select-Object Filename,Line
```

Expect hits in `claim-details.ts`, `investigate-claim.ts`, `claim-review.ts` — and
`document-list.ts`/`integrity-panel.ts` themselves.

### Live walk-through, in order

| # | Who | Do | Expect |
|---|---|---|---|
| 1 | Company | File a claim, attach 3 PDFs, submit | “Claim submitted”, then “Uploading evidence — 3 file(s) left…” then “A surveyor will pick it up next” |
| 2 | Company | Open the claim | **Evidence documents** shows 3 rows; **Open** renders the PDF in a tab; **Remove** present |
| 3 | Surveyor | Pick up the claim, open it | Same 3 files, **no upload/remove**; panel says *Not checked yet* |
| 4 | Surveyor | Run integrity check | Verdict after 12–30 s; *Documents read (3)* |
| 5 | Admin | Open the same claim | Evidence list + the AI verdict, **no run button** |
| 6 | Company | Reload the claim after pickup | “frozen at surveyor pickup”, no Remove |

---

## What each file does, in one line

| File | Why it changed |
|---|---|
| `claim-document.model.ts` | the `ClaimDocumentDto` shape + type labels + the 5 MB rule |
| `claims-documents-api.service.ts` | list / upload / remove / download against `/api/claims/{id}/documents` |
| `document-list.ts` + `.html` | the shared evidence card; `canUpload` and `editable` decide what the role can do |
| `claim.model.ts` | `documentLink` becomes optional on both interfaces — everything else identical |
| `file-claim.*` | URL box removed; file picker + post-submit upload queue |
| `claim-details.*` | bundle link removed; `<app-document-list canUpload editable>` added |
| `investigate-claim.*` | bundle link removed; `styleUrl` removed; documents list + AI panel added |
| `claim-review.*` | documents list + AI panel (`canRun=false`) added below the two-column grid |
