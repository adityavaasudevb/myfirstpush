// PATH ON YOUR MACHINE: src/app/features/claims/file-claim/file-claim.ts
//
// v3.4: the "Document bundle (link)" URL box is gone. The company picks the actual
// files here and they are uploaded immediately after the claim is created — the only
// moment uploads are legal (FR5.16 freezes evidence at surveyor pickup).

import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PolicyService } from '../../../core/services/policy.service';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimsDocumentsApiService } from '../../../core/services/claims-documents-api.service';
import { PolicyListItem } from '../../../core/models/policy.model';
import {
  CreateClaimRequest,
  CreateClaimResponse,
  TripEventInput,
  CLAIM_TYPES,
  TRIP_EVENT_TYPES,
  TRIP_EVENT_CANONICAL,
} from '../../../core/models/claim.model';
import { CLAIM_DOCUMENT_TYPES, CLAIM_DOCUMENT_LABELS } from '../../../core/models/claim-document.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

interface TripEventForm {
  eventType: string;
  occurredAt: string; // datetime-local value
}

/** A file chosen but not yet uploaded — the claim must exist before it can be attached. */
interface PendingDocument {
  type: string;
  file: File;
}

/** "YYYY-MM-DDTHH:mm" for datetime-local's [max] — caps date pickers at right now
 *  (v3.2: the server also rejects future-dated incidents/events with 400). */
function localNowForInput(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

@Component({
  selector: 'app-file-claim',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe],
  templateUrl: './file-claim.html',
  styleUrl: './file-claim.css',
})
export class FileClaim {
  private readonly fb = inject(FormBuilder);
  private readonly policies = inject(PolicyService);
  private readonly claimsApi = inject(ClaimsApiService);
  private readonly docsApi = inject(ClaimsDocumentsApiService);

  readonly claimTypes = CLAIM_TYPES;
  readonly eventTypes = TRIP_EVENT_TYPES;
  readonly maxNow = localNowForInput();

  readonly documentTypes = CLAIM_DOCUMENT_TYPES;
  readonly docLabel = (t: string) => CLAIM_DOCUMENT_LABELS[t] ?? t;
  /** Which type the next chosen file is filed as. */
  readonly uploadType = signal<string>('RepairEstimate');

  readonly loadingPolicies = signal(true);
  readonly activePolicies = signal<PolicyListItem[]>([]);

  readonly form = this.fb.nonNullable.group({
    policyId: ['', Validators.required],
    driverName: ['', Validators.required],
    driverLicenceNumber: ['', Validators.required],
    vehicleNumber: ['', Validators.required],
    passengerName: ['', Validators.required],
    passengerContact: ['', Validators.required],
    passengerCount: [null as number | null, [Validators.min(1)]],
    additionalPassengersNotes: ['', [Validators.maxLength(500)]],
    incidentAt: ['', Validators.required],
    incidentLocation: ['', Validators.required],
    description: ['', [Validators.required, Validators.minLength(10)]],
    claimedAmountInr: [0, [Validators.required, Validators.min(1)]],
    claimType: ['Third-Party Liability', Validators.required],
    appNotInUseDeclared: [false],
  });

  // v3.2 — preseed the full canonical sequence (FR5.2): the server rejects
  // partial/duplicated/misordered trip logs with 400 ("incomplete trip log").
  readonly events = signal<TripEventForm[]>(
    TRIP_EVENT_CANONICAL.map((eventType) => ({ eventType, occurredAt: '' })),
  );

  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);
  readonly result = signal<CreateClaimResponse | null>(null);

  /** Files chosen before submit; uploaded one by one after the claim exists. */
  readonly pending = signal<PendingDocument[]>([]);
  /** Set only when a file failed after the claim was already created. */
  readonly uploadWarning = signal<string | null>(null);
  readonly uploading = signal(false);

  constructor() {
    this.policies.mine({ status: 'Active' }).subscribe({
      next: (pg) => {
        this.activePolicies.set(pg.items);
        this.loadingPolicies.set(false);
      },
      error: () => this.loadingPolicies.set(false),
    });
  }

  addEvent(): void {
    this.events.update((es) => [...es, { eventType: 'AppOffline', occurredAt: '' }]);
  }

  removeEvent(i: number): void {
    this.events.update((es) => es.filter((_, ix) => ix !== i));
  }

  patchEvent(i: number, patch: Partial<TripEventForm>): void {
    this.events.update((es) => es.map((e, ix) => (ix === i ? { ...e, ...patch } : e)));
  }

  periodChip(period: string): string {
    return period === 'App Off'
      ? 'bg-red-100 text-red-700'
      : 'bg-primary-faint text-primary';
  }

  // ---- documents ----------------------------------------------------------

  onPick(event: Event, picker: HTMLInputElement): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) this.addPending(this.uploadType(), file);
    picker.value = ''; // so picking the same file twice still fires (change)
  }

  addPending(type: string, file: File): void {
    if (file.size > 5 * 1024 * 1024) {
      this.error.set(`“${file.name}” is over 5 MB — that is the per-file limit.`);
      return;
    }
    if (!/\.(pdf|jpe?g|png)$/i.test(file.name)) {
      this.error.set(`“${file.name}” is not a PDF, JPG or PNG.`);
      return;
    }
    this.error.set(null);
    this.pending.update((list) => [...list, { type, file }]);
  }

  dropPending(i: number): void {
    this.pending.update((list) => list.filter((_, idx) => idx !== i));
  }

  /**
   * Uploads the chosen files one at a time, after the claim exists.
   * A failure here must never look like a failed filing: the claim is already
   * created and the message says so, with the claim page as the way to retry.
   */
  private uploadPending(claimId: string): void {
    const queue = [...this.pending()];
    if (queue.length === 0) return;

    this.uploading.set(true);

    const next = (): void => {
      const item = queue.shift();
      if (!item) {
        this.uploading.set(false);
        return;
      }
      this.docsApi.upload(claimId, item.type, item.file).subscribe({
        next: () => {
          this.pending.update((list) => list.filter((x) => x !== item));
          next();
        },
        error: (err) => {
          this.uploading.set(false);
          this.uploadWarning.set(
            `Claim filed, but “${item.file.name}” did not upload: ${responseErrorText(err)} ` +
              `Open the claim to add the rest.`,
          );
        },
      });
    };

    next();
  }

  // ---- submit -------------------------------------------------------------

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    this.error.set(null);
    this.uploadWarning.set(null);
    const v = this.form.getRawValue();
    const tripEvents: TripEventInput[] | null = v.appNotInUseDeclared
      ? null
      : this.events()
          .filter((e) => e.occurredAt)
          .map((e) => ({ eventType: e.eventType, occurredAtUtc: new Date(e.occurredAt).toISOString() }));
    const body: CreateClaimRequest = {
      policyId: v.policyId,
      driverName: v.driverName,
      driverLicenceNumber: v.driverLicenceNumber,
      vehicleNumber: v.vehicleNumber,
      passengerName: v.passengerName,
      passengerContact: v.passengerContact,
      passengerCount: v.passengerCount ?? null,
      additionalPassengersNotes: v.additionalPassengersNotes.trim() || null,
      incidentAtUtc: new Date(v.incidentAt).toISOString(),
      incidentLocation: v.incidentLocation,
      description: v.description,
      claimedAmountInr: Number(v.claimedAmountInr),
      claimType: v.claimType,
      // No documentLink — evidence travels as files (FR5.1 v3.4).
      appNotInUseDeclared: v.appNotInUseDeclared,
      tripEvents,
    };
    this.claimsApi.file(body).subscribe({
      next: (res) => {
        this.result.set(res);
        this.submitting.set(false);
        this.uploadPending(res.claimId);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.submitting.set(false);
      },
    });
  }
}
