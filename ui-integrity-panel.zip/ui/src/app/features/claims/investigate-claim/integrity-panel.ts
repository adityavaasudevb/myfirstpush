// PATH ON YOUR MACHINE: src/app/features/claims/investigate-claim/integrity-panel.ts
import { Component, DestroyRef, inject, input, signal, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize, timer } from 'rxjs';
import { IntegrityApiService } from '../../../core/services/integrity-api.service';
import { AiFinding, AiIntegrityResult } from '../../../core/models/ai-integrity.model';
import { responseErrorText } from '../../../core/services/auth.service';

/**
 * v3.4 — the AI integrity panel.
 *
 * The model reads; the C# engine judges. Everything on this panel is the engine's
 * answer, not a model's opinion, so a failed read is shown as a failed read rather
 * than folded into a weaker verdict.
 *
 * Four states: not checked (204) · running · result · error.
 */
@Component({
  selector: 'app-integrity-panel',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './integrity-panel.html',
})
export class IntegrityPanel implements OnInit {
  private readonly api = inject(IntegrityApiService);
  private readonly destroyRef = inject(DestroyRef);

  /** The claim this panel audits. */
  readonly claimId = input.required<string>();
  /** Only open claims can be checked; anywhere else the API answers 409. */
  readonly claimStatus = input<string>('');
  /** Surveyor (assigned) and Admin may run it. Company may only read the last result. */
  readonly canRun = input(false);

  /** v3.4 — the claim may be read this many times in total (SurveyorLimits.MaxAuditRuns on the server). */
  readonly maxRuns = 2;

  readonly result = signal<AiIntegrityResult | null>(null);
  readonly checked = signal(false);      // a GET has come back (204 or 200)
  readonly running = signal(false);
  readonly elapsed = signal(0);          // whole seconds while a run is in flight
  readonly error = signal<string | null>(null);

  ngOnInit(): void {
    // ngOnInit, not the constructor: input signals are only populated once Angular
    // has run the first change-detection pass.
    this.load();
  }

  load(): void {
    this.api.get(this.claimId()).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (r) => {
        this.result.set(r);
        this.checked.set(true);
      },
      error: () => {
        // The service already maps 204 and transport noise to null; anything that
        // still errors here is a real failure and should be visible.
        this.error.set('Could not read the last check for this claim.');
        this.checked.set(true);
      },
    });
  }

  run(force = false): void {
    if (this.running()) return;
    this.running.set(true);
    this.error.set(null);
    this.elapsed.set(0);

    // The live run takes 12–30s. A silent button looks broken on a projector, so
    // count the seconds on screen.
    const ticker = timer(0, 1000)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((n) => this.elapsed.set(n));

    this.api
      .run(this.claimId(), force)
      .pipe(
        finalize(() => {
          this.running.set(false);
          ticker.unsubscribe();
        }),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe({
        next: (r) => {
          this.result.set(r);
          this.checked.set(true);
        },
        error: (err) => this.error.set(responseErrorText(err)),
      });
  }

  // ---- display helpers -------------------------------------------------

  /**
   * v3.4 — the server counts completed runs and refuses a third one. The result payload does
   * not carry that count, so the panel cannot know it before a run is attempted; it says so
   * rather than guessing. When the cap is hit the POST returns 409 and the message below the
   * button explains why (see the error state).
   */
  runsLeft(): number {
    return this.result() ? 1 : this.maxRuns;
  }

  /** The button stays available; the server is the authority on the cap. */
  runsExhausted(): boolean {
    return false;
  }

  isOpen(): boolean {
    const s = this.claimStatus();
    return s === 'AwaitingSurveyorPickup' || s === 'UnderInvestigation';
  }

  verdictChip(v: string): string {
    switch (v) {
      case 'Consistent': return 'bg-green-100 text-green-800';
      case 'NeedsReview': return 'bg-amber-100 text-amber-800';
      case 'Inconsistent': return 'bg-red-100 text-red-700';
      default: return 'bg-warm-light text-ink-soft';
    }
  }

  verdictLine(v: string): string {
    switch (v) {
      case 'Consistent': return 'Every document reconciles with the claim and with each other.';
      case 'NeedsReview': return 'One point needs a surveyor’s eye before a decision.';
      case 'Inconsistent': return 'Several points in the paperwork do not reconcile with the claim.';
      default: return '';
    }
  }

  severityClass(s: string): string {
    return s === 'Warn'
      ? 'border-amber-200 bg-amber-50 text-amber-900'
      : 'border-warm bg-warm-lightest text-ink-soft';
  }

  severityBadge(s: string): string {
    return s === 'Warn' ? 'bg-amber-200 text-amber-900' : 'bg-warm-light text-ink-soft';
  }

  /** WARN_VEHICLE ... → "Vehicle mismatch" — readable without a lookup table. */
  prettyCode(code: string): string {
    const words = code.toLowerCase().replaceAll('_', ' ');
    return words.charAt(0).toUpperCase() + words.slice(1);
  }

  warnCount(list: AiFinding[]): number {
    return list.filter((f) => f.severity === 'Warn').length;
  }

  docStatusChip(status: string): string {
    return status === 'Completed'
      ? 'bg-green-100 text-green-800'
      : 'bg-red-100 text-red-700';
  }

  docStatusText(status: string): string {
    return status === 'Completed' ? 'read' : 'could not be read';
  }

  seconds(n: number): string {
    return `${n}s`;
  }

  /** Rupees with two decimals — the panel shows the engine's own figures verbatim. */
  costText(v: number | null | undefined): string {
    if (v == null) return '—';
    return '₹' + v.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  /** True when at least one attached document produced no reading at all. */
  unreadable(docs: { status: string }[]): boolean {
    return docs.some((d) => d.status !== 'Completed');
  }

  fmtTime(iso: string): string {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    return `${d.toLocaleDateString('en-GB').replaceAll('/', '-')} ${d.toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
    })}`;
  }
}
