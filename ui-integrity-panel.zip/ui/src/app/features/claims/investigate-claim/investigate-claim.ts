// PATH ON YOUR MACHINE: src/app/features/claims/investigate-claim/investigate-claim.ts
//
// v3.4: `styleUrl` removed (there is no .css — everything is Tailwind), and the page
// now hosts <app-document-list> (the evidence, read-only) directly above
// <app-integrity-panel> (what the model read of those very files).

import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimDetails, SubmitReportRequest } from '../../../core/models/claim.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { DocumentList } from '../../../shared/ui/document-list/document-list';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';
import { IntegrityPanel } from './integrity-panel';

@Component({
  selector: 'app-investigate-claim',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe, DocumentList, IntegrityPanel],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './investigate-claim.html',
})
export class InvestigateClaim {
  private readonly fb = inject(FormBuilder);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly claimsApi = inject(ClaimsApiService);
  private readonly alerts = inject(AlertService);

  private readonly id = this.route.snapshot.paramMap.get('id')!;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly claim = signal<ClaimDetails | null>(null);

  /** Per-field draft note (keyed by fieldName). */
  readonly notes: Record<string, string | undefined> = {};
  readonly verifying = signal<string | null>(null);

  readonly reportForm = this.fb.nonNullable.group({
    overallOutcome: ['Genuine', Validators.required],
    recommendation: ['Approve', Validators.required],
    recommendedAmountInr: [null as number | null],
    notes: ['', [Validators.required, Validators.minLength(10)]],
  });

  readonly submittingReport = signal(false);
  readonly reportError = signal<string | null>(null);

  /** FR5.18 (v3.2) — release back to the open queue. Only viable while the claim
   *  is still UnderInvestigation with no report submitted (after the report, the
   *  assignment is final and release would 409 anyway). */
  readonly releasing = signal(false);
  readonly releaseError = signal<string | null>(null);

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.claimsApi.get(this.id).subscribe({
      next: (c) => {
        this.claim.set(c);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  /** True only while release is legal: still UnderInvestigation, no report yet. */
  canRelease(): boolean {
    const c = this.claim();
    return !!c && c.status === 'UnderInvestigation' && !c.report;
  }

  /** FR5.18 (v3.2) — returns the claim to the open queue; partial field checks are
   *  discarded server-side and recreated for the next surveyor. */
  release(): void {
    if (!this.canRelease()) return;
    this.releasing.set(true);
    this.releaseError.set(null);
    this.claimsApi.release(this.id).subscribe({
      next: () => {
        this.alerts.success('Claim released back to the open queue.');
        this.router.navigate(['/surveyor/assigned']);
      },
      error: (err) => {
        this.releasing.set(false);
        this.releaseError.set(responseErrorText(err)); // e.g. 409 after a report was submitted
      },
    });
  }

  /** True once every field-verification is out of Pending. */
  allFieldsDone(): boolean {
    const c = this.claim();
    return !!c && c.fieldVerifications.length > 0 && c.fieldVerifications.every((f) => f.status !== 'Pending');
  }

  pendingCount(): number {
    return (this.claim()?.fieldVerifications ?? []).filter((f) => f.status === 'Pending').length;
  }

  verify(fieldName: string, status: 'Verified' | 'Suspicious'): void {
    this.verifying.set(fieldName);
    this.claimsApi
      .verifyField(this.id, { fieldName, status, note: this.notes[fieldName]?.trim() || null })
      .subscribe({
        next: () => {
          this.verifying.set(null);
          this.reload();
        },
        error: (err) => {
          this.verifying.set(null);
          this.alerts.error(responseErrorText(err));
        },
      });
  }

  submitReport(): void {
    if (this.reportForm.invalid) {
      this.reportForm.markAllAsTouched();
      return;
    }
    this.submittingReport.set(true);
    this.reportError.set(null);
    const v = this.reportForm.getRawValue();
    const body: SubmitReportRequest = {
      overallOutcome: v.overallOutcome,
      recommendation: v.recommendation,
      recommendedAmountInr:
        v.recommendation === 'Approve' && v.recommendedAmountInr != null
          ? Number(v.recommendedAmountInr)
          : null,
      notes: v.notes,
    };
    this.claimsApi.submitReport(this.id, body).subscribe({
      next: () => {
        this.alerts.success('Report submitted.');
        this.router.navigate(['/surveyor/assigned']);
      },
      error: (err) => {
        this.submittingReport.set(false);
        this.reportError.set(responseErrorText(err)); // e.g. 409 while fields pending
      },
    });
  }

  // ---- display helpers ----

  pretty(s: string): string {
    return s.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  fieldLabel(name: string): string {
    switch (name) {
      case 'DriverInfo': return 'Driver information';
      case 'PassengerInfo': return 'Passenger information';
      case 'TripEventLog': return 'Trip event log';
      case 'Documents': return 'Documents';
      default: return this.pretty(name);
    }
  }

  verificationChip(status: string): string {
    switch (status) {
      case 'Verified': return 'bg-green-100 text-green-800';
      case 'Suspicious': return 'bg-red-100 text-red-700';
      default: return 'bg-warm-light text-ink-soft';
    }
  }

  statusChip(status: string): string {
    switch (status) {
      case 'UnderInvestigation': return 'bg-blue-100 text-blue-800';
      case 'SurveyorReportSubmitted': return 'bg-amber-100 text-amber-800';
      case 'Paid': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-warm-light text-ink-soft';
    }
  }

  periodChip(period: string): string {
    return period === 'App Off' ? 'bg-red-100 text-red-700' : 'bg-primary-faint text-primary';
  }

  fmtTime(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime())
      ? '—'
      : `${d.toLocaleDateString('en-GB').replaceAll('/', '-')} ${d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
  }
}
