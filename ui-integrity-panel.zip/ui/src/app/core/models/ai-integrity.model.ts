// PATH ON YOUR MACHINE: src/app/core/models/ai-integrity.model.ts
//
// Contract for GET/POST /api/claims/{id}/integrity — mirrors ClaimAuditResult in C#.
// camelCase JSON. `findings` is always an array (empty on a clean claim), never null.

export type AiSeverity = 'Warn' | 'Info';

export interface AiFinding {
  code: string;
  severity: AiSeverity | string;
  documentId: string | null;
  message: string;
  claimValue: string | null;
  documentValue: string | null;
  evidence: string | null;
}

/** One document as the auditor saw it. Only the fields the panel renders. */
export interface AiDocumentAudit {
  documentId: string;
  documentType: string;
  fileName: string;
  /** Completed | Failed | Unavailable */
  status: string;
  extracted: { confidence?: string | null; readAsImage?: boolean } | null;
  findings: AiFinding[];
  errorMessage: string | null;
}

export interface AiIntegrityResult {
  schemaVersion: string;
  claimId: string;
  claimNumber: string;
  /** Consistent | NeedsReview | Inconsistent */
  verdict: string;
  summary: string;
  findings: AiFinding[];
  documents: AiDocumentAudit[];
  model: string | null;
  offline: boolean;
  modelCallsMade: number;
  promptTokens: number;
  outputTokens: number;
  /** Estimate in rupees, not a bill. */
  estimatedCostInr: number;
  durationMs: number;
  generatedAtUtc: string;
}
