// PATH ON YOUR MACHINE: src/app/core/models/claim-document.model.ts

/** Canonical document types — mirrors ClaimDocumentTypes in the backend. */
export const CLAIM_DOCUMENT_TYPES = [
  'FIR',
  'RepairEstimate',
  'MedicalBill',
  'RentalInvoice',
  'Other',
] as const;

export type ClaimDocumentType = (typeof CLAIM_DOCUMENT_TYPES)[number];

/** Display labels, identical to ClaimDocumentTypes.Labels on the server. */
export const CLAIM_DOCUMENT_LABELS: Record<string, string> = {
  FIR: 'FIR / police report',
  RepairEstimate: 'Repair estimate',
  MedicalBill: 'Medical bill',
  RentalInvoice: 'Rental invoice',
  Other: 'Other (photos, etc.)',
};

/** ClaimDocumentDto — GET/POST api/claims/{claimId}/documents */
export interface ClaimDocument {
  id: string;
  claimId: string;
  documentType: string;
  originalFileName: string;
  contentType: string;
  sizeBytes: number;
  uploadedAtUtc: string;
  /** null = never read by the AI. Processing | Completed | Failed | Unavailable */
  aiStatus: string | null;
  aiModel: string | null;
  aiReviewedAtUtc: string | null;
}

/** FR5.1 — at most 5 MB, PDF/JPG/PNG, at most 10 per claim. */
export const MAX_DOCUMENT_BYTES = 5 * 1024 * 1024;

/** FR5.16 — evidence freezes the moment a surveyor picks the claim up. */
export function documentsEditable(claimStatus: string): boolean {
  return claimStatus === 'AwaitingSurveyorPickup';
}
