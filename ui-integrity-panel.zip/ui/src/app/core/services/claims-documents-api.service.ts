// PATH ON YOUR MACHINE: src/app/core/services/claims-documents-api.service.ts
//
// Separate from ClaimsApiService on purpose: the four document routes are their own
// controller (ClaimDocumentsController), and keeping them here means a broken upload
// can never take the claim read paths down with it.
//
// All four go through the gateway because every path starts /api/claims/... and the
// gateway forwards /api/claims/{**rest} to the insurance cluster.

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ClaimDocument, MAX_DOCUMENT_BYTES } from '../models/claim-document.model';

const API = environment.apiBaseUrl;

@Injectable({ providedIn: 'root' })
export class ClaimsDocumentsApiService {
  private readonly http = inject(HttpClient);

  /** FR5.17 — the claim's evidence. Company (own), assigned Surveyor, Admin. */
  list(claimId: string): Observable<ClaimDocument[]> {
    return this.http.get<ClaimDocument[]>(`${API}/claims/${claimId}/documents`);
  }

  /** FR5.1 / FR5.16 — Company only, and only before pickup. 409 once frozen. */
  upload(claimId: string, documentType: string, file: File): Observable<ClaimDocument> {
    if (file.size > MAX_DOCUMENT_BYTES) {
      throw new Error(`“${file.name}” is ${(file.size / 1024 / 1024).toFixed(1)} MB — the limit is 5 MB.`);
    }
    const body = new FormData();
    body.append('documentType', documentType);
    body.append('file', file, file.name);
    return this.http.post<ClaimDocument>(`${API}/claims/${claimId}/documents`, body);
  }

  /** Remove evidence before pickup (Company/Admin). */
  remove(claimId: string, documentId: string): Observable<void> {
    return this.http.delete<void>(`${API}/claims/${claimId}/documents/${documentId}`);
  }

  /** Streams the PDF for viewing — the auth token rides on the interceptor, not the URL. */
  download(claimId: string, documentId: string): Observable<Blob> {
    return this.http
      .get(`${API}/claims/${claimId}/documents/${documentId}`, { responseType: 'blob' })
      .pipe(map((b) => b as Blob));
  }
}
