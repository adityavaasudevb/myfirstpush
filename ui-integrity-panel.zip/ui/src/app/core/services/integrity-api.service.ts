// PATH ON YOUR MACHINE: src/app/core/services/integrity-api.service.ts
//
// Two routes, both nested under the claim (ClaimAuditController):
//   POST /api/claims/{id}/integrity            run it   (Surveyor assigned / Admin)
//   GET  /api/claims/{id}/integrity            read it  (Company / Surveyor / Admin)
//
// GET returns 204 No Content when the audit has never run. That is a normal
// answer, not an error: the panel renders it as "Not checked".

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, map, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AiIntegrityResult } from '../models/ai-integrity.model';

const API = environment.apiBaseUrl;

@Injectable({ providedIn: 'root' })
export class IntegrityApiService {
  private readonly http = inject(HttpClient);

  /** The stored result, or null when nothing has been run for this claim. */
  get(claimId: string): Observable<AiIntegrityResult | null> {
    return this.http.get<AiIntegrityResult | null>(`${API}/claims/${claimId}/integrity`).pipe(
      map((res) => res ?? null),
      // A 204 arrives here as a null body in most setups, but some gateways surface it as an
      // empty-string parse error. Either way "no audit yet" must not throw.
      catchError(() => of(null)),
    );
  }

  /** Run it (or return the cached run unless force = true). Costs money when it re-reads. */
  run(claimId: string, force = false): Observable<AiIntegrityResult> {
    const url = force
      ? `${API}/claims/${claimId}/integrity?force=true`
      : `${API}/claims/${claimId}/integrity`;
    return this.http.post<AiIntegrityResult>(url, {});
  }
}
