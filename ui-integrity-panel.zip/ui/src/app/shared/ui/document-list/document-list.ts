// PATH ON YOUR MACHINE: src/app/shared/ui/document-list/document-list.ts
import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  OnInit,
  inject,
  input,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { finalize } from 'rxjs';
import { ClaimsDocumentsApiService } from '../../../core/services/claims-documents-api.service';
import {
  ClaimDocument,
  CLAIM_DOCUMENT_LABELS,
  CLAIM_DOCUMENT_TYPES,
} from '../../../core/models/claim-document.model';
import { responseErrorText } from '../../../core/services/auth.service';

/**
 * v3.4 — the claim's evidence, as files.
 *
 * This is the list the "Document bundle" link was standing in for. It renders in three
 * places: the company's claim page (with upload), the surveyor's investigate page
 * (read only, directly above the AI panel that audits these same files), and the admin
 * review page (read only).
 *
 * Nothing here is invented: every row is a ClaimDocument row from the server.
 */
@Component({
  selector: 'app-document-list',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './document-list.html',
})
export class DocumentList implements OnInit {
  private readonly api = inject(ClaimsDocumentsApiService);
  private readonly destroyRef = inject(DestroyRef);

  readonly claimId = input.required<string>();
  /** Company sees the upload control; surveyor and admin do not (the server enforces it too). */
  readonly canUpload = input(false);
  /** FR5.16 — false once a surveyor has picked the claim up. */
  readonly editable = input(false);

  readonly documents = signal<ClaimDocument[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly busy = signal(false);
  /** Which type the next chosen file is filed as. */
  readonly uploadType = signal<string>(CLAIM_DOCUMENT_TYPES[1]); // RepairEstimate
  readonly documentTypes = CLAIM_DOCUMENT_TYPES;

  ngOnInit(): void {
    this.reload();
  }

  label(type: string): string {
    return CLAIM_DOCUMENT_LABELS[type] ?? type;
  }

  size(bytes: number): string {
    return bytes < 1024 * 1024
      ? `${Math.max(1, Math.round(bytes / 1024))} KB`
      : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api
      .list(this.claimId())
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.loading.set(false)),
      )
      .subscribe({
        next: (docs) => this.documents.set(docs),
        error: (err) => this.error.set(responseErrorText(err)),
      });
  }

  open(d: ClaimDocument): void {
    this.error.set(null);
    this.api
      .download(this.claimId(), d.id)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (blob) => {
          // Object URL, opened in place: the token never reaches the address bar.
          const url = URL.createObjectURL(blob);
          window.open(url, '_blank', 'noopener');
          setTimeout(() => URL.revokeObjectURL(url), 30_000);
        },
        error: (err) => this.error.set(responseErrorText(err)),
      });
  }

  onFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    // The server sniffs magic bytes and would reject these anyway; failing here keeps
    // the 15-second round trip out of the way of a mistyped filename.
    if (!/\.(pdf|jpe?g|png)$/i.test(file.name)) {
      this.error.set(`“${file.name}” is not a PDF, JPG or PNG.`);
      input.value = '';
      return;
    }

    this.busy.set(true);
    this.error.set(null);
    this.api
      .upload(this.claimId(), this.uploadType(), file)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.busy.set(false);
          input.value = ''; // choosing the same file twice must still fire (change)
        }),
      )
      .subscribe({
        next: () => this.reload(),
        error: (err) => this.error.set(responseErrorText(err)),
      });
  }

  remove(d: ClaimDocument): void {
    if (!this.editable()) return;
    this.busy.set(true);
    this.error.set(null);
    this.api
      .remove(this.claimId(), d.id)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.busy.set(false)),
      )
      .subscribe({
        next: () => this.reload(),
        error: (err) => this.error.set(responseErrorText(err)),
      });
  }
}
