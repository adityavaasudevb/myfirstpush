# Commands: create the AI panel files and wire them in

Angular 21, standalone components, Tailwind only. Every command below is PowerShell
and runs **from your Angular project root** — the folder that contains `src\app`, `angular.json`
and `package.json`.

```powershell
cd C:\path\to\your\frontend
dir angular.json     # must exist. If not, cd into the right folder first.
```

Set two variables once, in the same PowerShell window, and the rest of the commands work
unchanged:

```powershell
$src = "C:\Users\AB13410\Downloads\ui-integrity-panel\ui\src\app"
$app = "src\app"
```

---

## Step 1 — create the two files that need a new folder path

`core\models` and `core\services` already exist. This just copies into them.

```powershell
Copy-Item "$src\core\models\ai-integrity.model.ts"        "$app\core\models\"      -Force
Copy-Item "$src\core\services\integrity-api.service.ts"   "$app\core\services\"    -Force
```

`money-pipe.ts` is **no longer needed** — the panel formats its own numbers, so your
existing shared pipe stays exactly as it is.

Verify:

```powershell
Test-Path "$app\core\models\ai-integrity.model.ts"       # True
Test-Path "$app\core\services\integrity-api.service.ts"  # True
```

---

## Step 2 — create the panel component

Use the CLI so the folder and selector are registered the Angular way, then overwrite the two
generated files. The generated `.css` is deleted, because you use Tailwind.

```powershell
ng g c features/claims/investigate-claim/integrity-panel --skip-tests
```

That prints something like `CREATE src/app/features/claims/investigate-claim/integrity-panel.ts`
(and `.html` / `.css` / `.spec.ts` depending on your `ng` version). Now overwrite:

```powershell
Copy-Item "$src\features\claims\investigate-claim\integrity-panel.ts"   "$app\features\claims\investigate-claim\" -Force
Copy-Item "$src\features\claims\investigate-claim\integrity-panel.html" "$app\features\claims\investigate-claim\" -Force
```

Delete the generated stylesheet and spec — the panel has no CSS file and no spec:

```powershell
Remove-Item "$app\features\claims\investigate-claim\integrity-panel.css"  -ErrorAction SilentlyContinue
Remove-Item "$app\features\claims\investigate-claim\integrity-panel.spec.ts" -ErrorAction SilentlyContinue
```

> **If `ng g c` writes `integrity-panel.ts` with a `styleUrl` line**, the copy in Step 2 replaces the
> whole file, so it disappears. Nothing else to do.

---

## Step 3 — delete the missing stylesheet from the investigate page

`investigate-claim.ts` declares `styleUrl: './investigate-claim.css'`, and that file does not exist,
so the build fails before anything else. Remove the line.

Open `src\app\features\claims\investigate-claim\investigate-claim.ts` and delete this line from the
`@Component` decorator:

```ts
  styleUrl: './investigate-claim.css',
```

The decorator should end up as:

```ts
@Component({
  selector: 'app-investigate-claim',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './investigate-claim.html',
})
```

Find it quickly:

```powershell
Select-String -Path "$app\features\claims\investigate-claim\investigate-claim.ts" -Pattern "styleUrl"
```

---

## Step 4 — register the panel in `investigate-claim.ts`

Two edits, both in the same file.

**(a)** Add the import next to the other feature imports:

```powershell
Select-String -Path "$app\features\claims\investigate-claim\investigate-claim.ts" -Pattern "^import"
```

Add one more line under them:

```ts
import { IntegrityPanel } from './integrity-panel';
```

**(b)** Add `IntegrityPanel` to the `imports` array in the decorator:

```ts
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe, IntegrityPanel],
```

---

## Step 5 — put the panel on the page

Open `src\app\features\claims\investigate-claim\investigate-claim.html`.

Find the **App trip log** card — it starts with this comment:

```html
        <!-- Trip log -->
        <div class="card p-5">
```

Its closing `</div>` is immediately followed by the report card:

```html
        <!-- Report (read view) -->
```

Insert **between** them:

```html
        <!-- AI document check (v3.4) -->
        <app-integrity-panel
          [claimId]="c.id"
          [claimStatus]="c.status"
          [canRun]="true" />
```

`c` is the `@else if (claim(); as c)` alias already used throughout that file, so nothing else
needs to change.

---

## Step 6 — build

```powershell
ng build
```

or, faster while you are iterating:

```powershell
ng serve
```

Errors you are likely to see, and what they mean:

| Error | Cause |
|---|---|
| `Could not resolve './investigate-claim.css'` | Step 3 not done |
| `'app-integrity-panel' is not a known element` | Step 4(b) not done — not in `imports` |
| `Cannot find module './integrity-panel'` | Step 2 copy went to the wrong folder |
| `Cannot find module '../../../core/services/auth.service'` | your project keeps `auth.service.ts` elsewhere — check where `investigate-claim.ts` imports it from and match that path |

---

## Step 7 — test it without touching the demo claim

1. Log in as an **approved surveyor**.
2. Pick up a claim; open it. The panel should say **Not checked yet** with a **Run integrity check**
   button.
3. Press it. The spinner counts seconds. Expect **12–30 seconds** on a live Vertex run.
4. You should get a verdict chip, a summary line, a **Documents read** list and the findings.
5. Press **Re-run and re-read** — this time it is instant, costs 0, and the timestamp changes.

If the panel shows **Not checked yet** after a run that returned 200, the GET is being called
before the POST persists — check the API log for the actual response body.

---

## Step 8 — the config the backend needs

`src\InsuranceService\InsuranceService.API\appsettings.json`, inside the root object:

```json
  "Ai": {
    "Provider": "vertex",
    "ProjectId": "higsbx-indintq326sbx",
    "Location": "global",
    "Model": "gemini-3.8-flash",
    "TimeoutSeconds": 60,
    "MaxOutputTokens": 4000,
    "AuditThresholdInr": 10000,
    "MaxCallsPerClaim": 6,
    "MaxCallsPerDay": 50,
    "InputPricePerMillionInr": 65,
    "OutputPricePerMillionInr": 330
  }
```

To fall back to recordings for the demo, change only the first line to `"Provider": "fake"` and add:

```json
    "RecordedDir": "recorded",
```

with the 11 JSON files copied to `bin\Debug\net8.0\recorded\`.

---

## One command to check everything landed

```powershell
@(
  "$app\core\models\ai-integrity.model.ts",
  "$app\core\services\integrity-api.service.ts",
  "$app\features\claims\investigate-claim\integrity-panel.ts",
  "$app\features\claims\investigate-claim\integrity-panel.html"
) | ForEach-Object { "{0,-95} {1}" -f $_, (Test-Path $_) }
```

All four must print `True`. Then confirm the two edits:

```powershell
Select-String -Path "$app\features\claims\investigate-claim\investigate-claim.ts" -Pattern "IntegrityPanel|styleUrl"
Select-String -Path "$app\features\claims\investigate-claim\investigate-claim.html" -Pattern "app-integrity-panel"
```

Expected: two hits for `IntegrityPanel`, **zero** for `styleUrl`, one for `app-integrity-panel`.
