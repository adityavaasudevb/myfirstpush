# v3.4 — Evidence documents + AI panel for three roles

The story, in one sentence: **a claim carries its evidence; the surveyor opens that evidence and runs the check on it; the admin reads the result but cannot spend money on it.**

Before this, the evidence was a pasted URL (`documentLink`) and the AI panel read hidden files. Two sources of truth, two stories. This closes that.

## What changes where

| Screen | File | Change |
|---|---|---|
| Company — file claim | `features/claims/file-claim/file-claim.ts` | capture the `File[]`; upload after filing |
| Company — file claim | `features/claims/file-claim/file-claim.html` | replace the URL box with a file picker; upload on the success card |
| Company — claim page | `features/claims/claim-details/claim-details.html` | replace the bundle link with `<app-document-list>` (upload allowed) |
| Surveyor | `features/claims/investigate-claim/investigate-claim.html` | replace the bundle link; add `<app-document-list>` + `<app-integrity-panel>` |
| Admin | `features/claims/claim-review/claim-review.html` | add `<app-integrity-panel [canRun]="false">` |

`documentLink` **stays in the database and the DTO**. It is no longer collected or displayed, so it holds its old value and nothing breaks. That is the (a) decision.

---

## Step 1 — copy the three new files

```powershell
$src = "C:\Users\AB13410\Downloads\ui-integrity-panel\ui\src\app"
$app = "src\app"

# already there from the last round — harmless to repeat
Copy-Item "$src\core\models\ai-integrity.model.ts"        "$app\core\models\"      -Force
Copy-Item "$src\core\services\integrity-api.service.ts"   "$app\core\services\"    -Force

# new this round
Copy-Item "$src\core\models\claim-document.model.ts"        "$app\core\models\"      -Force
Copy-Item "$src\core\services\claims-documents-api.service.ts" "$app\core\services\" -Force

# the shared list component
ng g c shared/ui/document-list --skip-tests
Copy-Item "$src\shared\ui\document-list\document-list.ts"   "$app\shared\ui\document-list\" -Force
Copy-Item "$src\shared\ui\document-list\document-list.html" "$app\shared\ui\document-list\" -Force
Remove-Item "$app\shared\ui\document-list\document-list.css"     -ErrorAction SilentlyContinue
Remove-Item "$app\shared\ui\document-list\document-list.spec.ts" -ErrorAction SilentlyContinue
```

`ng g c` will also add a `styleUrl` line to the generated `.ts` — but we overwrite that file, so it disappears with the overwrite. Nothing to fix.

---

## Step 2 — company: file claim with files

### 2a. `file-claim.ts`

**Replace** `documentLink: ['', Validators.required],` with nothing (delete that line from the form group).

Add above `submit()`:

```ts
  /** FR5.1 (amended v3.4) — evidence is uploaded as files, at filing time only. */
  readonly pending = signal<{ type: string; file: File }[]>([]);
  private pendingClaimId: string | null = null;
  readonly uploadWarning = signal<string | null>(null);

  addPending(type: string, file: File): void {
    if (file.size > 5 * 1024 * 1024) {
      this.error.set(`“${file.name}” is over 5 MB.`);
      return;
    }
    this.pending.update((list) => [...list, { type, file }]);
  }

  dropPending(i: number): void {
    this.pending.update((list) => list.filter((_, idx) => idx !== i));
  }
```

In `submit()`, **delete** the line `documentLink: v.documentLink,` from `body`.

Then change the `next` handler so the files follow the claim:

```ts
      next: (res) => {
        this.result.set(res);
        this.pendingClaimId = res.claimId;
        this.uploadPending(res.claimId);
        this.submitting.set(false);
      },
```

And add this method:

```ts
  /** Uploads the chosen files one at a time. A failed upload never loses the claim. */
  private uploadPending(claimId: string): void {
    const queue = [...this.pending()];
    if (queue.length === 0) return;

    const next = (): void => {
      const item = queue.shift();
      if (!item) return;
      this.docsApi.upload(claimId, item.type, item.file).subscribe({
        next: () => {
          this.pending.update((l) => l.filter((x) => x !== item));
          next();
        },
        error: (err) => {
          // The claim exists; only this file failed. Say so and let them retry from the claim page.
          this.uploadWarning.set(
            `Claim filed, but “${item.file.name}” did not upload: ${responseErrorText(err)} ` +
            `Open the claim to add it.`,
          );
        },
      });
    };
    next();
  }
```

Add the service + imports at the top:

```ts
import { ClaimsDocumentsApiService } from '../../../core/services/claims-documents-api.service';
import { CLAIM_DOCUMENT_TYPES, CLAIM_DOCUMENT_LABELS } from '../../../core/models/claim-document.model';
```

and inside the class:

```ts
  private readonly docsApi = inject(ClaimsDocumentsApiService);
  readonly documentTypes = CLAIM_DOCUMENT_TYPES;
  readonly docLabel = (t: string) => CLAIM_DOCUMENT_LABELS[t] ?? t;
  readonly uploadType = signal<string>('RepairEstimate');
```

### 2b. `file-claim.html`

**Delete** the whole block:

```html
        <div>
          <label class="label" for="doc-link">Document bundle (link)</label>
          <input id="doc-link" type="url" class="input" formControlName="documentLink" placeholder="https://…" />
        </div>
```

**Add** this card just above the closing `</form>`:

```html
      <!-- FR5.1 (v3.4) — evidence files, uploaded right after the claim is filed -->
      <div class="card space-y-3 p-6">
        <h2 class="text-sm font-bold uppercase tracking-wide text-ink-soft">
          Evidence documents
        </h2>
        <p class="text-xs text-ink-soft">
          Attach the FIR, the repair estimate and the tow receipt. PDF, JPG or PNG, up to 5 MB each.
          Once a surveyor picks the claim up, the evidence is frozen (FR5.16).
        </p>

        <div class="flex flex-wrap items-center gap-2">
          <select class="input !w-auto !py-1.5 text-xs" [value]="uploadType()"
                  (change)="uploadType.set($any($event.target).value)">
            @for (t of documentTypes; track t) {
              <option [value]="t">{{ docLabel(t) }}</option>
            }
          </select>
          <input #picker type="file" class="hidden" accept=".pdf,.jpg,.jpeg,.png"
                 (change)="onPick($event, picker)" />
          <button type="button" class="btn-outline !py-1.5 text-xs" (click)="picker.click()">
            Choose file
          </button>
        </div>

        @if (pending().length > 0) {
          <ul class="space-y-1.5">
            @for (p of pending(); track $index) {
              <li class="flex items-center gap-2 rounded-xl border border-warm px-3 py-1.5">
                <span class="min-w-0 flex-1 truncate text-xs font-medium text-ink">{{ p.file.name }}</span>
                <span class="shrink-0 rounded-full bg-warm-lightest px-2 py-0.5 text-[10px] font-semibold text-ink-soft">
                  {{ docLabel(p.type) }}
                </span>
                <button type="button" class="shrink-0 text-[11px] font-semibold text-danger hover:underline"
                        (click)="dropPending($index)">Remove</button>
              </li>
            }
          </ul>
        }
      </div>
```

Add `onPick` to the class:

```ts
  onPick(event: Event, picker: HTMLInputElement): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) this.addPending(this.uploadType(), file);
    picker.value = '';
  }
```

On the success card, after the “surveyor will pick it up next” paragraph, add:

```html
      @if (pending().length > 0) {
        <p class="mt-3 text-sm font-medium text-ink">Uploading {{ pending().length }} file(s)…</p>
      }
      @if (uploadWarning(); as w) {
        <p class="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-900">{{ w }}</p>
      }
```

And change “A surveyor will pick it up next” to render only when nothing is pending:

```html
      @if (pending().length === 0 && !uploadWarning()) {
        <p class="mt-4 text-sm text-ink-soft">A surveyor will pick it up next — track every step on the claim page.</p>
      }
```

---

## Step 3 — company: the claim page shows the files

### 3a. `claim-details.html`

**Delete** the line (line 58):

```html
            <div><dt class="text-ink-soft">Documents</dt><dd><a class="font-medium text-primary underline underline-offset-2" [href]="c.documentLink" target="_blank" rel="noopener">Open document bundle ↗</a></dd></div>
```

**Add**, inside the same `space-y-*` column, right after the App trip log card:

```html
        <app-document-list
          [claimId]="c.id"
          [canUpload]="true"
          [editable]="c.status === 'AwaitingSurveyorPickup'" />
```

### 3b. `claim-details.ts`

The claim page is at `src/app/features/claims/claim-details/`, so the shared component
three folders up and across:

```ts
import { DocumentList } from '../../../shared/ui/document-list/document-list';
```

Add `DocumentList` to the `imports` array.

---

## Step 4 — surveyor: documents above the AI panel

### 4a. `investigate-claim.html`

**Delete** the same `Documents` line (line 49 in this file).

**Add**, inside `<div class="space-y-4">`, directly after the App trip log card and before the report block:

```html
        <app-document-list [claimId]="c.id" />

        <app-integrity-panel
          [claimId]="c.id"
          [claimStatus]="c.status"
          [canRun]="true" />
```

### 4b. `investigate-claim.ts`

- delete `styleUrl: './investigate-claim.css',` if it is still there
- add:

```ts
import { DocumentList } from '../../../shared/ui/document-list/document-list';
import { IntegrityPanel } from './integrity-panel';
```

- add `DocumentList, IntegrityPanel` to `imports`

`IntegrityPanel` is the only one of these imports that is a sibling (`./`). The other
three climb three levels to `src/app/` — same depth as the existing
`'../../../core/services/claims-api.service'` line, which is how you can check yourself.

---

## Step 5 — admin: read the AI result, never run it

### 5a. `claim-review.html`

Insert between the two-column grid and the final-decision block — i.e. after the `</div>` that closes the grid, immediately **above** the line `<!-- ===================== final decision ===================== -->`:

```html
    <!-- v3.4 — the AI reading of the evidence. Read-only here: an admin cannot spend a call. -->
    <div class="mt-6">
      <app-integrity-panel [claimId]="d.claimId" [claimStatus]="d.status" [canRun]="false" />
    </div>
```

### 5b. `claim-review.ts`

The admin screen is at `src/app/features/claims/claim-review/`; the panel is at
`src/app/features/claims/investigate-claim/`. They are siblings, so:

```ts
import { IntegrityPanel } from '../investigate-claim/integrity-panel';
```

Add `IntegrityPanel` to the `imports` array.

---

## Step 6 — build

```powershell
ng build
```

---

## Verification

### Files landed

```powershell
@(
  "src\app\core\models\claim-document.model.ts",
  "src\app\core\services\claims-documents-api.service.ts",
  "src\app\shared\ui\document-list\document-list.ts",
  "src\app\shared\ui\document-list\document-list.html",
  "src\app\features\claims\investigate-claim\integrity-panel.ts",
  "src\app\features\claims\investigate-claim\integrity-panel.html"
) | ForEach-Object { "{0,-90} {1}" -f $_, (Test-Path $_) }
```

Six `True`.

### No stale CSS references

```powershell
Select-String -Path "src\app\features\claims\investigate-claim\investigate-claim.ts","src\app\shared\ui\document-list\document-list.ts" -Pattern "styleUrl"
```

No output.

### The old link is gone from every screen

```powershell
Select-String -Path "src\app\features\**\*.html" -Pattern "documentLink"
```

No output. (The field still exists in `claim.model.ts` and in the server DTO — that is intended.)

### Components are declared

```powershell
Select-String -Path "src\app\features\claims\investigate-claim\investigate-claim.ts" -Pattern "DocumentList|IntegrityPanel"
Select-String -Path "src\app\features\claims\claim-review\claim-review.ts" -Pattern "IntegrityPanel"
Select-String -Path "src\app\features\claims\claim-details\claim-details.ts" -Pattern "DocumentList"
```

Two hits, one hit, one hit.

### Live walk-through

1. Log in as **Company** → file a claim → pick three PDFs → submit → success card says “Uploading 3 file(s)…”, then “A surveyor will pick it up next”.
2. Open the claim → **Evidence documents** lists three files → click **Open** on one; it renders in a new tab.
3. Log in as **Surveyor** → pick the claim up → the investigate page lists the same three files, **no upload control**, and the AI panel sits directly beneath them.
4. Press **Run integrity check** → verdict.
5. Log in as **Admin** → open the same claim → the panel shows the result with **no run button**.
6. Back as Company, after pickup → the evidence card says *frozen at surveyor pickup*, no Remove buttons.

---

## If something fails

| Message | Cause |
|---|---|
| `'app-document-list' is not a known element` | not added to that screen's `imports` |
| `Cannot find module '../investigate-claim/integrity-panel'` | admin path — count the folders back to `features/claims/` |
| `Cannot find module '../../../core/services/claims-documents-api.service'` | the model/service went into a different folder |
| 404 on upload | gateway path — must be `/api/claims/{id}/documents`, which the existing `claims` route already forwards |
| 409 on upload | the surveyor already picked the claim up (FR5.16). Correct behaviour |
| 403 on upload | logged in as someone other than the owning Company |
| “Only PDF, JPG and PNG files are accepted” | server magic-byte sniff, not the extension — a renamed `.docx` fails here |
