# Backend — three edits so `documentLink` is no longer required

**Why this is not optional:** `ClaimService.ValidateIntake` adds `documentLink` to the
`missing` list, so a filing without it throws
`ValidationException("Missing required fields: documentLink.")` → HTTP 400.
The new form does not send it. Until these three lines change, **every claim filed from
the new screen fails.**

The column and the DTO property stay. Only the requirement goes.

Paths are relative to `src/Services/Insurance/`.

---

## 1. `InsuranceService.Infrastructure/Services/ClaimService.cs`

### 1a. stop requiring it (around line 409)

Find:

```csharp
        if (string.IsNullOrWhiteSpace(r.DocumentLink)) missing.Add("documentLink");
```

Replace with:

```csharp
        // v3.4 — evidence is uploaded as files (FR5.1 amended); the link is legacy and optional.
```

### 1b. tolerate a null link (around line 106)

Find:

```csharp
            DocumentLink = request.DocumentLink.Trim(),
```

Replace with:

```csharp
            DocumentLink = request.DocumentLink?.Trim() ?? string.Empty,
```

### 1c. leave the read path alone

Line ~334 builds `ClaimDetails` and passes `claim.DocumentLink`. Leave it — the property
still exists on the entity and the details DTO. Old claims keep their value; nothing
renders it.

---

## 2. `InsuranceService.Application/Dtos/ClaimDtos.cs`

### 2a. the request record (around line 26)

Find:

```csharp
    string ClaimType,
    string DocumentLink,
    bool AppNotInUseDeclared,
    List<TripEventInput>? TripEvents);
```

Replace with:

```csharp
    string ClaimType,
    string? DocumentLink,          // v3.4 — legacy; evidence now arrives as uploaded files
    bool AppNotInUseDeclared,
    List<TripEventInput>? TripEvents);
```

### 2b. the details record (around line 104)

Leave `string DocumentLink,` as it is. It is a response field; the UI simply stops reading
it. Making it nullable here would force a null check in three Angular templates for no gain.

---

## 3. Build and one smoke test

```powershell
cd src\Services\Insurance
dotnet build
```

Then, with the API running, file one claim from the new screen. Expected: **201**, then
three uploads, then `ClaimDocuments` has three rows:

```sql
SELECT DocumentType, OriginalFileName, AiStatus
FROM [Tnc_InsuranceDb].dbo.ClaimDocuments
WHERE ClaimId = 'THE-NEW-CLAIM-ID'
ORDER BY UploadedAtUtc;
```

Three rows, `AiStatus` null until the surveyor runs the check.

---

## If you would rather not touch C# at all

The alternative is one line in `file-claim.ts`:

```ts
documentLink: `upload://${Date.now()}`,   // placeholder, satisfies the old validation
```

It keeps the build green and the demo working, and it is a lie in the database. I would not
do it in a submission you have to defend — but it is a one-line escape hatch if the backend
is not yours to rebuild an hour before the recording.
