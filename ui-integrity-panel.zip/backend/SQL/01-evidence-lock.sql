-- ============================================================================
-- v3.4 evidence custody — one column, one index look-up, no other schema change.
-- Run this once against [Tnc_InsuranceDb] before starting the API with the new code.
-- Safe to re-run: both statements are guarded.
-- ============================================================================

USE [Tnc_InsuranceDb];
GO

-- 1. The permanent evidence lock. Set on the first surveyor pickup, never cleared.
IF COL_LENGTH('dbo.Claims', 'EvidenceLockedAtUtc') IS NULL
BEGIN
    ALTER TABLE dbo.Claims ADD EvidenceLockedAtUtc datetimeoffset(7) NULL;
    PRINT 'Added Claims.EvidenceLockedAtUtc';
END
ELSE
    PRINT 'Claims.EvidenceLockedAtUtc already exists — nothing to do';
GO

-- 2. Backfill: any claim that has ever been picked up is already frozen by definition.
--    Without this, claims picked up before the upgrade would look editable to the company.
UPDATE c
SET c.EvidenceLockedAtUtc = h.PickedUpAt
FROM dbo.Claims c
CROSS APPLY (
    SELECT MIN(h.ChangedAtUtc) AS PickedUpAt
    FROM dbo.ClaimStatusHistories h
    WHERE h.ClaimId = c.Id
      AND h.ToStatus = 'UnderInvestigation'
) h
WHERE c.EvidenceLockedAtUtc IS NULL
  AND h.PickedUpAt IS NOT NULL;
GO

PRINT 'Backfill done — rows still NULL have never been picked up and stay editable.';
GO

-- 3. Check it.
SELECT
    COUNT(*)                                                   AS TotalClaims,
    SUM(CASE WHEN EvidenceLockedAtUtc IS NULL THEN 1 ELSE 0 END) AS StillEditable,
    SUM(CASE WHEN EvidenceLockedAtUtc IS NOT NULL THEN 1 ELSE 0 END) AS Frozen
FROM dbo.Claims;
GO

-- ============================================================================
-- Expect: Frozen equals the number of claims that have been picked up at least once.
-- Your two Lane A claims (GFW103 / GFW104) were picked up for the walkthrough, so both
-- should show as Frozen — which is correct: their documents must not change now.
-- ============================================================================
