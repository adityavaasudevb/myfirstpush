// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Domain/Entities/Claim.cs
// (The copy you sent was fully commented out — this is the complete live file.
//  Paste it wherever your live Claim entity currently sits.)
using InsuranceService.Domain.Constants;

namespace InsuranceService.Domain.Entities;

/// <summary>
/// A claim against an Active policy (FR5). State machine (Section 2):
/// Submitted -> AwaitingSurveyorPickup (same request, after the rules engine runs)
///           -> UnderInvestigation (atomic pickup; four Pending FieldVerifications created)
///           -> SurveyorReportSubmitted (only when no field is still Pending)
///           -> Paid (Admin approves; payout simulated in the same request) | Rejected.
/// UnderInvestigation -> AwaitingSurveyorPickup is possible again via release (FR5.18, v3.2).
/// IncidentLocation, the trip event log (FR5.16) and the surveyor report are
/// immutable once submitted — there is deliberately no update endpoint for Claims.
/// </summary>
public class Claim
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string ClaimNumber { get; set; } = string.Empty;  // human readable, e.g. CLM-2026-XXXXXXXX
    public Guid PolicyId { get; set; }
    public Policy? Policy { get; set; }                      // navigation: loaded only with Include (detail / company-list joins)

    // ---- intake (FR5.1) ----
    public string DriverName { get; set; } = string.Empty;
    public string DriverLicenceNumber { get; set; } = string.Empty;
    public string PassengerName { get; set; } = string.Empty;
    public string PassengerContact { get; set; } = string.Empty;
    // v3.2 (mentor change) — multi-passenger support, proportionate to the payout model:
    // one primary claimant contact + headcount + free-text for the rest. A modelled
    // Passenger 1..N collection is a documented next iteration (Appendix D, D16).
    public int? PassengerCount { get; set; }                 // total aboard incl. the primary passenger; optional
    public string? AdditionalPassengersNotes { get; set; }   // other passengers' details, optional (max 500)
    public string VehicleNumber { get; set; } = string.Empty;
    public DateTimeOffset IncidentAtUtc { get; set; }
    public string IncidentLocation { get; set; } = string.Empty; // immutable after submission (FR5.16)
    public string Description { get; set; } = string.Empty;
    public decimal ClaimedAmountInr { get; set; }
    public string ClaimType { get; set; } = ClaimTypes.ThirdPartyLiability;
    public string DocumentLink { get; set; } = string.Empty;      // single consolidated link (D8 interim)

    /// <summary>FR5.2 — company declares the app was never on: no event validation runs, claim classifies as App Off.</summary>
    public bool AppNotInUseDeclared { get; set; }

    // ---- rules-engine output (Section 3 precedence, FR5.7 decision-support only) ----
    public string DerivedPeriod { get; set; } = CoveragePeriods.AppOff; // FR5.5 — always derived at intake; every persisted claim has one
    public string PreliminaryDecision { get; set; } = PreliminaryDecisions.Reject; // FR5.7 — engine always runs at intake; this default is a placeholder, never persisted
    public decimal? PreliminaryAmountInr { get; set; }          // min(claimed, period cap) when Approve
    public bool IsFlagged { get; set; }                         // plausibility windows + boundary + late-intimation + log-window flags (FR5.4/FR5.6/v3.2)
    public string? FlagReason { get; set; }

    // ---- lifecycle ----
    public string Status { get; set; } = ClaimStatuses.Submitted;
    public string? AssignedSurveyorId { get; set; }             // JWT sub of the surveyor who picked it up (FR5.9); cleared on release (FR5.18)
    public decimal? FinalPayoutAmountInr { get; set; }          // recorded on Admin approve (FR5.15/FR6.1)

    // ---- v3.4 evidence custody --------------------------------------------------
    /// <summary>
    /// Set the first time a surveyor picks the claim up, never cleared — not by release, not
    /// by anything else. Once true, the company can no longer add or remove evidence, even if
    /// the claim goes back to the open queue. This is what stops the swap-clean-documents
    /// loop: a released claim can be investigated by the next surveyor, but its evidence is
    /// frozen as the first surveyor saw it.
    /// </summary>
    public DateTimeOffset? EvidenceLockedAtUtc { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; } = DateTimeOffset.UtcNow;

    // ---- children (same database; loaded in DETAIL queries only — list/queue endpoints use projections, a Layer-2 service rule) ----
    public List<TripEvent> TripEvents { get; set; } = new();
    public List<FieldVerification> FieldVerifications { get; set; } = new();
    public SurveyorReport? Report { get; set; }
    public List<ClaimStatusHistory> StatusHistory { get; set; } = new();
}

// ================================================================
// RELATED ONE-LINE CHANGE NEEDED IN Policy.cs (not included in your
// upload set): your InsuranceDbContext wires
//     claim.HasOne(c => c.Policy).WithMany(p => p.Claims)...
// so the Policy entity must carry the collection navigation:
//
//     public List<Claim> Claims { get; set; } = new();   // inverse navigation (never Include'd in list endpoints)
//
// Add it if it isn't there already — no column/migration impact.
// ================================================================
