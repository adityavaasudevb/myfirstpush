// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Domain/Constants/InsuranceConstants.cs
// All canonical string vocab for the Insurance bounded context, one file (house rule).
// WARNING: CoverageTiers and AddOnNames must stay character-identical to QuoteService.Domain —
// premium math and claim-type->add-on mapping depend on it (Section 3).

namespace InsuranceService.Domain.Constants;

/// <summary>Coverage tiers — verbatim duplicate of QuoteService.Domain (intentional, Section 3).</summary>
public static class CoverageTiers
{
    public const string TierA = "Tier A";
    public const string TierB = "Tier B";
    public static readonly string[] All = { TierA, TierB };

    public static string? Normalize(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        var squashed = raw.Trim().Replace(" ", "").Replace("-", "").Replace("_", "");
        foreach (var tier in All)
            if (string.Equals(tier.Replace(" ", ""), squashed, StringComparison.OrdinalIgnoreCase))
                return tier;
        return null;
    }
}

/// <summary>Add-on names — verbatim duplicate of QuoteService.Domain (Section 3 mapping depends on these).</summary>
public static class AddOnNames
{
    public const string PhysicalDamage = "Physical Damage";
    public const string UninsuredMotorist = "Uninsured Motorist";
    public const string MedicalPayments = "Medical Payments";
    public const string RentalCar = "Rental Car";
    public static readonly string[] All = { PhysicalDamage, UninsuredMotorist, MedicalPayments, RentalCar };

    public static string? Normalize(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        foreach (var addOn in All)
            if (string.Equals(addOn, raw.Trim(), StringComparison.OrdinalIgnoreCase))
                return addOn;
        return null;
    }
}

public static class PolicyStatuses
{
    public const string Pending = "Pending";
    public const string Active = "Active";
    public const string Scheduled = "Scheduled";   // v3.3 — Active with a future StartDateUtc (paid renewal, next term)
    public const string Expired = "Expired";       // v3.3 — computed lazily only (FR4.6); never stored by the renewal flow
    public const string Cancelled = "Cancelled";
    public static readonly string[] All = { Pending, Active, Scheduled, Expired, Cancelled };
}

/// <summary>Section 2 — claim status state machine, exactly as documented.</summary>
public static class ClaimStatuses
{
    public const string Submitted = "Submitted";
    public const string AwaitingSurveyorPickup = "AwaitingSurveyorPickup";
    public const string UnderInvestigation = "UnderInvestigation";
    public const string SurveyorReportSubmitted = "SurveyorReportSubmitted";
    public const string Paid = "Paid"; // terminal (approve simulates payout in the same request, FR6.1)
    public const string Rejected = "Rejected"; // terminal
    public static readonly string[] All = { Submitted, AwaitingSurveyorPickup, UnderInvestigation, SurveyorReportSubmitted, Paid, Rejected };

    public static bool IsTerminal(string status) => status == Paid || status == Rejected;
}

/// <summary>FR5.1 claim types; RequiredAddOn implements Section 3's claim-type -> add-on mapping.</summary>
public static class InsuranceClaimTypes
{
    public const string ThirdPartyLiability = "Third-Party Liability";
    public const string OwnVehicleDamage = "Own Vehicle Damage";
    public const string UninsuredMotorist = "Uninsured Motorist";
    public const string MedicalExpense = "Medical Expense";
    public const string RentalCar = "Rental Car";
    public static readonly string[] All = { ThirdPartyLiability, OwnVehicleDamage, UninsuredMotorist, MedicalExpense, RentalCar };

    /// <summary>Section 3: Third-Party Liability is base coverage (null); everything else requires its add-on.</summary>
    public static readonly IReadOnlyDictionary<string, string?> RequiredAddOn =
        new Dictionary<string, string?>
        {
            [ThirdPartyLiability] = null,
            [OwnVehicleDamage] = AddOnNames.PhysicalDamage,
            [UninsuredMotorist] = AddOnNames.UninsuredMotorist,
            [MedicalExpense] = AddOnNames.MedicalPayments,
            [RentalCar] = AddOnNames.RentalCar
        };

    public static string? Normalize(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        foreach (var type in All)
            if (string.Equals(type, raw.Trim(), StringComparison.OrdinalIgnoreCase))
                return type;
        return null;
    }
}

/// <summary>FR5.2 trip event log vocabulary.</summary>
public static class TripEventTypes
{
    public const string AppOnline = "AppOnline";
    public const string RideAccepted = "RideAccepted";
    public const string PassengerPickedUp = "PassengerPickedUp";
    public const string RideCompleted = "RideCompleted";
    public const string AppOffline = "AppOffline";
    public static readonly string[] All = { AppOnline, RideAccepted, PassengerPickedUp, RideCompleted, AppOffline };
}

/// <summary>Section 3, "Period derivation" — evidence-derived coverage periods.</summary>
public static class CoveragePeriods
{
    public const string AppOff = "AppOff"; // rejected by rules precedence #2
    public const string Period1 = "Period1"; // cap Rs 10,00,000 (both tiers)
    public const string Period2 = "Period2"; // cap Rs 1,00,00,000, Tier B only
    public const string Period3 = "Period3"; // cap Rs 1,00,00,000, Tier B only
    public static readonly string[] All = { AppOff, Period1, Period2, Period3 };
}

public static class PreliminaryDecisions
{
    public const string Approve = "Approve";
    public const string Reject = "Reject";
    public static readonly string[] All = { Approve, Reject };
}

/// <summary>FR5.10 — the four verification groups created in Pending at pickup.</summary>
public static class VerificationFields
{
    public const string TripEventLog = "TripEventLog";
    public const string DriverInfo = "DriverInfo";
    public const string PassengerInfo = "PassengerInfo";
    public const string Documents = "Documents";
    public static readonly string[] All = { TripEventLog, DriverInfo, PassengerInfo, Documents };
}

public static class VerificationStatuses
{
    public const string Pending = "Pending";
    public const string Verified = "Verified";
    public const string Suspicious = "Suspicious"; // negative signal, does not block (FR5.11); no InfoRequested (D9)
    public static readonly string[] All = { Pending, Verified, Suspicious };
}

/// <summary>Report vocabulary — the design doc names the fields but not the values; this is our chosen vocab.</summary>
public static class SurveyorOutcomes
{
    public const string Genuine = "Genuine";
    public const string Suspicious = "Suspicious";
    public const string Fraudulent = "Fraudulent";   // v3.4 — the UI offered it; the service now accepts it
    public static readonly string[] All = { Genuine, Suspicious, Fraudulent };
}

public static class SurveyorRecommendations
{
    public const string Approve = "Approve";
    public const string Reject = "Reject"; // FR5.15 compares the Admin decision against this value
    public static readonly string[] All = { Approve, Reject };
}

/// <summary>
/// v3.4 — how far a surveyor may churn one claim. Release is an "I cannot proceed" action, not
/// a way to abandon a claim you do not want; without a cap a surveyor can bounce a claim
/// indefinitely and re-run the audit on every pickup.
/// </summary>
public static class SurveyorLimits
{
    public const int MaxReleases = 1;    // the second release is refused (409)
    public const int MaxAuditRuns = 2;   // total readings per claim; the third is refused (409)
}

public static class ClaimHistoryActions
{
    public const string Submitted = "Submitted";
    public const string PickedUp = "PickedUp";
    public const string ReportSubmitted = "ReportSubmitted";
    public const string Approved = "Approved";
    public const string Rejected = "Rejected";
}

// ============================================================================
// v3.4 — AI document audit (FR5.1 amended, D8 upload half)
// ============================================================================

/// <summary>
/// The document types a company can attach at filing. Deliberately short: the three documents
/// that actually move a decision, plus a catch-all for photos.
/// </summary>
public static class ClaimDocumentTypes
{
    public const string Fir = "FIR";
    public const string RepairEstimate = "RepairEstimate";
    public const string MedicalBill = "MedicalBill";
    public const string RentalInvoice = "RentalInvoice";
    public const string Other = "Other";
    public static readonly string[] All = { Fir, RepairEstimate, MedicalBill, RentalInvoice, Other };

    /// <summary>Display labels shared by API and UI.</summary>
    public static readonly IReadOnlyDictionary<string, string> Labels = new Dictionary<string, string>
    {
        [Fir] = "FIR / police report",
        [RepairEstimate] = "Repair estimate",
        [MedicalBill] = "Medical bill",
        [RentalInvoice] = "Rental invoice",
        [Other] = "Other (photos, etc.)"
    };

    /// <summary>Only the money documents are sent to the model — the FIR is prose and yields vague findings.</summary>
    public static readonly string[] Auditable = { RepairEstimate, MedicalBill, RentalInvoice };

    public static bool IsAuditable(string? type) =>
        type is not null && Auditable.Contains(type);

    /// <summary>The money document a claim type is expected to carry; null when there is none.</summary>
    public static string? ExpectedMoneyDocument(string claimType) => claimType switch
    {
        InsuranceClaimTypes.OwnVehicleDamage => RepairEstimate,
        InsuranceClaimTypes.MedicalExpense => MedicalBill,
        InsuranceClaimTypes.RentalCar => RentalInvoice,
        _ => null
    };
}

/// <summary>AI audit lifecycle per document.</summary>
public static class AiStatuses
{
    public const string Processing = "Processing";
    public const string Completed = "Completed";
    public const string Failed = "Failed";           // the model answered but the payload was unusable
    public const string Unavailable = "Unavailable"; // no provider / network blocked — no checks ran
    public static readonly string[] All = { Processing, Completed, Failed, Unavailable };
}

/// <summary>Severity of an audit finding. Informational only; nothing auto-rejects.</summary>
public static class AiFindingSeverities
{
    public const string Warn = "Warn";
    public const string Info = "Info";
    public static readonly string[] All = { Warn, Info };
}

/// <summary>
/// Finding codes produced by CheckEngine (declared there as AuditFindingCodes — same strings).
/// Kept here as well for the eval table and for any consumer that only imports Domain.
/// </summary>
public static class AiFindingCodes
{
    public const string ArithmeticMismatch = "ARITHMETIC_MISMATCH";
    public const string DuplicateLine = "DUPLICATE_LINE";
    public const string VehicleMismatch = "VEHICLE_MISMATCH";
    public const string DateOutsideWindow = "DATE_OUTSIDE_WINDOW";
    public const string ExceedsClaimedAmount = "EXCEEDS_CLAIMED_AMOUNT";
    public const string NonMedicalItem = "NON_MEDICAL_ITEM";
    public const string DescriptionNotInClaim = "DESCRIPTION_NOT_IN_CLAIM";
    public const string ExtractionIncomplete = "EXTRACTION_INCOMPLETE";
    public const string TaxRateMismatch = "TAX_RATE_MISMATCH";
    public const string BelowClaimedAmount = "BELOW_CLAIMED_AMOUNT";
    public const string BalanceNotSettled = "BALANCE_NOT_SETTLED";
    public const string PatientNameMismatch = "PATIENT_NAME_MISMATCH";
    public const string DocumentNumberReused = "DOCUMENT_NUMBER_REUSED";
    public const string DocumentAfterIncident = "DOCUMENT_AFTER_INCIDENT";
    public const string FirWindowMismatch = "FIR_WINDOW_MISMATCH";
    public const string AdmissionBeforeIncident = "ADMISSION_BEFORE_INCIDENT";
    public const string LateRegistration = "LATE_REGISTRATION";
    public const string MissingExpectedDocument = "MISSING_EXPECTED_DOCUMENT";
    public const string ProviderMismatch = "PROVIDER_MISMATCH";
    public const string ExtractionDisagrees = "EXTRACTION_DISAGREES";
    public static readonly string[] All =
    {
        ArithmeticMismatch, DuplicateLine, VehicleMismatch, DateOutsideWindow, ExceedsClaimedAmount,
        NonMedicalItem, DescriptionNotInClaim, ExtractionIncomplete, TaxRateMismatch, BelowClaimedAmount,
        BalanceNotSettled, PatientNameMismatch, DocumentNumberReused, DocumentAfterIncident,
        FirWindowMismatch, AdmissionBeforeIncident, LateRegistration, MissingExpectedDocument,
        ProviderMismatch, ExtractionDisagrees
    };
}
