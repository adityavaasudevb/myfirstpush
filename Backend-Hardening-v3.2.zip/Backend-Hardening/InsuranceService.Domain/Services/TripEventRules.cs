// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Domain/Services/TripEventRules.cs
using InsuranceService.Domain.Constants;
using InsuranceService.Domain.Entities;

namespace InsuranceService.Domain.Services;

/// <summary>
/// All rules that operate on the trip event log, in one place (canonical
/// structure FR5.2 (v3.2), sequence validation FR5.3, plausibility windows
/// FR5.4, boundary flag FR5.6 — Section 3, "Trip-log plausibility flags").
/// PURE: returns results only. Throwing the HTTP-mapped exceptions
/// (InvalidEventSequenceException / ValidationException -> 400) is the service
/// layer's job.
/// </summary>
public static class TripEventRules
{
    /// <summary>The required event types, in their required relative order (the canonical trip shape).</summary>
    public static readonly string[] RequiredSequence =
    {
        TripEventTypes.AppOnline, TripEventTypes.RideAccepted,
        TripEventTypes.PassengerPickedUp, TripEventTypes.RideCompleted
    };

    /// <summary>
    /// FR5.2 (v3.2) — structure check run on the SUBMITTED (in-order) list:
    /// every canonical type must appear exactly once, in canonical order;
    /// AppOffline is optional and may only be the final event. Returns the
    /// problem text, or null when the log is structurally complete.
    /// Missing/extra/misordered structure = a data error (400), never silently fixed.
    /// </summary>
    public static string? CanonicalSequenceError(IReadOnlyList<TripEvent> eventsInSubmissionOrder)
    {
        if (eventsInSubmissionOrder.GroupBy(e => e.EventType).Any(g => g.Count() > 1))
            return "The trip log must contain each event type at most once.";

        var types = eventsInSubmissionOrder.Select(e => e.EventType).ToList();
        if (types.Contains(TripEventTypes.AppOffline) && types[^1] != TripEventTypes.AppOffline)
            return "AppOffline, when present, must be the final trip event.";

        var core = types.Where(t => t != TripEventTypes.AppOffline).ToList();
        if (!core.SequenceEqual(RequiredSequence))
            return "The trip log must contain the complete sequence — AppOnline, RideAccepted, PassengerPickedUp, " +
                   "RideCompleted — in that order (AppOffline optional last). If the app was never used, file with the " +
                   "App-Off declaration instead of a partial log.";
        return null;
    }

    /// <summary>FR5.3 — every event must not precede the previous one (equal timestamps allowed).</summary>
    public static bool IsChronological(IReadOnlyList<TripEvent> eventsInSubmissionOrder)
    {
        for (var i = 1; i < eventsInSubmissionOrder.Count; i++)
            if (eventsInSubmissionOrder[i].OccurredAtUtc < eventsInSubmissionOrder[i - 1].OccurredAtUtc)
                return false;
        return true;
    }

    /// <summary>
    /// FR5.4 (plausibility windows) + FR5.6 (boundary flag) + v3.2 log-window checks.
    /// Events are assumed canonical + chronological (service layer validates first).
    /// Uses the FIRST occurrence of each event type (canonical = only occurrence).
    /// </summary>
    public static FlagEvaluation Evaluate(
        IReadOnlyList<TripEvent> events,
        DateTimeOffset incidentAtUtc,
        int boundaryFlagMinutes,
        DateTimeOffset policyStartUtc,
        DateTimeOffset policyEndUtc)
    {
        var reasons = new List<string>();
        DateTimeOffset? First(string type) =>
            events.FirstOrDefault(e => e.EventType == type)?.OccurredAtUtc;

        var online = First(TripEventTypes.AppOnline);
        var accepted = First(TripEventTypes.RideAccepted);
        var pickedUp = First(TripEventTypes.PassengerPickedUp);
        var completed = First(TripEventTypes.RideCompleted);

        // Section 3 plausibility windows
        if (online is not null && accepted is not null &&
            accepted.Value - online.Value > TimeSpan.FromHours(4))
            reasons.Add("AppOnline to RideAccepted exceeds 4 hours");
        if (accepted is not null && pickedUp is not null)
        {
            var gap = pickedUp.Value - accepted.Value;
            if (gap < TimeSpan.FromMinutes(1) || gap > TimeSpan.FromMinutes(60))
                reasons.Add("RideAccepted to PassengerPickedUp is implausible (<1 min or >60 min)");
        }
        if (pickedUp is not null && completed is not null)
        {
            var gap = completed.Value - pickedUp.Value;
            if (gap < TimeSpan.FromMinutes(2) || gap > TimeSpan.FromHours(6))
                reasons.Add("PassengerPickedUp to RideCompleted is implausible (<2 min or >6 h)");
        }

        // FR5.6 — incident within BoundaryFlagMinutes of a period-boundary event
        foreach (var boundary in new[] { accepted, pickedUp, completed })
            if (boundary is not null &&
                (incidentAtUtc - boundary.Value).Duration() <= TimeSpan.FromMinutes(boundaryFlagMinutes))
            {
                reasons.Add($"Incident time within {boundaryFlagMinutes} min of a period boundary");
                break; // one boundary flag is enough
            }

        // v3.2 — the log must sit inside the policy term and cover the incident.
        var minEvent = events.Min(e => e.OccurredAtUtc);
        var maxEvent = events.Max(e => e.OccurredAtUtc);
        if (minEvent < policyStartUtc || maxEvent > policyEndUtc)
            reasons.Add("Trip events fall outside the policy term");
        if ((maxEvent - incidentAtUtc).Duration() > TimeSpan.FromHours(24) ||
            incidentAtUtc < minEvent || incidentAtUtc > maxEvent.Add(TimeSpan.FromHours(0)))
        {
            // incident must sit inside the log window; a log that ends long before/starts long
            // after the incident time suggests a fabricated or mismatched sequence
            if (incidentAtUtc < minEvent || incidentAtUtc > maxEvent)
                reasons.Add("Incident time lies outside the trip event log window");
        }

        return new FlagEvaluation(reasons.Count > 0, reasons.Count > 0 ? string.Join("; ", reasons) : null);
    }

    /// <param name="IsFlagged">FR5.4: flagged for mandatory review, never auto-rejected.</param>
    /// <param name="Reason">Semicolon-joined reasons, null when clean.</param>
    public record FlagEvaluation(bool IsFlagged, string? Reason);
}
