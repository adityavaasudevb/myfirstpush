// All five interfaces, in YOUR per-file layout — split at the ===== banners.
// The only interface CHANGE is IClaimService: ReleaseAsync added (FR5.18, v3.2).
// The other four are re-included verbatim (your parameterless ICompanyResolver kept)
// so this file also serves as the reference copy of record.

// =====================================================================
// FILE: src/Services/Insurance/InsuranceService.Application/Interfaces/IClaimService.cs
// =====================================================================
using InsuranceService.Application.Dtos;
using TNCInsurance.Shared.Models;

namespace InsuranceService.Application.Interfaces;

public interface IClaimService
{
    Task<CreateClaimResponse> FileAsync(
        string callerUserId,
        CreateClaimRequest request,
        CancellationToken ct = default);
    Task<PagedResult<ClaimQueueItemDto>> GetQueueAsync(
        bool? isFlagged,
        DateTimeOffset? incidentFrom,
        DateTimeOffset? incidentTo,
        int page,
        int pageSize,
        CancellationToken ct = default);
    Task<PagedResult<ClaimQueueItemDto>> GetAssignedAsync(
        string surveyorUserId,
        int page,
        int pageSize,
        CancellationToken ct = default);
    Task PickupAsync(
        Guid claimId,
        string surveyorUserId,
        CancellationToken ct = default);
    /// <summary>FR5.18 (v3.2) — the assigned surveyor releases an UnderInvestigation
    /// claim back to the open queue (assignment cleared; partial field verifications
    /// discarded and recreated on the next pickup). 403 not assigned; 409 after the
    /// report is submitted.</summary>
    Task ReleaseAsync(
        Guid claimId,
        string surveyorUserId,
        CancellationToken ct = default);
    Task VerifyFieldAsync(
        Guid claimId,
        string surveyorUserId,
        VerifyFieldRequest request,
        CancellationToken ct = default);
    Task SubmitReportAsync(
        Guid claimId,
        string surveyorUserId,
        SubmitReportRequest request,
        CancellationToken ct = default);
    Task<ClaimReviewDto> GetReviewAsync(
        Guid claimId,
        CancellationToken ct = default);
    Task<ClaimDecisionResponse> DecideAsync(
        Guid claimId,
        string adminUserId,
        ClaimDecisionRequest request,
        CancellationToken ct = default);
    Task<ClaimDetailsDto> GetDetailsAsync(
        Guid claimId,
        string callerUserId,
        string callerRole,
        CancellationToken ct = default);
    Task<PagedResult<ClaimListItemDto>> GetCompanyListAsync(
        string callerUserId,
        string? status,
        DateTimeOffset? from,
        DateTimeOffset? to,
        int page,
        int pageSize,
        CancellationToken ct = default);
    Task<PagedResult<ClaimListItemDto>> GetAdminListAsync(
        string? search,
        string? status,
        string? claimType,
        bool? isFlagged,
        string? sortOrder,
        int page,
        int pageSize,
        CancellationToken ct = default);
}

// =====================================================================
// FILE: src/Services/Insurance/InsuranceService.Application/Interfaces/ICompanyResolver.cs  (unchanged — yours)
// =====================================================================
namespace InsuranceService.Application.Interfaces;

/// <summary>
/// Section 4 ownership-resolution helper.
/// The caller's JWT is forwarded to CustomerService,
/// which resolves the company through GET /api/companies/me.
/// (Your architecture: the resolver resolves the caller internally — no user-id parameter.)
/// </summary>
public interface ICompanyResolver
{
    Task<Guid> GetCompanyIdAsync(
        CancellationToken ct = default);
}

// =====================================================================
// FILE: src/Services/Insurance/InsuranceService.Application/Interfaces/IDashboardService.cs  (unchanged — yours)
// =====================================================================
using InsuranceService.Application.Dtos;

namespace InsuranceService.Application.Interfaces;

public interface IDashboardService
{
    Task<DashboardDto> GetAsync(
        CancellationToken ct = default);
}

// =====================================================================
// FILE: src/Services/Insurance/InsuranceService.Application/Interfaces/IPolicyService.cs  (unchanged — yours; ApplyPolicyResponse return kept)
// =====================================================================
using InsuranceService.Application.Dtos;
using TNCInsurance.Shared.Models;

namespace InsuranceService.Application.Interfaces;

public interface IPolicyService
{
    Task<ApplyPolicyResponse> ApplyAsync(
        string callerUserId,
        ApplyPolicyRequest request,
        CancellationToken ct = default);
    Task<PagedResult<PolicyListItemDto>> GetAdminListAsync(
        string? status,
        string? tier,
        string? sortOrder,
        int page,
        int pageSize,
        CancellationToken ct = default);
    Task<PagedResult<PolicyListItemDto>> GetCompanyListAsync(
        string callerUserId,
        string? status,
        DateTimeOffset? from,
        DateTimeOffset? to,
        int page,
        int pageSize,
        CancellationToken ct = default);
    Task<PolicyDetailsDto> GetByIdAsync(
        Guid id,
        string callerUserId,
        bool isAdmin,
        CancellationToken ct = default);
    Task CancelAsync(
        Guid id,
        string callerUserId,
        CancellationToken ct = default);
    Task<PayPolicyResponse> PayAsync(
        Guid id,
        string callerUserId,
        CancellationToken ct = default);
    Task<RenewalResponse> RenewAsync(
        Guid id,
        string callerUserId,
        CancellationToken ct = default);
}

// =====================================================================
// FILE: src/Services/Insurance/InsuranceService.Application/Interfaces/IQuoteServiceClient.cs  (unchanged — yours)
// =====================================================================
namespace InsuranceService.Application.Interfaces;

/// <summary>
/// QuoteService calls made by InsuranceService.
/// </summary>
public interface IQuoteServiceClient
{
    Task<QuoteConvertResult> ConvertAsync(
        Guid quoteId,
        CancellationToken ct = default);
    Task<QuoteStatsResult> GetStatsAsync(
        CancellationToken ct = default);
}

/// <summary>
/// FR3.4 convert result.
/// Returned from QuoteService when a quote is converted during policy application.
/// </summary>
public record QuoteConvertResult(
    Guid QuoteId,
    string QuoteNumber,
    int FleetSize,
    string Tier,
    IReadOnlyList<string> AddOns,
    decimal PremiumInr,
    string Status);

/// <summary>
/// FR7.1 quote statistics used by the dashboard.
/// </summary>
public record QuoteStatsResult(
    int TotalQuotes,
    int ConvertedQuotes,
    decimal ConversionRate);
