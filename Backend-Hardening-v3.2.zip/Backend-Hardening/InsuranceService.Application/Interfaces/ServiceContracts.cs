// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Interfaces/ServiceContracts.cs
// All Application-layer contracts + the two inter-service result records, one file (house rule).
using InsuranceService.Application.Dtos;
using TNCInsurance.Shared.Models;

namespace InsuranceService.Application.Interfaces;

public interface IPolicyService
{
    Task<PolicyDetailsDto> ApplyAsync(string callerUserId, ApplyPolicyRequest request, CancellationToken ct = default);
    Task<PagedResult<PolicyListItemDto>> GetAdminListAsync(string? status, string? tier, string? sortOrder, int page, int pageSize, CancellationToken ct = default);
    Task<PagedResult<PolicyListItemDto>> GetCompanyListAsync(string callerUserId, string? status, DateTimeOffset? from, DateTimeOffset? to, int page, int pageSize, CancellationToken ct = default);
    Task<PolicyDetailsDto> GetByIdAsync(Guid id, string callerUserId, bool isAdmin, CancellationToken ct = default);
    Task CancelAsync(Guid id, string callerUserId, CancellationToken ct = default);
    Task<PayPolicyResponse> PayAsync(Guid id, string callerUserId, CancellationToken ct = default);
    Task<RenewalResponse> RenewAsync(Guid id, string callerUserId, CancellationToken ct = default);
}

public interface IClaimService
{
    Task<CreateClaimResponse> FileAsync(string callerUserId, CreateClaimRequest request, CancellationToken ct = default);
    Task<PagedResult<ClaimQueueItemDto>> GetQueueAsync(bool? isFlagged, DateTimeOffset? incidentFrom, DateTimeOffset? incidentTo, int page, int pageSize, CancellationToken ct = default);
    Task<PagedResult<ClaimQueueItemDto>> GetAssignedAsync(string surveyorUserId, int page, int pageSize, CancellationToken ct = default);
    Task PickupAsync(Guid claimId, string surveyorUserId, CancellationToken ct = default);
    /// <summary>FR5.18 (v3.2) — the assigned surveyor releases an UnderInvestigation claim back to the open queue.</summary>
    Task ReleaseAsync(Guid claimId, string surveyorUserId, CancellationToken ct = default);
    Task VerifyFieldAsync(Guid claimId, string surveyorUserId, VerifyFieldRequest request, CancellationToken ct = default);
    Task SubmitReportAsync(Guid claimId, string surveyorUserId, SubmitReportRequest request, CancellationToken ct = default);
    Task<ClaimReviewDto> GetReviewAsync(Guid claimId, CancellationToken ct = default);
    Task<ClaimDecisionResponse> DecideAsync(Guid claimId, string adminUserId, ClaimDecisionRequest request, CancellationToken ct = default);
    Task<ClaimDetailsDto> GetDetailsAsync(Guid claimId, string callerUserId, string callerRole, CancellationToken ct = default);
    Task<PagedResult<ClaimListItemDto>> GetCompanyListAsync(string callerUserId, string? status, DateTimeOffset? from, DateTimeOffset? to, int page, int pageSize, CancellationToken ct = default);
    Task<PagedResult<ClaimListItemDto>> GetAdminListAsync(string? search, string? status, string? claimType, bool? isFlagged, string? sortOrder, int page, int pageSize, CancellationToken ct = default);
}

public interface IDashboardService
{
    Task<DashboardDto> GetAsync(CancellationToken ct = default);
}

/// <summary>Section 4 ownership-resolution helper — the ONLY way a policy/claim learns the caller's company.</summary>
public interface ICompanyResolver
{
    /// <summary>Returns the caller's CompanyProfile ID; a CustomerService 404 surfaces as HTTP 400 with instructions (Section 4).</summary>
    Task<Guid> GetCompanyIdAsync(string callerUserId, CancellationToken ct = default);
}

/// <summary>QuoteService calls InsuranceService makes (Section 4 diagram): convert at apply time, stats for the dashboard.</summary>
public interface IQuoteServiceClient
{
    Task<QuoteConvertResult> ConvertAsync(Guid quoteId, CancellationToken ct = default);
    Task<QuoteStatsResult> GetStatsAsync(CancellationToken ct = default);
}

/// <summary>Mirror of QuoteService's QuoteConvertDto (FR3.4): the converted quote's stored inputs, informational.</summary>
public record QuoteConvertResult(Guid QuoteId, string QuoteNumber, int FleetSize, string Tier, IReadOnlyList<string> AddOns, decimal PremiumInr, string Status);

/// <summary>Mirror of QuoteService's QuoteStatsDto (FR7.1).</summary>
public record QuoteStatsResult(int TotalQuotes, int ConvertedQuotes, double ConversionRate);
