// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.API/Controllers/ClaimsController.cs
using System.Security.Claims;
using InsuranceService.Application.Dtos;
using InsuranceService.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceService.API.Controllers;

/// <summary>
/// Section 6.4 — claim endpoints (FR5/FR6). Surveyor approval (FR2A.4) is enforced
/// at AuthService's login gate; this service trusts the Surveyor role in the JWT.
/// v3.2: release route added; default queue/assigned orders noted on the actions.
/// </summary>
[ApiController]
[Route("api/claims")]
[Authorize]
public class ClaimsController : ControllerBase
{
    private readonly IClaimService _claims;
    public ClaimsController(IClaimService claims) => _claims = claims;

    private string CallerId =>
        User.FindFirst("sub")?.Value
        ?? throw new UnauthorizedAccessException("Missing sub claim.");
    private string CallerRole =>
        User.FindFirst("role")?.Value
        ?? string.Empty;

    // ---- company ----

    /// <summary>FR5.1–FR5.8 — intake: ownership + Active/term gate, event validation, period derivation, flags, rules engine.</summary>
    [HttpPost]
    [Authorize(Roles = "Company")]
    public async Task<IActionResult> File([FromBody] CreateClaimRequest request,
        CancellationToken ct)
        => StatusCode(StatusCodes.Status201Created, await _claims.FileAsync(CallerId, request, ct));

    /// <summary>FR9.4 — the caller's claims: status + incident-date filters, paged; newest incident first (v3.2).</summary>
    [HttpGet("company")]
    [Authorize(Roles = "Company")]
    public async Task<IActionResult> CompanyList(
        [FromQuery] string? status, [FromQuery] DateTimeOffset? from, [FromQuery] DateTimeOffset? to,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
        => Ok(await _claims.GetCompanyListAsync(CallerId, status, from, to, page, pageSize, ct));

    /// <summary>FR5.17 — full claim incl. status history and per-field notes. Company (own) / Admin / assigned Surveyor.</summary>
    [HttpGet("{id:guid}")]
    [Authorize(Roles = "Company,Admin,Surveyor")]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
        => Ok(await _claims.GetDetailsAsync(id, CallerId, CallerRole, ct));

    // ---- surveyor ----

    /// <summary>FR5.9/FR9.3 — open queue (unassigned AwaitingSurveyorPickup claims), flag + incident-range filters. Default order: flagged first, then oldest incident first (v3.2).</summary>
    [HttpGet("queue")]
    [Authorize(Roles = "Surveyor")]
    public async Task<IActionResult> Queue(
        [FromQuery] bool? isFlagged, [FromQuery] DateTimeOffset? incidentFrom, [FromQuery] DateTimeOffset? incidentTo,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
        => Ok(await _claims.GetQueueAsync(isFlagged, incidentFrom, incidentTo, page, pageSize, ct));

    /// <summary>FR9.3 — claims assigned to the caller (oldest incident first — stalest work on top, v3.2).</summary>
    [HttpGet("assigned")]
    [Authorize(Roles = "Surveyor")]
    public async Task<IActionResult> Assigned([FromQuery] int page = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
        => Ok(await _claims.GetAssignedAsync(CallerId, page, pageSize, ct));

    /// <summary>FR5.9 — atomic pickup: 404 missing, 409 lost the race; creates the four Pending verifications.</summary>
    [HttpPost("{id:guid}/pickup")]
    [Authorize(Roles = "Surveyor")]
    public async Task<IActionResult> Pickup(Guid id, CancellationToken ct)
    {
        await _claims.PickupAsync(id, CallerId, ct);
        return NoContent();
    }

    /// <summary>FR5.18 (v3.2) — release the claim back to the open queue (403 not assigned, 409 once the report is in).</summary>
    [HttpPost("{id:guid}/release")]
    [Authorize(Roles = "Surveyor")]
    public async Task<IActionResult> Release(Guid id, CancellationToken ct)
    {
        await _claims.ReleaseAsync(id, CallerId, ct);
        return NoContent();
    }

    /// <summary>FR5.10 — mark one field Verified/Suspicious with an optional note (assigned surveyor only).</summary>
    [HttpPost("{id:guid}/verify-field")]
    [Authorize(Roles = "Surveyor")]
    public async Task<IActionResult> VerifyField(Guid id, [FromBody] VerifyFieldRequest request, CancellationToken ct)
    {
        await _claims.VerifyFieldAsync(id, CallerId, request, ct);
        return NoContent();
    }

    /// <summary>FR5.13 — final report: 409 while fields Pending; one report per claim.</summary>
    [HttpPost("{id:guid}/report")]
    [Authorize(Roles = "Surveyor")]
    public async Task<IActionResult> SubmitReport(Guid id, [FromBody] SubmitReportRequest request, CancellationToken ct)
    {
        await _claims.SubmitReportAsync(id, CallerId, request, ct);
        return NoContent();
    }

    // ---- admin ----

    /// <summary>FR5.14 — preliminary determination side-by-side with the surveyor's full report.</summary>
    [HttpGet("{id:guid}/review")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Review(Guid id, CancellationToken ct)
        => Ok(await _claims.GetReviewAsync(id, ct));

    /// <summary>FR5.15/FR6.1 — decision; override note mandatory when differing from the surveyor; Approve pays inline.</summary>
    [HttpPost("{id:guid}/decision")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Decide(Guid id, [FromBody] ClaimDecisionRequest request, CancellationToken ct)
        => Ok(await _claims.DecideAsync(id, CallerId, request, ct));

    /// <summary>FR9.2 — full admin claims list: search (claim number / vehicle), status/claimType/flagged filters, sort by incident date.</summary>
    [HttpGet]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> AdminList(
        [FromQuery] string? search, [FromQuery] string? status, [FromQuery] string? claimType,
        [FromQuery] bool? isFlagged, [FromQuery] string? sortOrder,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10, CancellationToken ct = default)
        => Ok(await _claims.GetAdminListAsync(search, status, claimType, isFlagged, sortOrder, page, pageSize, ct));
}
