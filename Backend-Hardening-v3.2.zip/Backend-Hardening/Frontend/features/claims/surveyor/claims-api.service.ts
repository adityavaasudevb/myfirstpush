import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  AdminClaimFilter,
  ClaimDecisionRequest,
  ClaimDecisionResponse,
  ClaimDetails,
  ClaimListItem,
  ClaimQueueItem,
  ClaimReview,
  CreateClaimRequest,
  CreateClaimResponse,
  SubmitReportRequest,
  VerifyFieldRequest,
} from '../models/claim.model';
import { Paged, unwrapPaged } from '../models/paged';

const API = environment.apiBaseUrl;

/** Server page size for claim lists (change in one place). */
export const PAGE_SIZE = 25;

// Claim endpoints (doc §6.4) — company, surveyor and admin slices.
// Ownership/assignment is enforced server-side.
// v3.2: release() added (FR5.18). BUGFIX (v3.2-rebase): the date-filter keys were
// swapped — company's ClaimsController expects from/to, the queue expects
// incidentFrom/incidentTo; they were wired to the opposite endpoints here.
// Default orders are server-set now (queue: flagged first, then oldest incident;
// assigned: oldest incident) — lists just render what arrives.
@Injectable({ providedIn: 'root' })
export class ClaimsApiService {
  private readonly http = inject(HttpClient);

  // ------------------------------- company -------------------------------

  /** FR5.1/FR5.2 — intake; the response already carries the preliminary outcome. */
  file(body: CreateClaimRequest): Observable<CreateClaimResponse> {
    return this.http.post<CreateClaimResponse>(`${API}/claims`, body);
  }

  /** FR9.4 — the caller's claims, paged, optional status + incident-date filters.
   *  Pass pageSize 1 for cheap count reads. */
  mine(filter?: { status?: string; from?: string; to?: string; page?: number; pageSize?: number }): Observable<Paged<ClaimListItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', filter?.pageSize ?? PAGE_SIZE);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.from) params = params.set('from', filter.from); // v3.2-rebase: controller parameter is 'from'
    if (filter?.to) params = params.set('to', filter.to);
    return this.http
      .get<Raw>(`${API}/claims/company`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizeListItem)));
  }

  /** FR5.17 — full claim (Company own / Admin / assigned Surveyor). */
  get(id: string): Observable<ClaimDetails> {
    return this.http.get<ClaimDetails>(`${API}/claims/${id}`);
  }

  // ------------------------------- surveyor -------------------------------

  /** FR5.9/FR9.3 — open queue (unassigned, AwaitingSurveyorPickup).
   *  Pass pageSize 1 for cheap count reads. */
  queue(filter?: { isFlagged?: boolean; from?: string; to?: string; page?: number; pageSize?: number }): Observable<Paged<ClaimQueueItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', filter?.pageSize ?? PAGE_SIZE);
    if (filter?.isFlagged != null) params = params.set('isFlagged', filter.isFlagged);
    if (filter?.from) params = params.set('incidentFrom', filter.from); // v3.2-rebase: controller parameter is 'incidentFrom'
    if (filter?.to) params = params.set('incidentTo', filter.to);
    return this.http
      .get<Raw>(`${API}/claims/queue`, { params })
      .pipe(map((res) => unwrapPaged(res, (c) => c)));
  }

  /** FR9.3 — claims assigned to the caller (v3.2: oldest incident first — stalest work on top). */
  assigned(page = 1, pageSize = PAGE_SIZE): Observable<Paged<ClaimQueueItem>> {
    const params = new HttpParams().set('page', page).set('pageSize', pageSize);
    return this.http
      .get<Raw>(`${API}/claims/assigned`, { params })
      .pipe(map((res) => unwrapPaged(res, (c) => c)));
  }

  /** FR5.9 — atomic pickup; 409 if someone won the race. Creates the four
   *  Pending field-verification records. Returns 204. */
  pickup(id: string): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/pickup`, {});
  }

  /** FR5.18 (v3.2) — release an UnderInvestigation claim back to the open queue;
   *  the next pickup recreates the four Pending fields. 403 not assigned,
   *  409 once the report is submitted. Returns 204. */
  release(id: string): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/release`, {});
  }

  /** FR5.10 — mark one field Verified/Suspicious (+ optional note). 204. */
  verifyField(id: string, body: VerifyFieldRequest): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/verify-field`, body);
  }

  /** FR5.13 — final report; 409 while any field is Pending. 204. */
  submitReport(id: string, body: SubmitReportRequest): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/report`, body);
  }

  // ------------------------------- admin -------------------------------

  /** FR9.2 — full admin claims list: search (claim number / vehicle),
   *  status/claimType/flagged filters, sort by incident date.
   *  Pass pageSize 1 for cheap count reads. */
  adminList(filter?: AdminClaimFilter): Observable<Paged<ClaimListItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', filter?.pageSize ?? PAGE_SIZE);
    if (filter?.search) params = params.set('search', filter.search);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.claimType) params = params.set('claimType', filter.claimType);
    if (filter?.isFlagged != null) params = params.set('isFlagged', filter.isFlagged);
    if (filter?.sortOrder) params = params.set('sortOrder', filter.sortOrder);
    return this.http
      .get<Raw>(`${API}/claims`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizeListItem)));
  }

  /** FR5.14 — preliminary determination + the surveyor's full report.
   *  Errors (400/404) while the claim has no report yet. */
  review(id: string): Observable<ClaimReview> {
    return this.http.get<ClaimReview>(`${API}/claims/${id}/review`);
  }

  /** FR5.15/FR6.1 — final decision; Approve records the simulated payout in
   *  the same request. 200 OK with the resulting claim state. */
  decide(id: string, body: ClaimDecisionRequest): Observable<ClaimDecisionResponse> {
    return this.http.post<ClaimDecisionResponse>(`${API}/claims/${id}/decision`, body);
  }
}

type Raw = Record<string, any>;

function normalizeListItem(c: Raw): ClaimListItem {
  return {
    ...c,
    finalPayoutAmountInr:
      c['finalPayoutAmountInr'] ?? null,
  } as ClaimListItem;
}
