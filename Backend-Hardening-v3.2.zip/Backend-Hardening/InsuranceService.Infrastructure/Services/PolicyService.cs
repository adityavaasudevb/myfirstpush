// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Infrastructure/Services/PolicyService.cs
using InsuranceService.Application.Dtos;
using InsuranceService.Application.Interfaces;
using InsuranceService.Domain.Constants;
using InsuranceService.Domain.Entities;
using InsuranceService.Domain.Rules;
using InsuranceService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using TNCInsurance.Shared.Exceptions;
using TNCInsurance.Shared.Models;

namespace InsuranceService.Infrastructure.Services;

/// <summary>
/// All policy business rules (FR4). Pure math/derivations live in Domain/Rules.
/// v3.2: one-active-policy per company enforced at apply time (409, checked BEFORE
/// the origin quote is converted so a refused application never burns the quote),
/// and Id tiebreakers on every paged list.
/// </summary>
public class PolicyService : IPolicyService
{
    private readonly InsuranceDbContext _db;
    private readonly ICompanyResolver _companies;
    private readonly IQuoteServiceClient _quotes;
    private readonly IConfiguration _config;

    public PolicyService(InsuranceDbContext db, ICompanyResolver companies, IQuoteServiceClient quotes, IConfiguration config)
    {
        _db = db;
        _companies = companies;
        _quotes = quotes;
        _config = config;
    }

    /// <summary>FR4.7 — renewal window opens this many days before the end date (Section 3: 30; demo config 365).</summary>
    private int RenewalWindowDays => _config.GetValue("Insurance:RenewalWindowDays", 30);

    /// <summary>
    /// FR4.1–FR4.3 — straight-through binding: validate, refuse when the company already
    /// holds a live policy (v3.2, one active per company), (optionally) convert the
    /// origin quote inter-service (FR3.4), recompute the premium server-side, save Pending.
    /// </summary>
    public async Task<ApplyPolicyResponse> ApplyAsync(string callerUserId, ApplyPolicyRequest request, CancellationToken ct = default)
    {
        var companyId = await _companies.GetCompanyIdAsync(ct); // Section 4; 404 downstream -> 400 with instructions

        if (request.FleetSize < 1)
            throw new ValidationException("Fleet size must be at least 1.");
        var tier = CoverageTiers.Normalize(request.Tier)
            ?? throw new ValidationException("Tier must be 'Tier A' or 'Tier B'.");
        var addOns = NormalizeAddOns(request.AddOns).ToList();

        var now = DateTimeOffset.UtcNow;

        // v3.2 — ONE active policy per company (Section 12 assumption, now enforced here):
        // a second application is refused while another application is still Pending or an
        // Active (lazy-expiry-aware) policy exists. Runs BEFORE the quote conversion below so a
        // refused application never burns the caller's origin quote. Also closes the
        // double-submit race that could produce two payable Pending policies.
        var hasLivePolicy = await _db.Policies.AnyAsync(p =>
            p.CompanyProfileId == companyId &&
            (p.Status == PolicyStatuses.Pending ||
             (p.Status == PolicyStatuses.Active && p.EndDateUtc > now)), ct);
        if (hasLivePolicy)
            throw new ConflictException(
                "Your company already has an Active policy or a Pending application — one active policy per company. " +
                "Pay or cancel the pending application first, or renew your active policy once the renewal window opens.");

        // FR3.4 — the single conversion point in the flow. Errors propagate verbatim:
        // 404 missing / 403 not yours / 410 expired / 409 already converted.
        // Premium is ALWAYS recomputed below from the submitted values (FR4.2); the
        // convert response is only an acknowledgement, no field-match is re-checked (doc-final).
        if (request.OriginQuoteId is not null)
            await _quotes.ConvertAsync(request.OriginQuoteId.Value, ct);

        var premium = PremiumCalculator.CalculateInr(request.FleetSize, tier, addOns);
        var policy = new Policy
        {
            Id = Guid.NewGuid(),
            PolicyNumber = NewNumber("POL"),
            CompanyProfileId = companyId,
            OriginQuoteId = request.OriginQuoteId,
            Tier = tier,
            AddOns = addOns,
            FleetSize = request.FleetSize,
            PremiumInr = premium,
            Status = PolicyStatuses.Pending
        };
        _db.Policies.Add(policy);
        await _db.SaveChangesAsync(ct);
        return new ApplyPolicyResponse(policy.Id, policy.PolicyNumber, policy.PremiumInr, policy.Status);
    }

    /// <summary>FR4.4 + FR6.1 — simulated payment, always succeeds; activates with 365-day term. Renewals start the day after the old policy ends and store Expire it (FR4.7).</summary>
    public async Task<PayPolicyResponse> PayAsync(Guid id, string callerUserId, CancellationToken ct = default)
    {
        var policy = await LoadTrackedOwnedAsync(id, callerUserId, ct);
        if (policy.Status != PolicyStatuses.Pending)
            throw new PolicyStateException($"Policy {policy.PolicyNumber} cannot be paid in status {policy.Status} — only Pending policies can be paid.");

        DateTimeOffset start;
        if (policy.RenewedFromPolicyId is null)
        {
            start = DateTimeOffset.UtcNow; // FR4.4: start = current instant
        }
        else
        {
            // FR4.7 — renewal activation: starts the day after the old policy ends; old becomes Expired (stored).
            var parent = await _db.Policies.FirstOrDefaultAsync(p => p.Id == policy.RenewedFromPolicyId.Value, ct)
                ?? throw new EntityNotFoundException("The policy being renewed no longer exists.");
            if (parent.EndDateUtc is null)
                throw new PolicyStateException("The policy being renewed has not been activated yet.");
            start = parent.EndDateUtc.Value.AddDays(1);
            parent.Status = PolicyStatuses.Expired;
        }

        policy.StartDateUtc = start;
        policy.EndDateUtc = start.AddDays(365); // Section 3 time limits
        policy.Status = PolicyStatuses.Active;
        await _db.SaveChangesAsync(ct);
        return new PayPolicyResponse(policy.Id, policy.PolicyNumber, policy.Status, policy.StartDateUtc.Value, policy.EndDateUtc.Value);
    }

    /// <summary>FR4.5 — cancel is Pending-only (409 otherwise); this is also how a company declines a renewal offer.</summary>
    public async Task CancelAsync(Guid id, string callerUserId, CancellationToken ct = default)
    {
        var policy = await LoadTrackedOwnedAsync(id, callerUserId, ct);
        if (policy.Status != PolicyStatuses.Pending)
            throw new PolicyStateException($"Policy {policy.PolicyNumber} cannot be cancelled in status {policy.Status} — only Pending policies can be cancelled.");
        policy.Status = PolicyStatuses.Cancelled;
        await _db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// FR4.7 — claims-ratio-priced renewal. Renewal is available only during the final 10 days
    /// before policy expiry (hard rule on top of the configured window).
    /// </summary>
    public async Task<RenewalResponse> RenewAsync(Guid id, string callerUserId, CancellationToken ct = default)
    {
        var policy = await LoadTrackedOwnedAsync(id, callerUserId, ct);

        if (policy.EffectiveStatus != PolicyStatuses.Active)
            throw new PolicyStateException($"Policy {policy.PolicyNumber} is {policy.EffectiveStatus} — only an Active policy can be renewed.");

        var now = DateTimeOffset.UtcNow;
        var daysRemaining = (policy.EndDateUtc!.Value - now).TotalDays;
        if (daysRemaining > 10)
        {
            throw new ValidationException(
                $"Renewal is not yet available. Policies may only be renewed during the final 10 days before expiry. Days remaining: {Math.Ceiling(daysRemaining)}.");
        }
        if (policy.EndDateUtc is null || now > policy.EndDateUtc.Value || now < policy.EndDateUtc.Value.AddDays(-RenewalWindowDays))
        {
            throw new PolicyStateException(
                $"Policy {policy.PolicyNumber} is outside its renewal window (opens {RenewalWindowDays} days before the end date).");
        }

        var alreadyPending = await _db.Policies.AnyAsync(p =>
            p.RenewedFromPolicyId == policy.Id && p.Status == PolicyStatuses.Pending, ct);
        if (alreadyPending)
            throw new ConflictException("A renewal for this policy is already pending — pay it to accept or cancel it to decline.");

        // Section 3: claims ratio = total paid amount of Paid claims on the policy / policy premium.
        var paidTotal = await _db.Claims
            .Where(c => c.PolicyId == policy.Id && c.Status == ClaimStatuses.Paid)
            .SumAsync(c => (decimal?)c.FinalPayoutAmountInr, ct) ?? 0m;
        var ratio = policy.PremiumInr == 0m ? 0m : decimal.Round(paidTotal / policy.PremiumInr, 4);
        var priced = RenewalCalculator.Calculate(policy.PremiumInr, ratio);

        var renewal = new Policy
        {
            Id = Guid.NewGuid(),
            PolicyNumber = NewNumber("POL"),
            CompanyProfileId = policy.CompanyProfileId,
            Tier = policy.Tier, // renewal keeps the same product shape
            AddOns = new List<string>(policy.AddOns),
            FleetSize = policy.FleetSize,
            PremiumInr = priced.PremiumInr,
            Status = PolicyStatuses.Pending,
            RenewedFromPolicyId = policy.Id,
            ReviewRequired = priced.ReviewRequired // informational only (D10)
        };
        _db.Policies.Add(renewal);
        await _db.SaveChangesAsync(ct);
        return new RenewalResponse(renewal.Id, renewal.PolicyNumber, policy.PremiumInr,
            ratio, priced.Band, priced.ReviewRequired, priced.PremiumInr);
    }

    /// <summary>GET /api/policies/{id} — Company (own) or Admin (FR4.6, Section 6.4).</summary>
    public async Task<PolicyDetailsDto> GetByIdAsync(Guid id, string callerUserId, bool isAdmin, CancellationToken ct = default)
    {
        var policy = await _db.Policies.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id, ct)
            ?? throw new EntityNotFoundException("Policy not found.");
        if (!isAdmin)
            await EnsureOwnerAsync(policy, callerUserId, ct);
        return ToDetails(policy);
    }

    /// <summary>FR9.4 — company's own policies: newest first, Id tiebreaker (v3.2).</summary>
    public async Task<PagedResult<PolicyListItemDto>> GetCompanyListAsync(string callerUserId, string? status,
        DateTimeOffset? from, DateTimeOffset? to, int page, int pageSize, CancellationToken ct = default)
    {
        var companyId = await _companies.GetCompanyIdAsync(ct);
        var query = _db.Policies.AsNoTracking().Where(p => p.CompanyProfileId == companyId);
        query = ApplyStatusFilter(query, status);
        if (from is not null) query = query.Where(p => p.CreatedAtUtc >= from.Value);
        if (to is not null) query = query.Where(p => p.CreatedAtUtc <= to.Value);
        return await PageAsync(query.OrderByDescending(p => p.CreatedAtUtc).ThenByDescending(p => p.Id), page, pageSize, ct);
    }

    /// <summary>FR9.1 — admin list: status + tier filters, ONE sort field (creation date), shared-clamped paging; Id tiebreaker (v3.2).</summary>
    public async Task<PagedResult<PolicyListItemDto>> GetAdminListAsync(string? status, string? tier,
        string? sortOrder, int page, int pageSize, CancellationToken ct = default)
    {
        var query = ApplyStatusFilter(_db.Policies.AsNoTracking(), status);
        if (!string.IsNullOrWhiteSpace(tier))
        {
            var canonical = CoverageTiers.Normalize(tier)
                ?? throw new ValidationException("Tier filter must be 'Tier A' or 'Tier B'.");
            query = query.Where(p => p.Tier == canonical);
        }
        var ordered = string.Equals(sortOrder, "asc", StringComparison.OrdinalIgnoreCase)
            ? query.OrderBy(p => p.CreatedAtUtc).ThenBy(p => p.Id)
            : query.OrderByDescending(p => p.CreatedAtUtc).ThenByDescending(p => p.Id);
        return await PageAsync(ordered, page, pageSize, ct);
    }

    // ---- helpers ----

    /// <summary>Lazy-expiry-aware status filter — same pattern as QuoteService history.</summary>
    private static IQueryable<Policy> ApplyStatusFilter(IQueryable<Policy> query, string? status)
    {
        if (string.IsNullOrWhiteSpace(status)) return query;
        var now = DateTimeOffset.UtcNow;
        var s = status.Trim();
        if (string.Equals(s, PolicyStatuses.Active, StringComparison.OrdinalIgnoreCase))
            return query.Where(p => p.Status == PolicyStatuses.Active && p.EndDateUtc > now);
        if (string.Equals(s, PolicyStatuses.Expired, StringComparison.OrdinalIgnoreCase))
            return query.Where(p => (p.Status == PolicyStatuses.Active && p.EndDateUtc <= now) || p.Status == PolicyStatuses.Expired);
        if (string.Equals(s, PolicyStatuses.Pending, StringComparison.OrdinalIgnoreCase))
            return query.Where(p => p.Status == PolicyStatuses.Pending);
        if (string.Equals(s, PolicyStatuses.Cancelled, StringComparison.OrdinalIgnoreCase))
            return query.Where(p => p.Status == PolicyStatuses.Cancelled);
        throw new ValidationException("Status filter must be Pending, Active, Expired, or Cancelled.");
    }

    private async Task<Policy> LoadTrackedOwnedAsync(Guid id, string callerUserId, CancellationToken ct)
    {
        var policy = await _db.Policies.FirstOrDefaultAsync(p => p.Id == id, ct)
            ?? throw new EntityNotFoundException("Policy not found.");
        await EnsureOwnerAsync(policy, callerUserId, ct);
        return policy;
    }

    private async Task EnsureOwnerAsync(Policy policy, string callerUserId, CancellationToken ct)
    {
        var companyId = await _companies.GetCompanyIdAsync(ct);
        if (policy.CompanyProfileId != companyId)
            throw new UnauthorizedRoleException("You do not own this policy.");
    }

    private static async Task<PagedResult<PolicyListItemDto>> PageAsync(IQueryable<Policy> ordered, int page, int pageSize, CancellationToken ct)
    {
        (page, pageSize) = Pagination.Clamp(page, pageSize);
        var total = await ordered.CountAsync(ct);
        var items = await ordered.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return new PagedResult<PolicyListItemDto>(items.Select(ToListItem).ToList(), page, pageSize, total);
    }

    private static IReadOnlyList<string> NormalizeAddOns(IEnumerable<string>? raw)
    {
        var result = new List<string>();
        foreach (var name in raw ?? Enumerable.Empty<string>())
        {
            var canonical = AddOnNames.Normalize(name)
                ?? throw new ValidationException($"Unknown add-on '{name}'. Valid add-ons: {string.Join(", ", AddOnNames.All)}.");
            if (!result.Contains(canonical))
                result.Add(canonical);
        }
        return result;
    }

    private static string NewNumber(string prefix)
        => $"{prefix}-{DateTimeOffset.UtcNow:yyyy}-{Guid.NewGuid().ToString("N")[..8].ToUpperInvariant()}";

    private static PolicyListItemDto ToListItem(Policy p) => new(
        p.Id, p.PolicyNumber, p.CompanyProfileId, p.Tier, p.AddOns, p.FleetSize, p.PremiumInr,
        p.EffectiveStatus, p.RenewedFromPolicyId is not null, p.ReviewRequired,
        p.CreatedAtUtc, p.StartDateUtc, p.EndDateUtc);

    private static PolicyDetailsDto ToDetails(Policy p) => new(
        p.Id, p.PolicyNumber, p.CompanyProfileId, p.OriginQuoteId, p.RenewedFromPolicyId,
        p.Tier, p.AddOns, p.FleetSize, p.PremiumInr, p.EffectiveStatus, p.ReviewRequired,
        p.CreatedAtUtc, p.StartDateUtc, p.EndDateUtc);
}
