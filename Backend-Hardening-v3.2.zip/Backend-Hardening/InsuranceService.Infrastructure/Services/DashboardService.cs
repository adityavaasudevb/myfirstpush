// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Infrastructure/Services/DashboardService.cs
using InsuranceService.Application.Dtos;
using InsuranceService.Application.Interfaces;
using InsuranceService.Domain.Constants;
using InsuranceService.Domain.Entities;
using InsuranceService.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using TNCInsurance.Shared.Models;

namespace InsuranceService.Infrastructure.Services;

/// <summary>
/// FR7.1 — the admin dashboard. Four metrics are computed locally from the
/// Insurance database; the quote-to-policy conversion rate comes from
/// GET /api/quotes/stats via QuoteServiceClient (Admin JWT forwarded by the
/// shared handler). No extra HTTP or DB round-trips: five queries + one call.
/// v3.2: the attention list is ordered oldest-first (fair work order) with an
/// Id tiebreaker for determinism.
/// NOTE: this is the full file — the copy you sent was fully commented out;
/// paste this over the file wherever your live DashboardService sits.
/// </summary>
public class DashboardService : IDashboardService
{
    private readonly InsuranceDbContext _db;
    private readonly IQuoteServiceClient _quotes;

    public DashboardService(InsuranceDbContext db, IQuoteServiceClient quotes)
    {
        _db = db;
        _quotes = quotes;
    }

    public async Task<DashboardDto> GetAsync(CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var monthStart = new DateTimeOffset(now.Year, now.Month, 1, 0, 0, 0, TimeSpan.Zero);

        // 1 — total active policies, lazy-expiry aware (FR4.6)
        var activePolicies = await _db.Policies.CountAsync(p =>
            p.Status == PolicyStatuses.Active && p.EndDateUtc >= now, ct);

        // 2 — claims this period (calendar month)
        var claimsThisMonth = await _db.Claims.CountAsync(c => c.CreatedAtUtc >= monthStart, ct);

        // 3+4 — payout total + approval:rejection ratio among claims DECIDED this period.
        // The status history (FR5.17) is what lets us date the decision, not just the filing.
        var decidedThisMonth = await _db.ClaimStatusHistories
            .Where(h => h.ChangedAtUtc >= monthStart &&
                        (h.ToStatus == ClaimStatuses.Paid || h.ToStatus == ClaimStatuses.Rejected))
            .Join(_db.Claims, h => h.ClaimId, c => c.Id, (h, c) => new { h.ToStatus, c.FinalPayoutAmountInr })
            .ToListAsync(ct);
        var totalPayout = decidedThisMonth
            .Where(x => x.ToStatus == ClaimStatuses.Paid)
            .Sum(x => x.FinalPayoutAmountInr ?? 0m);
        var approved = decidedThisMonth.Count(x => x.ToStatus == ClaimStatuses.Paid);
        var rejected = decidedThisMonth.Count(x => x.ToStatus == ClaimStatuses.Rejected);
        decimal? ratio = rejected == 0 ? null : decimal.Round(approved / (decimal)rejected, 2); // null-safe per FR7.1

        // 5 — quote-to-policy conversion rate from QuoteService (forwarded Admin token)
        var stats = await _quotes.GetStatsAsync(ct);

        // Attention list — Review-Required renewals awaiting a pay/decline decision (informational, D10).
        // v3.2: oldest request first (fair work order), deterministic Id tiebreaker.
        var flagged = await _db.Policies.AsNoTracking()
            .Where(p => p.ReviewRequired && p.Status == PolicyStatuses.Pending)
            .OrderBy(p => p.CreatedAtUtc).ThenBy(p => p.Id)
            .Take(50)
            .ToListAsync(ct);

        var metrics = new DashboardMetricsDto(activePolicies, claimsThisMonth, totalPayout, ratio, stats.ConversionRate);
        var attention = flagged.Select(p => new PolicyListItemDto(
            p.Id, p.PolicyNumber, p.CompanyProfileId, p.Tier, p.AddOns, p.FleetSize, p.PremiumInr,
            p.EffectiveStatus, p.RenewedFromPolicyId is not null, p.ReviewRequired,
            p.CreatedAtUtc, p.StartDateUtc, p.EndDateUtc)).ToList();
        return new DashboardDto(metrics, attention.Count, attention);
    }
}
