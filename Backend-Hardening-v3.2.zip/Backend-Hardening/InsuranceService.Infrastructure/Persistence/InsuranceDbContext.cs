// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Infrastructure/Persistence/InsuranceDbContext.cs
using InsuranceService.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace InsuranceService.Infrastructure.Persistence;

public class InsuranceDbContext : DbContext
{
    public InsuranceDbContext(DbContextOptions<InsuranceDbContext> options) : base(options) { }

    public DbSet<Policy> Policies => Set<Policy>();
    public DbSet<Claim> Claims => Set<Claim>();
    public DbSet<TripEvent> TripEvents => Set<TripEvent>();
    public DbSet<FieldVerification> FieldVerifications => Set<FieldVerification>();
    public DbSet<SurveyorReport> SurveyorReports => Set<SurveyorReport>();
    public DbSet<ClaimStatusHistory> ClaimStatusHistories => Set<ClaimStatusHistory>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // ---- Policy ----
        var policy = modelBuilder.Entity<Policy>();
        policy.HasKey(p => p.Id);
        policy.HasIndex(p => p.PolicyNumber).IsUnique();
        policy.HasIndex(p => p.CompanyProfileId);
        policy.HasIndex(p => p.RenewedFromPolicyId); // duplicate-pending-renewal check (FR4.7)
        policy.Property(p => p.PolicyNumber).HasMaxLength(32);
        policy.Property(p => p.Tier).HasMaxLength(20);
        policy.Property(p => p.Status).HasMaxLength(20);
        policy.Property(p => p.PremiumInr).HasPrecision(18, 2);
        policy.Ignore(p => p.EffectiveStatus);
        // AddOns: EF Core 8 primitive collection -> JSON column (same representation as QuoteService).

        // ---- Claim (with explicit relationships; children required, report 1:1) ----
        var claim = modelBuilder.Entity<Claim>();
        claim.HasKey(c => c.Id);
        claim.HasIndex(c => c.ClaimNumber).IsUnique();
        claim.HasIndex(c => c.VehicleNumber); // FR9.2 search
        claim.HasIndex(c => c.AssignedSurveyorId); // surveyor assigned list
        claim.HasIndex(c => new { c.PolicyId, c.IncidentAtUtc }); // v3.2: duplicate-claim guard query (FR5.8)
        claim.Property(c => c.ClaimNumber).HasMaxLength(32);
        claim.Property(c => c.DriverName).HasMaxLength(100);
        claim.Property(c => c.DriverLicenceNumber).HasMaxLength(40);
        claim.Property(c => c.PassengerName).HasMaxLength(100);
        claim.Property(c => c.PassengerContact).HasMaxLength(64);
        claim.Property(c => c.AdditionalPassengersNotes).HasMaxLength(500); // v3.2 (PassengerCount is int? — no mapping needed)
        claim.Property(c => c.VehicleNumber).HasMaxLength(20);
        claim.Property(c => c.IncidentLocation).HasMaxLength(256);
        claim.Property(c => c.Description).HasMaxLength(1000);
        claim.Property(c => c.ClaimType).HasMaxLength(40);
        claim.Property(c => c.DocumentLink).HasMaxLength(512);
        claim.Property(c => c.DerivedPeriod).HasMaxLength(10);
        claim.Property(c => c.PreliminaryDecision).HasMaxLength(10);
        claim.Property(c => c.FlagReason).HasMaxLength(512);
        claim.Property(c => c.Status).HasMaxLength(40);
        claim.Property(c => c.AssignedSurveyorId).HasMaxLength(64);
        claim.Property(c => c.ClaimedAmountInr).HasPrecision(18, 2);
        claim.Property(c => c.PreliminaryAmountInr).HasPrecision(18, 2);
        claim.Property(c => c.FinalPayoutAmountInr).HasPrecision(18, 2);

        claim.HasOne(c => c.Policy)
             .WithMany(p => p.Claims)
             .HasForeignKey(c => c.PolicyId)
             .OnDelete(DeleteBehavior.Restrict); // claims parent a policy forever; policies are never deleted (cancel = status change)

        claim.HasMany(c => c.TripEvents)
             .WithOne()
             .HasForeignKey(e => e.ClaimId);
        claim.HasMany(c => c.FieldVerifications)
             .WithOne()
             .HasForeignKey(v => v.ClaimId);
        claim.HasMany(c => c.StatusHistory)
             .WithOne()
             .HasForeignKey(h => h.ClaimId);
        claim.HasOne(c => c.Report)
             .WithOne()
             .HasForeignKey<SurveyorReport>(r => r.ClaimId);

        // ---- TripEvent ----
        var tripEvent = modelBuilder.Entity<TripEvent>();
        tripEvent.HasKey(e => e.Id);
        tripEvent.HasIndex(e => e.ClaimId);
        tripEvent.Property(e => e.EventType).HasMaxLength(32);

        // ---- FieldVerification ----
        var field = modelBuilder.Entity<FieldVerification>();
        field.HasKey(f => f.Id);
        field.HasIndex(f => f.ClaimId);
        field.Property(f => f.FieldName).HasMaxLength(32);
        field.Property(f => f.Status).HasMaxLength(20);
        field.Property(f => f.Note).HasMaxLength(512);

        // ---- SurveyorReport — FR5.13: ONE report per claim, enforced at the DB level ----
        var report = modelBuilder.Entity<SurveyorReport>();
        report.HasKey(r => r.Id);
        report.HasIndex(r => r.ClaimId).IsUnique();
        report.Property(r => r.OverallOutcome).HasMaxLength(20);
        report.Property(r => r.Recommendation).HasMaxLength(20);
        report.Property(r => r.Notes).HasMaxLength(1000);
        report.Property(r => r.RecommendedAmountInr).HasPrecision(18, 2);

        // ---- ClaimStatusHistory (append-only; backs FR5.17, the dashboard's "became Paid this month",
        //      and — on release — records the UnderInvestigation -> AwaitingSurveyorPickup return, FR5.18) ----
        var history = modelBuilder.Entity<ClaimStatusHistory>();
        history.HasKey(h => h.Id);
        history.HasIndex(h => h.ClaimId);
        history.HasIndex(h => new { h.ToStatus, h.ChangedAtUtc }); // dashboard aggregation query
        history.Property(h => h.FromStatus).HasMaxLength(40);
        history.Property(h => h.ToStatus).HasMaxLength(40);
        history.Property(h => h.ChangedByUserId).HasMaxLength(64);
    }
}
