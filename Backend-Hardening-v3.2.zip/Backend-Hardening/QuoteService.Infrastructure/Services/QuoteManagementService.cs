// PATH ON YOUR MACHINE: src/Services/Quote/QuoteService.Infrastructure/Services/QuoteManagementService.cs
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using QuoteService.Application.Dtos;
using QuoteService.Application.Interfaces;
using QuoteService.Domain.Constants;
using QuoteService.Domain.Entities;
using QuoteService.Domain.Pricing;
using QuoteService.Infrastructure.Persistence;
using TNCInsurance.Shared.Exceptions;
using TNCInsurance.Shared.Models;

namespace QuoteService.Infrastructure.Services;

/// <summary>
/// All quote business rules.
/// Pure pricing logic remains in QuoteService.Domain.
/// v3.2: history paging now carries an Id tiebreaker (deterministic pages); the
/// Converted status is documented as terminal.
/// </summary>
public class QuoteManagementService : IQuoteService
{
    private readonly QuoteDbContext _db;
    private readonly IFxRateService _fx;
    private readonly IConfiguration _config;

    public QuoteManagementService(
        QuoteDbContext db,
        IFxRateService fx,
        IConfiguration config)
    {
        _db = db;
        _fx = fx;
        _config = config;
    }

    private int ExpiryDays =>
        _config.GetValue("Quote:ExpiryDays", 7);

    /// <summary>
    /// FR3.1 / FR3.2
    /// Creates and persists a quote, returning alternate-tier pricing.
    /// </summary>
    public async Task<CreateQuoteResponse> CreateAsync(
        string ownerUserId,
        CreateQuoteRequest request,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(ownerUserId))
            throw new ValidationException("User identifier is required.");
        if (request.FleetSize < 1)
            throw new ValidationException("Fleet size must be at least 1.");
        var tier = CoverageTiers.Normalize(request.Tier)
            ?? throw new ValidationException(
                "Tier must be 'Tier A' or 'Tier B'.");
        var addOns = NormalizeAddOns(request.AddOns);

        var premium = PremiumCalculator.CalculateInr(
            request.FleetSize,
            tier,
            addOns);
        var alternateTier =
            tier == CoverageTiers.TierA
            ? CoverageTiers.TierB
            : CoverageTiers.TierA;
        var alternatePremium =
            PremiumCalculator.CalculateInr(
                request.FleetSize,
                alternateTier,
                addOns);

        var now = DateTimeOffset.UtcNow;
        var quote = new Quote
        {
            Id = Guid.NewGuid(),
            QuoteNumber =
                $"Q-{now:yyyy}-{Guid.NewGuid().ToString("N")[..8].ToUpperInvariant()}",
            OwnerUserId = ownerUserId,
            FleetSize = request.FleetSize,
            Tier = tier,
            AddOns = addOns.ToList(),
            EstimatedPremium = premium,
            Status = QuoteStatuses.Active,
            CreatedDate = now,
            ExpiryDate = now.AddDays(ExpiryDays)
        };
        _db.Quotes.Add(quote);
        await _db.SaveChangesAsync(ct);

        var fx = await _fx.GetRatesAsync(ct);
        return new CreateQuoteResponse(
            ToDto(quote, fx),
            new TierEstimateDto(
                alternateTier,
                alternatePremium));
    }

    /// <summary>
    /// Section 6.3
    /// Returns a single quote.
    /// </summary>
    public async Task<QuoteDto> GetByIdAsync(
        Guid id,
        string callerUserId,
        CancellationToken ct = default)
    {
        var quote = await _db.Quotes
            .AsNoTracking()
            .FirstOrDefaultAsync(q => q.Id == id, ct)
            ?? throw new EntityNotFoundException("Quote not found.");
        EnsureOwner(quote, callerUserId);
        var fx = await _fx.GetRatesAsync(ct);
        return ToDto(quote, fx);
    }

    /// <summary>
    /// FR3.5 + FR9.4
    /// Quote history with status/date filters and paging;
    /// v3.2 — Id tiebreaker so equal-timestamp rows can never repeat or vanish between pages.
    /// </summary>
    public async Task<PagedResult<QuoteDto>> GetHistoryAsync(
        string callerUserId,
        string? status,
        DateTimeOffset? createdFrom,
        DateTimeOffset? createdTo,
        int page,
        int pageSize,
        CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var query = _db.Quotes
            .AsNoTracking()
            .Where(q => q.OwnerUserId == callerUserId);

        if (!string.IsNullOrWhiteSpace(status))
        {
            var normalizedStatus = status.Trim();
            if (string.Equals(
                normalizedStatus,
                QuoteStatuses.Active,
                StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(q =>
                    q.Status == QuoteStatuses.Active &&
                    q.ExpiryDate > now);
            }
            else if (string.Equals(
                normalizedStatus,
                QuoteStatuses.Expired,
                StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(q =>
                    q.Status == QuoteStatuses.Active &&
                    q.ExpiryDate <= now);
            }
            else if (string.Equals(
                normalizedStatus,
                QuoteStatuses.Converted,
                StringComparison.OrdinalIgnoreCase))
            {
                query = query.Where(q =>
                    q.Status == QuoteStatuses.Converted);
            }
            else
            {
                throw new ValidationException(
                    "Status filter must be Active, Converted, or Expired.");
            }
        }
        if (createdFrom is not null)
        {
            query = query.Where(q =>
                q.CreatedDate >= createdFrom.Value);
        }
        if (createdTo is not null)
        {
            query = query.Where(q =>
                q.CreatedDate <= createdTo.Value);
        }

        (page, pageSize) = Pagination.Clamp(page, pageSize);
        var totalCount = await query.CountAsync(ct);
        var quotes = await query
            .OrderByDescending(q => q.CreatedDate)
            .ThenByDescending(q => q.Id) // v3.2 — deterministic tiebreaker
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        var fx = await _fx.GetRatesAsync(ct);
        var items = quotes
            .Select(q => ToDto(q, fx))
            .ToList();
        return new PagedResult<QuoteDto>(
            items,
            page,
            pageSize,
            totalCount);
    }

    /// <summary>
    /// FR3.4
    /// Called by InsuranceService during policy application.
    /// Converted is terminal (v3.2 wording): a converted quote is never un-converted,
    /// even if the resulting policy is never paid — payment state belongs to the policy.
    /// </summary>
    public async Task<QuoteConvertDto> ConvertAsync(
        Guid id,
        string callerUserId,
        CancellationToken ct = default)
    {
        var quote = await _db.Quotes
            .FirstOrDefaultAsync(q => q.Id == id, ct)
            ?? throw new EntityNotFoundException("Quote not found.");
        EnsureOwner(quote, callerUserId);
        if (quote.EffectiveStatus == QuoteStatuses.Expired)
        {
            throw new QuoteExpiredException(
                $"Quote {quote.QuoteNumber} expired on {quote.ExpiryDate:yyyy-MM-dd} and can no longer be applied.");
        }
        if (quote.Status == QuoteStatuses.Converted)
        {
            throw new ConflictException(
                $"Quote {quote.QuoteNumber} has already been converted to a policy application.");
        }

        quote.Status = QuoteStatuses.Converted;
        await _db.SaveChangesAsync(ct);

        return new QuoteConvertDto(
            quote.Id,
            quote.QuoteNumber,
            quote.FleetSize,
            quote.Tier,
            quote.AddOns,
            quote.EstimatedPremium,
            quote.Status);
    }

    /// <summary>
    /// FR7.1
    /// Dashboard quote statistics.
    /// </summary>
    public async Task<QuoteStatsDto> GetStatsAsync(
        CancellationToken ct = default)
    {
        var total = await _db.Quotes.CountAsync(ct);
        var converted = await _db.Quotes.CountAsync(
            q => q.Status == QuoteStatuses.Converted,
            ct);
        var conversionRate =
            total == 0
            ? 0d
            : Math.Round((double)converted / total, 4);
        return new QuoteStatsDto(
            total,
            converted,
            conversionRate);
    }

    private static void EnsureOwner(
        Quote quote,
        string callerUserId)
    {
        if (!string.Equals(
            quote.OwnerUserId,
            callerUserId,
            StringComparison.Ordinal))
        {
            throw new UnauthorizedRoleException(
                "You do not own this quote.");
        }
    }

    private static IReadOnlyList<string> NormalizeAddOns(
        IEnumerable<string>? raw)
    {
        var result = new List<string>();
        foreach (var addOn in raw ?? Enumerable.Empty<string>())
        {
            var canonical = AddOnNames.Normalize(addOn)
                ?? throw new ValidationException(
                    $"Unknown add-on '{addOn}'. Valid add-ons: {string.Join(", ", AddOnNames.All)}.");
            if (!result.Contains(canonical))
            {
                result.Add(canonical);
            }
        }
        return result;
    }

    private static QuoteDto ToDto(
        Quote quote,
        FxRates fx)
    {
        var usd = Math.Round(
            quote.EstimatedPremium / fx.InrPerUsd,
            2);
        var eur = Math.Round(
            usd * fx.EurPerUsd,
            2);
        return new QuoteDto(
            quote.Id,
            quote.QuoteNumber,
            quote.FleetSize,
            quote.Tier,
            quote.AddOns,
            quote.EstimatedPremium,
            usd,
            eur,
            fx.UsedFallback,
            quote.EffectiveStatus,
            quote.CreatedDate,
            quote.ExpiryDate);
    }
}
