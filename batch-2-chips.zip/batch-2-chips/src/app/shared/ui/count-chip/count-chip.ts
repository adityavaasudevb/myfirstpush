// PATH ON YOUR MACHINE: src/app/shared/ui/count-chip/count-chip.ts
//
// v3.4 — one filter chip with its count, used by every list screen so the numbers look the
// same wherever they appear. The count is a separate, quieter element rather than
// "{{ label }} ({{ n }})" baked into the label string: a number that sits in its own box
// stays aligned when it goes from 1 to 2 digits.
//
// Standalone and dumb: it renders and emits, it never fetches.

import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

@Component({
  selector: 'app-count-chip',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './count-chip.html',
})
export class CountChip {
  readonly label = input.required<string>();
  /** The count, or null while it is still loading (renders as a dash). */
  readonly count = input<number | null>(null);
  readonly active = input(false);
  /** `amber` is for attention filters such as Flagged; everything else is brand claret. */
  readonly tone = input<'primary' | 'amber'>('primary');

  readonly picked = output<void>();
}
