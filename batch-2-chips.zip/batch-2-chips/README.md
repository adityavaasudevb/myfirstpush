# Batch 2 — filter-chip counts and live admin search

Two changes, one package, no backend work:

1. **One filter chip with its count**, used by all six list screens, so the number looks the
   same on the company's pages as it does on the admin's.
2. **Live search on the admin claims screen** — the table filters as you type. No Search
   button, no Enter needed.

Everything here is a whole-file replacement. Copy, overwrite, build. Nothing to hand-edit.

## What it touches

| Screen | Files |
|---|---|
| Company claims | `features/claims/my-claims/my-claims.ts` + `.html` |
| Surveyor queue | `features/claims/surveyor-queue/surveyor-queue.ts` + `.html` |
| Admin claims | `features/claims/admin-claims/admin-claims.ts` + `.html` |
| Company policies | `features/policies/my-policies/my-policies.ts` + `.html` |
| Admin policies | `features/policies/admin-policies/admin-policies.ts` + `.html` |
| Company quotes | `features/quotes/my-quotes/my-quotes.ts` + `.html` |
| — | `shared/ui/count-chip/count-chip.ts` + `.html` ★ **new folder** |

Fourteen files. No `.css`, no `.spec.ts`, no `styleUrl` added, no backend change.

## Before you copy — two things that must already be true

Both come from the documents package you already installed. Check them; if either is
missing, stop and fix that first.

```powershell
cd C:\Users\AB13410\dotnet101\TNCInsurance\frontend\tnc-insurance-ui

# 1. the admin filter type takes a search term
Select-String -Path "src\app\core\models\claim.model.ts" -Pattern "search\?:"

# 2. the API client sends it
Select-String -Path "src\app\core\services\claims-api.service.ts" -Pattern "params.set\('search'"
```

Two hits. On the server, `GET /api/claims` already accepts `search` and matches claim number
or vehicle number, so nothing to deploy there.

## Copy

```powershell
cd C:\Users\AB13410\dotnet101\TNCInsurance\frontend\tnc-insurance-ui
$src = "C:\Users\AB13410\Downloads\batch-2-chips\src\app"
$app = "src\app"

New-Item -ItemType Directory -Force -Path "$app\shared\ui\count-chip" | Out-Null

Copy-Item "$src\shared\ui\count-chip\count-chip.ts"    "$app\shared\ui\count-chip\" -Force
Copy-Item "$src\shared\ui\count-chip\count-chip.html"  "$app\shared\ui\count-chip\" -Force

Copy-Item "$src\features\claims\my-claims\my-claims.ts"                "$app\features\claims\my-claims\"       -Force
Copy-Item "$src\features\claims\my-claims\my-claims.html"              "$app\features\claims\my-claims\"       -Force
Copy-Item "$src\features\claims\surveyor-queue\surveyor-queue.ts"      "$app\features\claims\surveyor-queue\"  -Force
Copy-Item "$src\features\claims\surveyor-queue\surveyor-queue.html"    "$app\features\claims\surveyor-queue\"  -Force
Copy-Item "$src\features\claims\admin-claims\admin-claims.ts"          "$app\features\claims\admin-claims\"    -Force
Copy-Item "$src\features\claims\admin-claims\admin-claims.html"        "$app\features\claims\admin-claims\"    -Force
Copy-Item "$src\features\policies\my-policies\my-policies.ts"          "$app\features\policies\my-policies\"   -Force
Copy-Item "$src\features\policies\my-policies\my-policies.html"        "$app\features\policies\my-policies\"   -Force
Copy-Item "$src\features\policies\admin-policies\admin-policies.ts"    "$app\features\policies\admin-policies\" -Force
Copy-Item "$src\features\policies\admin-policies\admin-policies.html"  "$app\features\policies\admin-policies\" -Force
Copy-Item "$src\features\quotes\my-quotes\my-quotes.ts"                "$app\features\quotes\my-quotes\"       -Force
Copy-Item "$src\features\quotes\my-quotes\my-quotes.html"              "$app\features\quotes\my-quotes\"       -Force
```

Leave every existing `.css` file alone. These six screens still declare `styleUrl`; that
`@Component` line is unchanged and the `.css` is already in your project.

## Build

```powershell
ng build
```

## Verify

```powershell
# the chip is used on six screens
Select-String -Path "src\app\features\**\*.html" -Pattern "app-count-chip" | Select-Object Filename

# none of the old inline chip buttons survived
Select-String -Path "src\app\features\**\*.html" -Pattern "rounded-full border px-3.5 py-1.5 text-sm font-semibold transition"

# the search box no longer has a Search button beside it
Select-String -Path "src\app\features\claims\admin-claims\admin-claims.html" -Pattern "Search</button>"
```

Six filenames, then nothing, then nothing.

## What changed, screen by screen

**The chip.** The count moved out of the label string into its own small pill on the right
of the chip: fixed minimum width, tabular figures, so `9` and `10` line up and the chip does
not jump when a number ticks over. While a count is still loading the pill shows `–`.

The old markup read `Active (4)` — the bracket inside plain text. The new markup is a
separate element, so the number can be styled, aligned and sized independently of the word.
That is the whole difference between the company chips and the admin chips you called
"neater": they were the same markup before; now they are the same *component*.

The Flagged toggle on the admin claims toolbar is the same chip with `tone="amber"` — same
height, same padding, same count pill, only the colour differs.

**Live search (admin claims only).** Typing waits 250 ms, then queries the server with
`search`; a newer keystroke cancels the request still in flight, so a fast typist never
queues six lists. Emptying the box resets the table instantly. Enter still works and skips
the wait. A subtle `Searching…` label appears while a request is running.

The status chips count what the current search returns, so they follow what you type.
They are read once on open and refreshed whenever the search, claim type or Flagged filter
changes.

## If a chip shows "–" after the page has loaded

"–" means that one count request did not come back. Each chip is its own cheap request
(`pageSize=1`; the response's `total` is the count), so a failure is per chip, not per page,
and it fails silently by design — a dead chip should not throw an error banner over a
working table.

Open DevTools → Network, filter `company` or `admin`, and look at a `pageSize=1` call:

| Status | Meaning |
|---|---|
| `200` and the pill still shows `–` | the response has no `total` field — send me the JSON body |
| `401` / `403` | the token's role does not match that endpoint |
| `500` | backend fault; the response body carries the exception |

## Nothing here needs a migration

No entity, no column, no DTO changed. If you were thinking about EF migrations: this
project has none — schema changes are hand-written SQL in `backend/SQL/`.
