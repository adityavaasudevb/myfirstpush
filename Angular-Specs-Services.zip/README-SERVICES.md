# Specs round 2 — services / models / guards (lifts the §9-thresholded layers)

§9 scopes the frontend coverage threshold to the **core and service layers**.
Round 1 covered guards, interceptors, `auth.service` and claim-form
validation; this round finishes the core layer. All files here **replace**
existing same-path stubs (which had one create-only test each) except
`paged.spec.ts`, which is new.

| File | Action | Adds |
|---|---|---|
| `core/models/paged.spec.ts` | New | `unwrapPaged`: envelope, bare array, aliases, missing total, null, normalizer application |
| `core/services/quote.service.spec.ts` | Replace | create (wrapped + bare), `estimatedPremiumInr`→`premiumInr` mapping, expiry aliases, mine params incl. `pageSize=1` count reads, addOns CSV tolerance |
| `core/services/policy.service.spec.ts` | Replace | apply / mine (FR9.4 params) / adminList (FR9.1 params) / get / pay / cancel (DELETE) / renew |
| `core/services/claims-api.service.spec.ts` | Replace | every role slice: file, mine, get, queue, assigned, pickup, verify-field, report, adminList full FR9.2 params, review, decide |
| `core/services/company-profile.service.spec.ts` | Replace | loadMe/create/update + signal cache semantics + clear |
| `core/services/dashboard.service.spec.ts` | Replace | FR7.1 payload incl. null ratio |
| `core/services/admin-surveyor.service.spec.ts` | Replace | pending (+null→[]), approve, reject `{reason}` |
| `core/guards/company-profile-guard.spec.ts` | Replace | cached fast-path, load-then-admit, 404→onboarding, non-404 pass-through; onboardingGuard mirror |
| `shared/ui/money-pipe.spec.ts` | Replace | en-IN grouping, ₹0 vs — for null |

Run: `ng test --coverage --watch=false`.

**Expected effect (from the v8 table of your last run):** `paged.ts` 12.5%→~95%,
`quote.service` 40%→~95%, guards →100%, every service →~90%+ — the
**core+services aggregate ≈ 90%**, comfortably above the 80% spirit that §9
reserves for those layers. Whole-app ~35% is expected and fine: HTML
templates are intentionally not thresholded (the doc thresholds "the core and
service layers", and the backend's own 80% gate is equally scoped to
Application+Domain only).
