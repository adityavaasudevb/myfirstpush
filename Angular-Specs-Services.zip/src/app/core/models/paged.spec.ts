import { unwrapPaged } from './paged';

// paged.ts — the defensive PagedResult<T> normalizer every list depends on.

describe('unwrapPaged', () => {
  const id = (x: unknown) => x;

  it('unwraps the canonical { items, page, pageSize, total } envelope', () => {
    const pg = unwrapPaged({ items: [1, 2], page: 2, pageSize: 25, total: 52 }, id);
    expect(pg.items).toEqual([1, 2]);
    expect(pg.page).toBe(2);
    expect(pg.pageSize).toBe(25);
    expect(pg.total).toBe(52);
  });

  it('tolerates a bare array (unpaged endpoints)', () => {
    const pg = unwrapPaged([7, 8, 9], id);
    expect(pg.items).toEqual([7, 8, 9]);
    expect(pg.total).toBe(3);
    expect(pg.page).toBe(1);
  });

  it('accepts alias collection/total fields', () => {
    const pg = unwrapPaged({ data: ['a'], totalCount: 41 }, id);
    expect(pg.items).toEqual(['a']);
    expect(pg.total).toBe(41);
  });

  it('falls back to items.length when the total is missing', () => {
    const pg = unwrapPaged({ items: ['x', 'y'] }, id);
    expect(pg.total).toBe(2);
  });

  it('survives null/empty responses', () => {
    const pg = unwrapPaged(null, id);
    expect(pg.items).toEqual([]);
    expect(pg.total).toBe(0);
  });

  it('applies the normalizer to every item', () => {
    const pg = unwrapPaged({ items: [{ v: 1 }], total: 1 }, (r: any) => r.v);
    expect(pg.items).toEqual([1]);
  });
});
