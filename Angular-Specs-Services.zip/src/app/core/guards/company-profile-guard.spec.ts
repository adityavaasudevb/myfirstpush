import { TestBed } from '@angular/core/testing';
import { Router, UrlTree } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { isObservable } from 'rxjs';
import { companyProfileGuard, onboardingGuard } from '../../features/company-profile/company-profile-guard';
import { CompanyProfileService } from '../../features/company-profile/services/company-profile.service';
import { CompanyProfile } from '../../features/company-profile/models/company-profile.model';

// The onboarding gate (FR2.3): the 404 from /me IS the "no profile yet" signal.

const PROFILE: CompanyProfile = {
  id: 'co-1',
  userId: 'u-1',
  name: 'SwiftFleet',
  registrationNo: 'CIN-1',
  contactPerson: 'A Rao',
  email: 'ops@fleet.in',
  phone: '9876543210',
  fleetSize: 10,
};

describe('company-profile guards', () => {
  let cached: CompanyProfile | null;
  let loadResult: () => Observable<CompanyProfile>;
  let builtPaths: string[];

  beforeEach(() => {
    cached = null;
    loadResult = () => of(PROFILE);
    builtPaths = [];
    TestBed.configureTestingModule({
      providers: [
        {
          provide: CompanyProfileService,
          useValue: { profile: () => cached, loadMe: () => loadResult() },
        },
        {
          provide: Router,
          useValue: {
            createUrlTree: (commands: string[]) => {
              builtPaths = commands;
              return { toString: () => commands.join('') } as unknown as UrlTree;
            },
          },
        },
      ],
    });
  });

  const resolve = (guard: typeof companyProfileGuard, done: (v: unknown) => void) => {
    TestBed.runInInjectionContext(() => {
      const out = guard({} as never, {} as never) as Observable<unknown> | unknown;
      if (isObservable(out)) out.subscribe(done);
      else done(out);
    });
  };

  it('lets a cached profile straight into the workspace (no API call)', (done) => {
    cached = PROFILE;
    loadResult = () => {
      throw new Error('loadMe must not be called');
    };
    resolve(companyProfileGuard, (v) => {
      expect(v).toBeTrue();
      done();
    });
  });

  it('loads the profile when uncached, then admits', (done) => {
    resolve(companyProfileGuard, (v) => {
      expect(v).toBeTrue();
      done();
    });
  });

  it('redirects to onboarding exactly on the 404 "no profile yet" signal', (done) => {
    loadResult = () => throwError(() => ({ status: 404 }));
    resolve(companyProfileGuard, (v) => {
      expect(builtPaths).toEqual(['/company/onboarding']);
      expect((v as UrlTree).toString()).toBe('/company/onboarding');
      done();
    });
  });

  it('lets non-404 backend hiccups through to the workspace', (done) => {
    loadResult = () => throwError(() => ({ status: 503 }));
    resolve(companyProfileGuard, (v) => {
      expect(v).toBeTrue();
      done();
    });
  });

  it('onboardingGuard bounces an existing profile to the workspace', (done) => {
    cached = PROFILE;
    resolve(onboardingGuard, (v) => {
      expect(builtPaths).toEqual(['/company']);
      done();
    });
  });

  it('onboardingGuard admits when the fetch says no profile', (done) => {
    loadResult = () => throwError(() => ({ status: 404 }));
    resolve(onboardingGuard, (v) => {
      expect(v).toBeTrue();
      done();
    });
  });
});
