import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { CompanyProfileService } from '../../features/company-profile/services/company-profile.service';

// CompanyProfileService (§9 core coverage): the profile signal is the single
// source consumed by the guards, dashboard and profile page.

const PROFILE = {
  id: 'co-1',
  userId: 'u-1',
  name: 'SwiftFleet Mobility Pvt Ltd',
  registrationNo: 'U74999TN2019PTC138821',
  contactPerson: 'Ananya Rao',
  email: 'ops@swiftfleet.in',
  phone: '9876543210',
  fleetSize: 25,
};

const REQUEST = {
  name: PROFILE.name,
  registrationNo: PROFILE.registrationNo,
  contactPerson: PROFILE.contactPerson,
  email: PROFILE.email,
  phone: PROFILE.phone,
  fleetSize: PROFILE.fleetSize,
};

describe('CompanyProfileService', () => {
  let svc: CompanyProfileService;
  let ctrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    svc = TestBed.inject(CompanyProfileService);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('loadMe GETs /companies/me and caches the profile (FR2.3)', () => {
    svc.loadMe().subscribe();
    const req = ctrl.expectOne('/api/companies/me');
    expect(req.request.method).toBe('GET');
    req.flush(PROFILE);
    expect(svc.profile()?.id).toBe('co-1');
  });

  it('create POSTs and caches the created profile (FR2.1)', () => {
    svc.create(REQUEST).subscribe();
    const req = ctrl.expectOne('/api/companies');
    expect(req.request.method).toBe('POST');
    expect(req.request.body.registrationNo).toBe('U74999TN2019PTC138821');
    req.flush(PROFILE);
    expect(svc.profile()?.name).toBe(PROFILE.name);
  });

  it('update PUTs to the profile id and refreshes the cache (FR2.2)', () => {
    svc.update('co-1', REQUEST).subscribe();
    const req = ctrl.expectOne('/api/companies/co-1');
    expect(req.request.method).toBe('PUT');
    req.flush({ ...PROFILE, name: 'SwiftFleet Mobility Limited' });
    expect(svc.profile()?.name).toBe('SwiftFleet Mobility Limited');
  });

  it('clear empties the cache (logout path)', () => {
    svc.loadMe().subscribe();
    ctrl.expectOne('/api/companies/me').flush(PROFILE);
    svc.clear();
    expect(svc.profile()).toBeNull();
  });
});
