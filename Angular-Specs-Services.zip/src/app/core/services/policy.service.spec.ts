import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { PolicyService } from './policy.service';

// PolicyService (§9 core coverage): methods, params, URL paths.

const POLICY_JSON = {
  id: 'p-1',
  policyNumber: 'POL-2026-0001',
  companyProfileId: 'co-1',
  tier: 'Tier B',
  addOns: ['Physical Damage'],
  fleetSize: 25,
  premiumInr: 720000,
  status: 'Active',
  isRenewal: false,
  reviewRequired: false,
  createdAtUtc: '2026-10-01T09:00:00Z',
  startDateUtc: '2026-10-01T09:05:00Z',
  endDateUtc: '2027-10-01T09:05:00Z',
};

describe('PolicyService', () => {
  let svc: PolicyService;
  let ctrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    svc = TestBed.inject(PolicyService);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('apply posts to the apply endpoint (FR4.1)', () => {
    let got: any;
    svc.apply({ originQuoteId: 'q-1', tier: 'Tier B', addOns: [], fleetSize: 25 }).subscribe((r) => (got = r));
    const req = ctrl.expectOne('/api/policies/apply');
    expect(req.request.method).toBe('POST');
    expect(req.request.body.originQuoteId).toBe('q-1');
    req.flush({ policyId: 'p-1', policyNumber: 'POL-2026-0001', premiumInr: 720000, status: 'Pending' });
    expect(got.status).toBe('Pending');
  });

  it('mine builds status/date filters and paging (FR9.4)', () => {
    let got: any;
    svc.mine({ status: 'Active', from: '2026-01-01', to: '2026-12-31', page: 3 }).subscribe((r) => (got = r));
    const req = ctrl.expectOne((r) => r.url === '/api/policies/company');
    expect(req.request.params.get('status')).toBe('Active');
    expect(req.request.params.get('from')).toBe('2026-01-01');
    expect(req.request.params.get('to')).toBe('2026-12-31');
    expect(req.request.params.get('page')).toBe('3');
    req.flush({ items: [POLICY_JSON], total: 51, page: 3, pageSize: 25 });
    expect(got.total).toBe(51);
  });

  it('adminList builds status/tier/sortOrder filters (FR9.1)', () => {
    svc.adminList({ status: 'Pending', tier: 'Tier A', sortOrder: 'asc', page: 2 }).subscribe();
    const req = ctrl.expectOne((r) => r.url === '/api/policies');
    expect(req.request.params.get('status')).toBe('Pending');
    expect(req.request.params.get('tier')).toBe('Tier A');
    expect(req.request.params.get('sortOrder')).toBe('asc');
    req.flush({ items: [], total: 0 });
  });

  it('get splits a comma-separated addOns string and coerces null dates', () => {
    let got: any;
    svc.get('p-1').subscribe((r) => (got = r));
    ctrl.expectOne('/api/policies/p-1').flush({ ...POLICY_JSON, addOns: 'Rental Car', startDateUtc: null, endDateUtc: null });
    expect(got.addOns).toEqual(['Rental Car']);
    expect(got.startDateUtc).toBeNull();
  });

  it('pay posts an empty body to the pay endpoint (FR4.4/FR6.1)', () => {
    let got: any;
    svc.pay('p-1').subscribe((r) => (got = r));
    const req = ctrl.expectOne('/api/policies/p-1/pay');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});
    req.flush({ policyId: 'p-1', policyNumber: 'POL-2026-0001', status: 'Active', startDateUtc: 'x', endDateUtc: 'y' });
    expect(got.status).toBe('Active');
  });

  it('cancel issues a DELETE (FR4.5)', () => {
    let done = false;
    svc.cancel('p-1').subscribe(() => (done = true));
    const req = ctrl.expectOne('/api/policies/p-1');
    expect(req.request.method).toBe('DELETE');
    req.flush(null, { status: 204, statusText: 'No Content' });
    expect(done).toBeTrue();
  });

  it('renew posts to the renew endpoint (FR4.7)', () => {
    let got: any;
    svc.renew('p-1').subscribe((r) => (got = r));
    const req = ctrl.expectOne('/api/policies/p-1/renew');
    expect(req.request.method).toBe('POST');
    req.flush({ newPolicyId: 'p-2', newPolicyNumber: 'POL-2026-0002', previousPremiumInr: 720000, claimsRatio: 0.8, band: 'Surcharge15', reviewRequired: false, adjustedPremiumInr: 828000 });
    expect(got.band).toBe('Surcharge15');
    expect(got.adjustedPremiumInr).toBe(828000);
  });
});
