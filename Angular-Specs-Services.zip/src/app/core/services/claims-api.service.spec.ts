import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { ClaimsApiService } from './claims-api.service';

// ClaimsApiService (§9 core coverage): every role slice — company, surveyor, admin.

const CLAIM_ROW = {
  id: 'c-1',
  claimNumber: 'CLM-2026-0001',
  vehicleNumber: 'TS09AB1234',
  claimType: 'Own Vehicle Damage',
  incidentAtUtc: '2026-09-15T09:00:00Z',
  claimedAmountInr: 55000,
  status: 'AwaitingSurveyorPickup',
  isFlagged: false,
  finalPayoutAmountInr: undefined,
};

describe('ClaimsApiService', () => {
  let svc: ClaimsApiService;
  let ctrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    svc = TestBed.inject(ClaimsApiService);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  // company
  it('file posts the intake body (FR5.1)', () => {
    svc.file({} as any).subscribe();
    const req = ctrl.expectOne('/api/claims');
    expect(req.request.method).toBe('POST');
    req.flush({});
  });

  it('mine maps status + incident range params and null-safe payout (FR9.4)', () => {
    let got: any;
    svc.mine({ status: 'Paid', from: '2026-01-01', to: '2026-12-31', page: 2 }).subscribe((r) => (got = r));
    const req = ctrl.expectOne((r) => r.url === '/api/claims/company');
    expect(req.request.params.get('status')).toBe('Paid');
    expect(req.request.params.get('incidentFrom')).toBe('2026-01-01');
    expect(req.request.params.get('incidentTo')).toBe('2026-12-31');
    req.flush({ items: [CLAIM_ROW], page: 2, pageSize: 25, total: 30 });
    expect(got.total).toBe(30);
    expect(got.items[0].finalPayoutAmountInr).toBeNull();
  });

  it('get hits the detail endpoint (FR5.17)', () => {
    svc.get('c-1').subscribe();
    ctrl.expectOne('/api/claims/c-1').flush({});
  });

  // surveyor
  it('queue sends isFlagged only when set (FR9.3)', () => {
    svc.queue({ isFlagged: true }).subscribe();
    const req = ctrl.expectOne((r) => r.url === '/api/claims/queue');
    expect(req.request.params.get('isFlagged')).toBe('true');
    req.flush({ items: [], total: 0 });
  });

  it('assigned paginates', () => {
    svc.assigned(4, 1).subscribe();
    const req = ctrl.expectOne((r) => r.url === '/api/claims/assigned');
    expect(req.request.params.get('page')).toBe('4');
    expect(req.request.params.get('pageSize')).toBe('1');
    req.flush({ items: [], total: 0 });
  });

  it('pickup / verify-field / report post to their action endpoints (FR5.9/5.10/5.13)', () => {
    svc.pickup('c-1').subscribe();
    svc.verifyField('c-1', { fieldName: 'DriverInfo', status: 'Verified', note: 'ok' }).subscribe();
    svc.submitReport('c-1', { overallOutcome: 'Genuine', recommendation: 'Approve', recommendedAmountInr: 50000, notes: 'verified all' }).subscribe();

    const p = ctrl.expectOne('/api/claims/c-1/pickup');
    const v = ctrl.expectOne('/api/claims/c-1/verify-field');
    const r = ctrl.expectOne('/api/claims/c-1/report');
    expect(p.request.method).toBe('POST');
    expect(v.request.body.status).toBe('Verified');
    expect(r.request.body.recommendation).toBe('Approve');
    p.flush(null, { status: 204, statusText: 'No Content' });
    v.flush(null, { status: 204, statusText: 'No Content' });
    r.flush(null, { status: 204, statusText: 'No Content' });
  });

  // admin
  it('adminList sends the full FR9.2 filter set', () => {
    svc.adminList({ search: 'TS09', status: 'Paid', claimType: 'Rental Car', isFlagged: true, sortOrder: 'asc', page: 2 }).subscribe();
    const req = ctrl.expectOne((r) => r.url === '/api/claims');
    const ps = req.request.params;
    expect(ps.get('search')).toBe('TS09');
    expect(ps.get('status')).toBe('Paid');
    expect(ps.get('claimType')).toBe('Rental Car');
    expect(ps.get('isFlagged')).toBe('true');
    expect(ps.get('sortOrder')).toBe('asc');
    expect(ps.get('page')).toBe('2');
    req.flush({ items: [], total: 0 });
  });

  it('review GETs the review DTO (FR5.14)', () => {
    svc.review('c-1').subscribe();
    ctrl.expectOne('/api/claims/c-1/review').flush({});
  });

  it('decide posts the decision and surfaces the 200 result (FR5.15/FR6.1)', () => {
    let got: any;
    svc.decide('c-1', { decision: 'Approve', finalAmountInr: 48000, overrideNote: null }).subscribe((r) => (got = r));
    const req = ctrl.expectOne('/api/claims/c-1/decision');
    expect(req.request.method).toBe('POST');
    expect(req.request.body.finalAmountInr).toBe(48000);
    req.flush({ claimId: 'c-1', claimNumber: 'CLM-2026-0001', status: 'Paid', finalPayoutAmountInr: 48000 });
    expect(got.status).toBe('Paid');
  });
});
