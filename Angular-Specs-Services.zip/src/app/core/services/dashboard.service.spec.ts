import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { DashboardService } from '../../features/dashboard/services/dashboard.service';

// DashboardService (FR7.1).

describe('DashboardService', () => {
  let svc: DashboardService;
  let ctrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    svc = TestBed.inject(DashboardService);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('get fetches the aggregated dashboard', () => {
    let got: any;
    svc.get().subscribe((r) => (got = r));

    const req = ctrl.expectOne('/api/dashboard');
    expect(req.request.method).toBe('GET');
    req.flush({
      metrics: {
        activePolicies: 9,
        claimsThisMonth: 3,
        totalPayoutThisMonthInr: 155000,
        approvalToRejectionRatio: null, // zero rejections this month
        quoteConversionRate: 0.62,
      },
      reviewRequiredRenewalCount: 1,
      reviewRequiredRenewals: [],
    });

    expect(got.metrics.activePolicies).toBe(9);
    expect(got.metrics.approvalToRejectionRatio).toBeNull();
    expect(got.reviewRequiredRenewalCount).toBe(1);
  });
});
