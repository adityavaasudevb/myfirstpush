import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { AdminSurveyorService } from '../../features/admin/services/admin-surveyor.service';

// AdminSurveyorService — the surveyor approval gate (FR2A.3).

const ROW = {
  id: 's-1',
  fullName: 'Raj Surveyor',
  email: 'raj.surveyor@example.in',
  contactInfo: '9876501234',
  irdaiLicenseNumber: 'IRDAI/SLA/12345',
  licenseValidUntil: '2027-06-30T00:00:00Z',
  status: 'Pending',
};

describe('AdminSurveyorService', () => {
  let svc: AdminSurveyorService;
  let ctrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    svc = TestBed.inject(AdminSurveyorService);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('pending GETs the pending list', () => {
    let got: any;
    svc.pending().subscribe((r) => (got = r));
    const req = ctrl.expectOne('/api/surveyors/pending');
    expect(req.request.method).toBe('GET');
    req.flush([ROW]);
    expect(got.length).toBe(1);
    expect(got[0].irdaiLicenseNumber).toBe('IRDAI/SLA/12345');
  });

  it('pending maps a null body to an empty list', () => {
    let got: any;
    svc.pending().subscribe((r) => (got = r));
    ctrl.expectOne('/api/surveyors/pending').flush(null);
    expect(got).toEqual([]);
  });

  it('approve posts an empty body', () => {
    let got: any;
    svc.approve('s-1').subscribe((r) => (got = r));
    const req = ctrl.expectOne('/api/surveyors/s-1/approve');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});
    req.flush({ message: 'Surveyor approved.' });
    expect(got.message).toBe('Surveyor approved.');
  });

  it('reject sends the reason in the body', () => {
    svc.reject('s-1', 'Licence number could not be verified').subscribe();
    const req = ctrl.expectOne('/api/surveyors/s-1/reject');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ reason: 'Licence number could not be verified' });
    req.flush({ message: 'Surveyor rejected.' });
  });
});
