import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { QuoteService } from './quote.service';

// QuoteService (§9 core coverage): request shapes, query params, and the
// field-name normalization the templates rely on.

const QUOTE_JSON = {
  id: 'q-1',
  quoteNumber: 'QT-2026-0001',
  fleetSize: 25,
  tier: 'Tier B',
  addOns: ['Physical Damage'],
  estimatedPremiumInr: 702000,
  estimatedPremiumUsd: 8424.5,
  estimatedPremiumEur: 7721.3,
  usedFallbackRate: true,
  status: 'Active',
  createdDate: '2026-10-01T09:00:00Z',
  expiryDate: '2026-10-08T09:00:00Z',
};

describe('QuoteService', () => {
  let svc: QuoteService;
  let ctrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    svc = TestBed.inject(QuoteService);
    ctrl = TestBed.inject(HttpTestingController);
  });

  afterEach(() => ctrl.verify());

  it('create posts the request and unwraps { quote, alternateTier } (FR3.2)', () => {
    let got: any;
    svc.create({ fleetSize: 25, tier: 'Tier B', addOns: ['Physical Damage'] }).subscribe((r) => (got = r));

    const req = ctrl.expectOne('/api/quotes');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ fleetSize: 25, tier: 'Tier B', addOns: ['Physical Damage'] });
    req.flush({ quote: QUOTE_JSON, alternateTier: { tier: 'Tier A', estimatedPremiumInr: 450000 } });

    expect(got.quote.quoteNumber).toBe('QT-2026-0001');
    expect(got.quote.premiumInr).toBe(702000); // estimatedPremiumInr → premiumInr
    expect(got.quote.usedFallbackRate).toBeTrue();
    expect(got.quote.expiresAtUtc).toBe('2026-10-08T09:00:00Z'); // expiryDate alias
    expect(got.alternateTier.tier).toBe('Tier A');
    expect(got.alternateTier.premiumInr).toBe(450000);
  });

  it('create tolerates a bare quote payload (no wrapper)', () => {
    let got: any;
    svc.create({ fleetSize: 5, tier: 'Tier A', addOns: [] }).subscribe((r) => (got = r));
    ctrl.expectOne('/api/quotes').flush(QUOTE_JSON);
    expect(got.quote.id).toBe('q-1');
    expect(got.alternateTier.premiumInr).toBe(0);
  });

  it('mine sends paging + optional status and keeps the server total (FR3.5/FR9.4)', () => {
    let got: any;
    svc.mine(2, 'Active').subscribe((r) => (got = r));

    const req = ctrl.expectOne((r) => r.url === '/api/quotes/company');
    expect(req.request.params.get('page')).toBe('2');
    expect(req.request.params.get('pageSize')).toBe('25');
    expect(req.request.params.get('status')).toBe('Active');
    req.flush({ items: [QUOTE_JSON], page: 2, pageSize: 25, total: 41 });

    expect(got.total).toBe(41);
    expect(got.items.length).toBe(1);
    expect(got.items[0].premiumInr).toBe(702000);
  });

  it('mine(pageSize=1) supports cheap count reads', () => {
    svc.mine(1, undefined, 1).subscribe();
    const req = ctrl.expectOne((r) => r.url === '/api/quotes/company');
    expect(req.request.params.get('status')).toBeNull();
    expect(req.request.params.get('pageSize')).toBe('1');
    req.flush({ items: [], total: 0 });
  });

  it('get normalizes a comma-separated addOns string defensively', () => {
    let got: any;
    svc.get('q-1').subscribe((r) => (got = r));
    ctrl.expectOne('/api/quotes/q-1').flush({ ...QUOTE_JSON, addOns: 'Physical Damage, Rental Car' });
    expect(got.addOns).toEqual(['Physical Damage', 'Rental Car']);
  });
});
