import { MoneyPipe } from './money-pipe';

// money pipe — en-IN grouping; null-safe em-dash for undecided amounts.

describe('MoneyPipe', () => {
  const pipe = new MoneyPipe();

  it('formats INR in the en-IN grouping style', () => {
    expect(pipe.transform(702000)).toContain('7,02,000');
    expect(pipe.transform(1000)).toContain('1,000');
  });

  it('renders ₹0 rather than a dash', () => {
    expect(pipe.transform(0)).toContain('0');
    expect(pipe.transform(0)).not.toBe('—');
  });

  it('renders an em-dash for null/undefined (undecided amounts)', () => {
    expect(pipe.transform(null)).toBe('—');
    expect(pipe.transform(undefined)).toBe('—');
  });
});
