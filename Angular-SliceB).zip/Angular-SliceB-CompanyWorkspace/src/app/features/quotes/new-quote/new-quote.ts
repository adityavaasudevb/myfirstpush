import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { QuoteService } from '../../../core/services/quote.service';
import { CreateQuoteResponse, TierName } from '../../../core/models/quote.model';
import { TIER_OPTIONS, ADD_ON_OPTIONS } from '../../../core/constants/pricing';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-new-quote',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe],
  templateUrl: './new-quote.html',
  styleUrl: './new-quote.css',
})
export class NewQuote {
  private readonly fb = inject(FormBuilder);
  private readonly quotes = inject(QuoteService);

  readonly tiers = TIER_OPTIONS;
  readonly addOns = ADD_ON_OPTIONS;

  readonly form = this.fb.nonNullable.group({
    fleetSize: [25, [Validators.required, Validators.min(1)]],
    tier: ['Tier B' as TierName, Validators.required],
  });

  private readonly selectedAddOns = signal<ReadonlySet<string>>(new Set());
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly result = signal<CreateQuoteResponse | null>(null);

  hasAddOn(key: string): boolean {
    return this.selectedAddOns().has(key);
  }

  toggleAddOn(key: string): void {
    const next = new Set(this.selectedAddOns());
    next.has(key) ? next.delete(key) : next.add(key);
    this.selectedAddOns.set(next);
    this.result.set(null); // changing inputs invalidates the shown estimate
  }

  invalidateEstimate(): void {
    this.result.set(null);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Converted':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  formatFx(value: number, ccy: 'USD' | 'EUR'): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: ccy,
      maximumFractionDigits: 0,
    }).format(value);
  }

  estimate(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    const v = this.form.getRawValue();
    this.quotes
      .create({ fleetSize: v.fleetSize, tier: v.tier as TierName, addOns: [...this.selectedAddOns()] })
      .subscribe({
        next: (res) => {
          this.result.set(res);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }
}
