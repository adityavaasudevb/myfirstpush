import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CreateQuoteResponse, Quote, QuoteRequest } from '../models/quote.model';

const API = environment.apiBaseUrl;

// QuoteService client (doc §6.3). POST creates AND persists the quote;
// ownership comes from the caller's token, never from the request body.
@Injectable({ providedIn: 'root' })
export class QuoteService {
  private readonly http = inject(HttpClient);

  /** FR3.1/FR3.2 — estimate + persist; response includes the alternate-tier estimate. */
  create(body: QuoteRequest): Observable<CreateQuoteResponse> {
    return this.http.post<CreateQuoteResponse>(`${API}/quotes`, body);
  }

  /** FR: caller's own quotes (EffectiveStatus already applied by the server). */
  mine(): Observable<Quote[]> {
    return this.http.get<Quote[]>(`${API}/quotes/company`);
  }

  get(id: string): Observable<Quote> {
    return this.http.get<Quote>(`${API}/quotes/${id}`);
  }

  /** FR3.4 — echoes the stored inputs back; InsuranceService cross-checks these
   *  when the quote is used to apply for a policy (next step will wire this). */
  convert(id: string): Observable<unknown> {
    return this.http.post(`${API}/quotes/${id}/convert`, {});
  }
}
