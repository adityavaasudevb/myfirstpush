# Slice B — Company Workspace: Step B1 (New Quote) · REVISED

**Contract now verified against the real QuoteService code** (QuoteDtos.cs + QuotesController.cs):
- Tiers: canonical strings **`"Tier A"` / `"Tier B"`**
- Add-ons: **`Physical Damage` / `Uninsured Motorist` / `Medical Payments` / `Rental Car`**
- Response = `{ quote: {…, premiumInr, estimatedPremiumUsd, estimatedPremiumEur, usedFallbackRate, status, expiresAtUtc}, alternateTier: { tier, premiumInr } }`
- **No client-side premium math at all** (doc Section 3 forbids it).

## 0 · Clean up the first draft on your laptop
1. `styles.css`: append everything from this zip's `src/styles-additions.css`
   (defines `.btn-secondary`, `.nav-link`, `.nav-active` — several Slice A pages
   were using classes that never existed; this styles them).
2. File moves (your new convention — services/models/constants under `core/`):
   - delete `src/app/features/quotes/services/` and `src/app/features/quotes/models/` and `src/app/features/quotes/constants/` (feature folder keeps components only)
   - `quote.service.ts` (+ its new spec) → `src/app/core/services/`
   - `quote.model.ts` → `src/app/core/models/`
   - `pricing.ts` → `src/app/core/constants/`
3. Replace these files with the zip versions:
   - `core/models/quote.model.ts`, `core/constants/pricing.ts`, `core/services/quote.service.ts`, `core/services/quote.service.spec.ts`
   - `features/quotes/new-quote/new-quote.ts` + `.html` + `.spec.ts`
   - `shared/ui/money-pipe.ts`
   - `shared/layouts/app-layout/app-layout.ts` + `.html` (**role-based nav links** now: Company gets Workspace + New quote; active pill highlighting)
   - `features/dashboard/company-dashboard/company-dashboard.html` (quick actions: New quote is live, other two muted — this supersedes your manual button edit)
4. If your generated specs had the class in `imports: [...]`, the zip specs fix that
   (services are provided, not imported).

## 1 · Routes (unchanged from before)
`app.routes.ts`, company children: `{ path: 'quotes/new', component: NewQuote }`.

## 2 · Verify against the seeded numbers
Get estimate for **fleet 25 · Tier B · Physical Damage + Uninsured Motorist** →
expect **₹7,02,000** (25 × ₹15,000 × 1.6 × 1.17 — matches the seeded Converted quote Q-2026-AA0001)
and **alternate tier "Tier A" → ₹4,38,750**. If both match, the UI is wired to the real pricing engine.
