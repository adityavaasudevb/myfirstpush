import { Routes } from '@angular/router';
import { PublicLayout } from './shared/layouts/public-layout/public-layout';
import { AppLayout } from './shared/layouts/app-layout/app-layout';
import { Landing } from './features/landing/landing';
import { RoleCards } from './features/auth/role-cards/role-cards';
import { Login } from './features/auth/login/login';
import { RegisterCompany } from './features/auth/register-company/register-company';
import { RegisterSurveyor } from './features/auth/register-surveyor/register-surveyor';
import { Onboarding } from './features/company-profile/onboarding/onboarding';
import { CompanyDashboard } from './features/dashboard/company-dashboard/company-dashboard';
import { SurveyorQueue } from './features/claims/surveyor-queue/surveyor-queue';
import { AdminDashboard } from './features/dashboard/admin-dashboard/admin-dashboard';
import { guestGuard, roleGuard } from './core/guards/auth.guard';
import { companyProfileGuard, onboardingGuard } from './features/company-profile/company-profile.guard';

export const routes: Routes = [
  // ---- Public chrome ----
  {
    path: '',
    component: PublicLayout,
    children: [
      { path: '', component: Landing },
      { path: 'auth', component: RoleCards, canActivate: [guestGuard] },
      { path: 'auth/login/:role', component: Login, canActivate: [guestGuard] },
      { path: 'auth/register/company', component: RegisterCompany, canActivate: [guestGuard] },
      { path: 'auth/register/surveyor', component: RegisterSurveyor, canActivate: [guestGuard] },
    ],
  },

  // ---- Authenticated chrome ----
  {
    path: '',
    component: AppLayout,
    children: [
      {
        path: 'company',
        canActivate: [roleGuard(['Company'])],
        children: [
          { path: '', component: CompanyDashboard, canActivate: [companyProfileGuard] },
          { path: 'onboarding', component: Onboarding, canActivate: [onboardingGuard] },
        ],
      },
      { path: 'surveyor', component: SurveyorQueue, canActivate: [roleGuard(['Surveyor'])] },
      { path: 'admin', component: AdminDashboard, canActivate: [roleGuard(['Admin'])] },
    ],
  },

  { path: '**', redirectTo: '' },
];
