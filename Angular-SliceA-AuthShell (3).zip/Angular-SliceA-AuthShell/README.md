# Slice A — Auth Shell + Landing (Angular 21, CSR-only, Tailwind 4, Vitest)

Foundation pack: Hartford theme, app shell with role navbar, token-in-memory auth with
cookie refresh, guards, styled toasts, landing page, role cards, logins, both registers,
and one-time fleet-profile onboarding. Every role lands at a styled placeholder workspace
(slices B/C/D replace them).

## 0 · One-time setup (in your existing repo)

**0.1 Strip SSR → CSR-only** (decision locked — keeps the mental model simple):
- Delete: `src/app/app.config.server.ts`, `src/main.server.ts`, `src/server.ts`
- `angular.json` → `projects.<name>.architect.build.options`: remove `"server"`,
  `"prerender"`, `"ssr"` keys (leave everything else)
- `package.json` → remove the `"serve:ssr:…"` script line. The `@angular/ssr`,
  `@angular/platform-server`, `express`, `@types/express` deps can stay installed
  (harmless) or be removed with `npm uninstall` — your choice.
- `src/main.ts` should read:
  ```ts
  import { bootstrapApplication } from '@angular/platform-browser';
  import { appConfig } from './app/app.config';
  import { AppComponent } from './app/app';
  bootstrapApplication(AppComponent, appConfig).catch((err) => console.error(err));
  ```
  (Adjust the AppComponent import name to whatever `ng new` generated —
  this pack's `src/app/app.ts` exports `AppComponent`.)

**0.2 Proxy** — put `proxy.conf.json` at repo root and change the start script:
```json
"start": "ng serve --proxy-config proxy.conf.json"
```
Gateway must run on `http://localhost:5000` whenever you `npm start`.

**0.3 Theme** — **replace** `src/styles.css` entirely with this pack's `src/styles.css`
(Tailwind 4: `@import "tailwindcss"` + Hartford `@theme` tokens + `.btn-*`/`.input`/`.card`
component classes). No `tailwind.config.js` — v4 is CSS-first, and you enabled it at `ng new`.

## 1 · Files in this pack — FINAL capability-first structure (doc §10A)

> **Delivery protocol (user's office workflow):** files arrive step-by-step in chat —
> one CLI command (e.g. `ng g c features/auth/login`) + the content to paste into the
> generated file + a one-line verify. The tree below is the canonical destination map.

```
proxy.conf.json
src/environments/environment.ts · environment.development.ts
src/styles.css                                    Hartford @theme tokens + component classes
src/app/app.config.ts                             router + http interceptors + session bootstrap
src/app/app.routes.ts                             layouts wrap public vs authenticated chrome
src/app/app.ts                                    toast + router-outlet only

src/app/core/
├── constants/          roles.ts · tier.ts · app-routes.ts
├── guards/             auth.guard.ts (roleGuard · guestGuard · homeForRole)
├── interceptors/       auth.interceptor.ts (Bearer · cookie · 401→single-flight refresh→retry)
│                       error.interceptor.ts (correlation-ID toasts for 5xx/network; SKIP_ERROR_TOAST ctx token)
├── services/           auth.service.ts (memory token · session state · auth calls)
└── models/             user-context.model.ts · paged-result.model.ts · api-error.model.ts  (shared only)

src/app/shared/
├── layouts/public-layout/    slim brand header + footer (landing, auth pages)
├── layouts/app-layout/       sticky role-navbar + sign-out (workspaces)
└── toast/toast.ts            AlertService + AlertsComponent (one file)

src/app/features/
├── landing/landing.page.ts                   Hartford hero · tiers · add-ons · how-it-works
├── auth/
│   ├── models/auth.model.ts                  LoginRequest/Response · MessageResponse · SurveyorRegisterRequest
│   ├── role-cards/                           continue-as cards + admin link
│   ├── login/                                role-aware; pending/rejected surveyor banners
│   ├── register-company/                     email+password → login w/ success banner
│   └── register-surveyor/                    IRDAI form → toast → landing
├── company-profile/
│   ├── models/company-profile.model.ts
│   ├── services/company-profile.service.ts   404 = "no profile yet" signal
│   ├── company-profile.guard.ts              workspace↔onboarding gates
│   └── onboarding/                           one-time fleet profile creation
├── quotes/models/quote.model.ts              (slice B adds service + pages)
├── policies/models/policy.model.ts           (slice B)
├── claims/models/claim.model.ts              (slices B/C/D)
│   └── surveyor-queue/                       (slice C replaces placeholder)
└── dashboard/
    ├── models/dashboard.model.ts             (slice D)
    ├── company-dashboard/                    (slice B replaces welcome panel)
    └── admin-dashboard/                      (slice D)
```

## 2 · Run order

1. Start all 4 services + gateway (gateway healthy on :5000 first).
2. `npm start` → http://localhost:4200
3. Landing renders (claret hero, tiers, add-ons, H-monogram ring).

## 3 · Verification checklist (match = pass)

| # | Action | Expected |
|---|---|---|
| V1 | Open `/` | Hartford landing; Sign in / Get started → `/auth` role cards |
| V2 | Login `company@swiftfleet.in` / `SwiftFleet@2026Ride` | Lands `/company` placeholder; navbar shows email + Company; DevTools shows `accessToken` only in memory (nothing in localStorage) |
| V3 | Refresh the page (F5) on `/company` | Session restores silently via cookie — **still signed in** (this proves the refresh flow) |
| V4 | Login `pending.surveyor@claimsurvey.in` | Amber banner: "awaiting admin approval" — no crash, stays on login |
| V5 | Wrong password for swiftfleet | Red banner: "Invalid email or password." |
| V6 | Register a new company (Register here) | Redirected to login with green "Account created" banner; sign in → **auto-redirected to `/company/onboarding`**; create profile → workspace |
| V7 | Register a new surveyor | Green toast "Application received…", back on landing; admin sees them in pending list (Swagger check) |
| V8 | Directly hit `/admin` while signed in as company | Bounced back to `/company` (roleGuard) |
| V9 | Sign out | Cookie cleared server-side; `/company` now redirects to `/auth` |

## 4 · Two checkpoints (the only guessed shapes — 1-line fixes if needed)

- **`GET /api/auth/me` shape** — modeled `{ id, email, role }`. If yours differs
  (e.g. `userId` instead of `id`), rename it in `core/models.ts → SessionUser` only.
- **Profile create field name** — DTO posts `registrationNumber` (matches your DB column).
  If Swagger's request schema shows `registrationNo`, rename in:
  `models.ts → CompanyProfileRequest` + `profile-create.page.ts` form control name/label.

## 5 · Not in this slice (on purpose)

Workspace screens for all three roles (slices B/C/D), tests (final test phase),
`GET /api/companies/me` render (slice B reads it), claims lists/detail (slice B).

## Architecture notes (worth knowing for the viva)

- **Token discipline:** access token lives in a private field on AuthService (memory only);
  refresh is an HttpOnly cookie the browser sends automatically (`withCredentials: true`
  set in the interceptor for every `/api` call). Angular never touches the refresh token
  field that the API echoes in the JSON body.
- **Silent recovery:** any 401 → one shared refresh request (`shareReplay(1)` single-flight)
  → original request retried with the new token. Concurrent calls queue behind it.
- **Fresh-company gate:** `GET /api/companies/me` returning 404 *is the signal* for
  onboarding — no local flags, the backend is the source of truth.
- **Pending surveyor** is decided at login by the backend's 403
  (`SURVEYOR_PENDING_APPROVAL`) — the UI just translates it into a friendly banner.
