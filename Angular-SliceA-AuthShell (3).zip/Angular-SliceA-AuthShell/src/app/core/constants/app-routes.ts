// Route path constants (doc §10A routing table) — single source for links and navigation.
export const APP_ROUTES = {
  landing: '/',
  auth: '/auth',
  login: (role: 'company' | 'surveyor' | 'admin') => `/auth/login/${role}`,
  registerCompany: '/auth/register/company',
  registerSurveyor: '/auth/register/surveyor',
  company: '/company',
  companyOnboarding: '/company/onboarding',
  surveyor: '/surveyor',
  admin: '/admin',
} as const;
