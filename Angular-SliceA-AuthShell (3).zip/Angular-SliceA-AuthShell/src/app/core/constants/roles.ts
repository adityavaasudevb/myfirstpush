// Canonical role names — must match the backend JWT `role` claim exactly.
export type Role = 'Company' | 'Surveyor' | 'Admin';

export const ROLES = {
  Company: 'Company',
  Surveyor: 'Surveyor',
  Admin: 'Admin',
} as const;
