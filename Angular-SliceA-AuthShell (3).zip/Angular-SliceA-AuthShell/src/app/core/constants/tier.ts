// Coverage tiers — shared by quotes, policies and claims (design doc §3).
export type Tier = 'Tier A' | 'Tier B';

export const TIERS = {
  A: 'Tier A',
  B: 'Tier B',
} as const;
