// Standardized error envelope returned by every backend service (FR8.4).
export interface ApiError {
  statusCode?: number;
  errorCode?: string;
  message?: string;
  correlationId?: string;
}
