// Shared pagination envelope (BuildingBlocks.PagedResult<T>, FR9):
// every list endpoint returns this shape.
export interface PagedResult<T> {
  items: T[];
  totalCount: number;
  page: number;
  pageSize: number;
}
