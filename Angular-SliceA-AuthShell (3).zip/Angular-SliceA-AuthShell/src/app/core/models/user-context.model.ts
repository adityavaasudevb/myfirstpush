import { Role } from '../constants/roles';

// The signed-in session — populated from GET /api/auth/me and used by
// guards, the interceptor and the app-layout navbar.
export interface SessionUser {
  id: string;
  email: string;
  role: Role;
}
