import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { Role } from '../constants/roles';
import { APP_ROUTES } from '../constants/app-routes';

/** roleGuard(['Company']) — requires a session with one of the given roles.
 *  Wrong role → bounced to their own home; guest → role pick. */
export function roleGuard(roles: Role[]): CanActivateFn {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);
    const role = auth.role();
    if (role && roles.includes(role)) return true;
    return router.createUrlTree(role ? [homeForRole(role)] : [APP_ROUTES.auth]);
  };
}

/** guestGuard — auth pages are guests-only; signed-in users go to their workspace. */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const role = auth.role();
  return role ? router.createUrlTree([homeForRole(role)]) : true;
};

export function homeForRole(role: Role): string {
  switch (role) {
    case 'Company':
      return APP_ROUTES.company;
    case 'Surveyor':
      return APP_ROUTES.surveyor;
    case 'Admin':
      return APP_ROUTES.admin;
  }
}
