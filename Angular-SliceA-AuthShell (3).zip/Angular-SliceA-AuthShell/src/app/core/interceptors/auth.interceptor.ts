import { inject } from '@angular/core';
import { HttpInterceptorFn, HttpRequest, HttpHandlerFn } from '@angular/common/http';
import { catchError, switchMap, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';

// ============================================================
// Attaches the in-memory Bearer token to every /api call, sends cookies
// (refresh token), and retries once after a silent refresh on 401.
// ============================================================
const NO_RETRY = ['/api/auth/login', '/api/auth/refresh', '/api/surveyors/register', '/api/auth/register'];

export const authInterceptor: HttpInterceptorFn = (req: HttpRequest<unknown>, next: HttpHandlerFn) => {
  if (!req.url.startsWith('/api')) return next(req);

  const auth = inject(AuthService);
  const send = (r: HttpRequest<unknown>) => {
    const token = auth.token();
    const out = r.clone({
      withCredentials: true,
      ...(token ? { setHeaders: { Authorization: `Bearer ${token}` } } : {}),
    });
    return next(out);
  };

  return send(req).pipe(
    catchError((err) => {
      const skipRetry = NO_RETRY.some((p) => req.url.includes(p));
      if (err?.status === 401 && !skipRetry) {
        return auth.refreshOnce().pipe(
          switchMap((u) => {
            if (!u) return throwError(() => err); // refresh failed → login flow takes over in guard/user action
            return send(req);
          }),
        );
      }
      return throwError(() => err);
    }),
  );
};
