import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { catchError, finalize, map, shareReplay, switchMap, tap } from 'rxjs/operators';
import { LoginResponse, MessageResponse, SurveyorRegisterRequest } from '../../features/auth/models/auth.model';
import { SessionUser } from '../models/user-context.model';
import { Role } from '../constants/roles';
import { environment } from '../../../environments/environment';

const API = environment.apiBaseUrl;

// ============================================================
// AuthService — access token lives in MEMORY only (never localStorage).
// Session restore on app start goes through the HttpOnly refresh cookie.
// ============================================================
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  readonly user = signal<SessionUser | null>(null);
  private accessToken: string | null = null;
  private refreshing$: Observable<SessionUser | null> | null = null;

  token(): string | null {
    return this.accessToken;
  }
  role(): Role | null {
    return this.user()?.role ?? null;
  }

  /** Called once by the app initializer — restores a session if a valid
   *  refresh cookie exists; swallows failures (guest sessions are fine). */
  bootstrap(): Observable<void> {
    return this.refreshOnce().pipe(map(() => undefined));
  }

  login(email: string, password: string): Observable<SessionUser> {
    return this.http
      .post<LoginResponse>(`${API}/auth/login`, { email, password }, { withCredentials: true })
      .pipe(
        tap((res) => (this.accessToken = res.accessToken)),
        switchMap(() => this.me()),
        tap((u) => this.user.set(u)),
      );
  }

  me(): Observable<SessionUser> {
    return this.http.get<SessionUser>(`${API}/auth/me`);
  }

  /** Single-flight refresh — concurrent 401s share one rotating request. */
  refreshOnce(): Observable<SessionUser | null> {
    if (!this.refreshing$) {
      this.refreshing$ = this.http
        .post<LoginResponse>(`${API}/auth/refresh`, {}, { withCredentials: true })
        .pipe(
          tap((res) => (this.accessToken = res.accessToken)),
          switchMap(() => this.me()),
          tap((u) => this.user.set(u)),
          catchError(() => of(null)),
          finalize(() => (this.refreshing$ = null)),
          shareReplay(1),
        );
    }
    return this.refreshing$;
  }

  logout(): void {
    this.http
      .post<MessageResponse>(`${API}/auth/logout`, {}, { withCredentials: true })
      .subscribe({ error: () => void 0 });
    this.clearLocal();
    this.router.navigateByUrl('/');
  }

  /** Interceptor calls this when refresh also fails. */
  clearToLogin(): void {
    this.clearLocal();
    this.router.navigateByUrl('/auth/login/company');
  }

  private clearLocal(): void {
    this.accessToken = null;
    this.user.set(null);
  }

  registerCompany(email: string, password: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${API}/auth/register`, { email, password });
  }

  registerSurveyor(body: SurveyorRegisterRequest): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${API}/surveyors/register`, body);
  }
}

export function responseErrorText(err: unknown): string {
  const e = err as { error?: { message?: string; errorCode?: string } };
  return e?.error?.errorCode ?? e?.error?.message ?? 'Something went wrong. Please try again.';
}
