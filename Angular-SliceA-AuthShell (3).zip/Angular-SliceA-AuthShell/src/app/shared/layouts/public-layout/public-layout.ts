import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

// Public layout — slim brand header + footer for landing and auth pages.
@Component({
  selector: 'app-public-layout',
  imports: [RouterOutlet, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './public-layout.html',
  styleUrl: './public-layout.css',
  })
export class PublicLayout {}
