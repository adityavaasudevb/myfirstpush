import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { NgClass } from '@angular/common';
import { AlertService } from './alert.service';

// Toast — renders the AlertService stack (create with: ng g c shared/toast).
@Component({
  selector: 'app-toast',
  imports: [NgClass],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './toast.html',
  styleUrl: './toast.css',
})
export class Toast {
  readonly alerts = inject(AlertService);
}
