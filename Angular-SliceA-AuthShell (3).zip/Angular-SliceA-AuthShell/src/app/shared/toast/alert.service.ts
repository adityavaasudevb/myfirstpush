import { Injectable, signal } from '@angular/core';

// AlertService — app-wide toast notifications (create with: ng g s shared/toast/alert).
export type AlertKind = 'success' | 'error' | 'info';
export interface AlertMsg {
  id: number;
  kind: AlertKind;
  text: string;
}

@Injectable({ providedIn: 'root' })
export class AlertService {
  readonly alerts = signal<AlertMsg[]>([]);
  private nextId = 1;

  show(kind: AlertKind, text: string, autoDismissMs = 4500): void {
    const msg: AlertMsg = { id: this.nextId++, kind, text };
    this.alerts.update((list) => [...list, msg]);
    if (autoDismissMs > 0) {
      setTimeout(() => this.dismiss(msg.id), autoDismissMs);
    }
  }
  success(text: string): void { this.show('success', text); }
  error(text: string): void { this.show('error', text, 6000); }
  info(text: string): void { this.show('info', text); }
  dismiss(id: number): void {
    this.alerts.update((list) => list.filter((a) => a.id !== id));
  }
}
