import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { CompanyProfile, CompanyProfileRequest } from '../models/company-profile.model';
import { environment } from '../../../environments/environment';

const API = environment.apiBaseUrl;

// Company profile state — 404 from /api/companies/me means "no profile yet"
// (fresh registrations) and drives the onboarding redirect.
@Injectable({ providedIn: 'root' })
export class CompanyProfileService {
  private readonly http = inject(HttpClient);
  readonly profile = signal<CompanyProfile | null>(null);

  loadMe(): Observable<CompanyProfile> {
    return this.http.get<CompanyProfile>(`${API}/companies/me`).pipe(
      tap((p) => this.profile.set(p)),
    );
  }

  create(body: CompanyProfileRequest): Observable<CompanyProfile> {
    return this.http.post<CompanyProfile>(`${API}/companies`, body).pipe(
      tap((p) => this.profile.set(p)),
    );
  }

  clear(): void {
    this.profile.set(null);
  }
}
