import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { CompanyProfileService } from './services/company-profile.service';

/** The 404 from GET /api/companies/me IS the "no profile yet" signal (FR2.3).
 *  Workspace → onboarding when missing; onboarding → workspace when present. */
export const companyProfileGuard: CanActivateFn = () => {
  const profiles = inject(CompanyProfileService);
  const router = inject(Router);
  if (profiles.profile()) return true;
  return profiles.loadMe().pipe(
    map(() => true),
    catchError((err) =>
      of(err?.status === 404 ? router.createUrlTree(['/company/onboarding']) : true),
    ),
  );
};

export const onboardingGuard: CanActivateFn = () => {
  const profiles = inject(CompanyProfileService);
  const router = inject(Router);
  if (profiles.profile()) return router.createUrlTree(['/company']);
  return profiles.loadMe().pipe(
    map(() => router.createUrlTree(['/company'])),
    catchError(() => of(true)),
  );
};
