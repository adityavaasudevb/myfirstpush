import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';
import { CompanyProfileService } from '../services/company-profile.service';
import { AlertService } from '../../../shared/toast/alert.service';

// One-time fleet profile creation (FR2.2) — fresh companies land here after
// their first login because GET /api/companies/me returned 404.
@Component({
  selector: 'app-onboarding',
  imports: [ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './onboarding.html',
  styleUrl: './onboarding.css',
  })
export class Onboarding {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly profiles = inject(CompanyProfileService);
  private readonly alerts = inject(AlertService);
  private readonly router = inject(Router);

  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    registrationNumber: ['', Validators.required],
    contactPerson: ['', Validators.required],
    email: [this.auth.user()?.email ?? '', [Validators.required, Validators.email]],
    phone: ['', Validators.required],
    fleetSize: [1, [Validators.required, Validators.min(1)]],
  });

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);

    this.profiles.create(this.form.getRawValue()).subscribe({
      next: () => {
        this.alerts.success('Fleet profile created — welcome aboard.');
        this.router.navigateByUrl('/company');
      },
      error: (err) => {
        this.busy.set(false);
        this.error.set(responseErrorText(err));
      },
    });
  }
}
