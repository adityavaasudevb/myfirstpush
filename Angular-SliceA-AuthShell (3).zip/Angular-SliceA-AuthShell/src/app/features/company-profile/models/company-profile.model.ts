// CustomerService (company profile) models.
export interface CompanyProfileRequest {
  name: string;
  registrationNumber: string;
  contactPerson: string;
  email: string;
  phone: string;
  fleetSize: number;
}
export interface CompanyProfile extends CompanyProfileRequest {
  id: string;
  userId: string;
}
