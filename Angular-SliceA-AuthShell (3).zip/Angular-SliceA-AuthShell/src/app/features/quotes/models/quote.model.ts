// QuoteService models — verified from real JSON (GET /api/quotes/{id}, /api/quotes/company).
import { Tier } from '../../../core/constants/tier';
export type { Tier };

export type QuoteStatus = 'Active' | 'Expired' | 'Converted';

export interface QuoteListItem {
  id: string;
  quoteNumber: string;
  fleetSize: number;
  tier: Tier;
  addOns: string[];
  estimatedPremiumInr: number;
  status: QuoteStatus;
  createdDate: string;
  expiryDate: string;
}
export interface QuoteDetail extends QuoteListItem {
  estimatedPremiumUsd: number;
  estimatedPremiumEur: number;
  usedFallbackRate: boolean;
}
