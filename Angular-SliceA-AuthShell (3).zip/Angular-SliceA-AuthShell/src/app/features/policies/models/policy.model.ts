// InsuranceService policy models — verified from GET /api/policies/company.
import { Tier } from '../../../core/constants/tier';

export type PolicyStatus = 'Pending' | 'Active' | 'Expired' | 'Cancelled';

export interface PolicyListItem {
  id: string;
  policyNumber: string;
  tier: Tier;
  fleetSize: number;
  premiumInr: number;
  status: PolicyStatus;
  reviewRequired: boolean;
  startDateUtc: string | null;
  endDateUtc: string | null;
}
