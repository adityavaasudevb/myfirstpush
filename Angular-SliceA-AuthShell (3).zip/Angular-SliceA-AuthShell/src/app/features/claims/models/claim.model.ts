// InsuranceService claim models — scalars verified from list JSON,
// children verified from the real GET /api/claims/{id} detail shape.
export type ClaimStatus =
  | 'Submitted'
  | 'AwaitingSurveyorPickup'
  | 'UnderInvestigation'
  | 'SurveyorReportSubmitted'
  | 'Paid'
  | 'Rejected';

export interface Claim {
  id: string;
  claimNumber: string;
  policyId: string;
  policyNumber: string;
  driverName: string;
  driverLicenceNumber: string;
  vehicleNumber: string;
  passengerName: string;
  passengerContact: string;
  incidentAtUtc: string;
  incidentLocation: string;
  description: string;
  claimedAmountInr: number;
  claimType: string;
  appNotInUseDeclared: boolean;
  derivedPeriod: string | null;
  preliminaryDecision: 'Approve' | 'Reject' | null;
  preliminaryAmountInr: number | null;
  isFlagged: boolean;
  flagReason: string | null;
  status: ClaimStatus;
  assignedSurveyorId: string | null;
  finalPayoutAmountInr: number | null;
  createdAtUtc: string;
}
export interface TripEvent {
  eventType: string;
  occurredAtUtc: string;
}
export interface FieldVerification {
  fieldName: string;
  status: 'Verified' | 'Suspicious';
  note?: string | null;
}
export interface SurveyorReportView {
  overallOutcome: string;
  recommendation: 'Approve' | 'Reject';
  recommendedAmountInr: number | null;
  notes?: string | null;
  submittedAtUtc?: string;
}
export interface StatusHistoryItem {
  fromStatus?: string | null;
  toStatus: string;
  changedAtUtc?: string;
  changedByUserId?: string;
}
export interface ClaimDetail extends Claim {
  documentLink: string | null;
  tripEvents: TripEvent[];
  fieldVerifications: FieldVerification[];
  report: SurveyorReportView | null;
  statusHistory: StatusHistoryItem[];
}
