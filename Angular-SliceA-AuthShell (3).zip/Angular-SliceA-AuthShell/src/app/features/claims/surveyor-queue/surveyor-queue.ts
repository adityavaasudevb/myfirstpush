import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

// Surveyor workspace — slice C replaces this with the live claim queue,
// pickup, investigation and report screens.
@Component({
  selector: 'app-surveyor-queue',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './surveyor-queue.html',
  styleUrl: './surveyor-queue.css',
  })
export class SurveyorQueue {
  readonly auth = inject(AuthService);
}
