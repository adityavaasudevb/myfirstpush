import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { NgClass } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';
import { homeForRole } from '../../../core/guards/auth-guard';

type LoginRole = 'company' | 'surveyor' | 'admin';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, RouterLink, NgClass],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './login.html',
  styleUrl: './login.css',
  })
export class Login {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  readonly role = signal<LoginRole>((this.route.snapshot.paramMap.get('role') as LoginRole) || 'company');
  readonly busy = signal(false);
  readonly banner = signal<{ kind: 'error' | 'info'; text: string } | null>(null);
  readonly justRegistered = signal(this.route.snapshot.queryParamMap.has('registered'));

  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });

  heading(): string {
    switch (this.role()) {
      case 'surveyor': return 'Surveyor sign in';
      case 'admin': return 'Administrator sign in';
      default: return 'Company sign in';
    }
  }
  subheading(): string {
    switch (this.role()) {
      case 'surveyor': return 'Approved IRDAI surveyors only.';
      case 'admin': return 'Internal access.';
      default: return 'Quotes, policies and claims for your fleet.';
    }
  }

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.banner.set(null);
    const { email, password } = this.form.getRawValue();

    this.auth.login(email, password).subscribe({
      next: (u) => this.router.navigateByUrl(homeForRole(u.role)),
      error: (err) => {
        this.busy.set(false);
        const text = responseErrorText(err);
        if (err?.status === 403 && text.includes('SURVEYOR_PENDING_APPROVAL')) {
          this.banner.set({
            kind: 'info',
            text: 'Your surveyor registration is awaiting admin approval. You will be able to sign in once approved.',
          });
        } else if (err?.status === 403 && text.toLowerCase().includes('reject')) {
          this.banner.set({ kind: 'error', text });
        } else if (err?.status === 401) {
          this.banner.set({ kind: 'error', text: 'Invalid email or password.' });
        } else {
          this.banner.set({ kind: 'error', text });
        }
      },
      complete: () => this.busy.set(false),
    });
  }
}
