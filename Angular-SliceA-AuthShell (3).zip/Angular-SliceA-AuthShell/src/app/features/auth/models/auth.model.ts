import { Role } from '../../../core/constants/roles';

// AuthService API contracts — request/response shapes verified from the
// real endpoints. Refresh flows are handled by the HttpOnly cookie; the
// client never stores or reads the refreshToken field.
export interface LoginRequest {
  email: string;
  password: string;
}
export interface LoginResponse {
  accessToken: string;
  refreshToken?: string;
  role: Role;
}
export interface MessageResponse {
  message: string;
}
export interface SurveyorRegisterRequest {
  email: string;
  password: string;
  name: string;
  contactInfo: string;
  irdaiLicenseNumber: string;
  licenseValidUntil: string; // ISO date (yyyy-mm-dd)
}
