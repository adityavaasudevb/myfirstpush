import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';
import { AlertService } from '../../../shared/toast/alert.service';

// Surveyor application — full IRDAI form; lands in the admin approval queue.
@Component({
  selector: 'app-register-surveyor',
  imports: [ReactiveFormsModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './register-surveyor.html',
  styleUrl: './register-surveyor.css',
  })
export class RegisterSurveyor {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly alerts = inject(AlertService);
  private readonly router = inject(Router);

  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    contactInfo: ['', Validators.required],
    irdaiLicenseNumber: ['', Validators.required],
    licenseValidUntil: ['', Validators.required], // yyyy-mm-dd from <input type=date>
  });

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);

    this.auth.registerSurveyor(this.form.getRawValue()).subscribe({
      next: () => {
        this.alerts.success('Application received — an administrator will review your licence shortly.');
        this.router.navigateByUrl('/');
      },
      error: (err) => {
        this.busy.set(false);
        this.error.set(responseErrorText(err));
      },
    });
  }
}
