import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';

// Role cards: Continue as Company / Surveyor (+ quiet admin link).
@Component({
  selector: 'app-role-cards',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './role-cards.html',
  styleUrl: './role-cards.css',
  })
export class RoleCards {}
