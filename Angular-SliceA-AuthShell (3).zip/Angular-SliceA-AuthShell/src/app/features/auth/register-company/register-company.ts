import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';

// Company registration — email + password only (profile comes after first login).
@Component({
  selector: 'app-register-company',
  imports: [ReactiveFormsModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './register-company.html',
  styleUrl: './register-company.css',
  })
export class RegisterCompany {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);
    const { email, password } = this.form.getRawValue();

    this.auth.registerCompany(email, password).subscribe({
      next: () =>
        this.router.navigate(['/auth/login/company'], { queryParams: { registered: 1 } }),
      error: (err) => {
        this.busy.set(false);
        this.error.set(responseErrorText(err));
      },
    });
  }
}
