// InsuranceService dashboard models — verified from GET /api/dashboard.
import { PolicyListItem } from '../../policies/models/policy.model';

export interface DashboardResponse {
  metrics: {
    activePolicies: number;
    claimsThisMonth: number;
    totalPayoutThisMonthInr: number;
    approvalToRejectionRatio: number | null;
    quoteConversionRate: number;
  };
  reviewRequiredRenewalCount: number;
  reviewRequiredRenewals: PolicyListItem[];
}
