import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

// Company workspace landing — slice B replaces this welcome panel with the
// real dashboard (quotes, policies, claims stats).
@Component({
  selector: 'app-company-dashboard',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './company-dashboard.html',
  styleUrl: './company-dashboard.css',
  })
export class CompanyDashboard {
  readonly auth = inject(AuthService);
}
