import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

// Admin workspace landing — slice D replaces this with approvals,
// claim review/decision and the metrics dashboard.
@Component({
  selector: 'app-admin-dashboard',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './admin-dashboard.html',
  styleUrl: './admin-dashboard.css',
  })
export class AdminDashboard {
  readonly auth = inject(AuthService);
}
