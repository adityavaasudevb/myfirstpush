import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';

// P0 — Landing: what the team's home page links into.
// Content = design doc §3 pricing, in plain insurance language.
@Component({
  selector: 'app-landing',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './landing.html',
  styleUrl: './landing.css',
  })
export class Landing {
  // twelve dots on a circle (r=84, centre 100,100) — The Hartford heritage mark homage
  readonly dots = Array.from({ length: 12 }, (_, i) => {
    const angle = (i * 30 * Math.PI) / 180 - Math.PI / 2;
    return [100 + 84 * Math.cos(angle), 100 + 84 * Math.sin(angle)];
  });

  readonly addons = [
    { name: 'Physical Damage', pct: '+12%', blurb: 'Own-vehicle repair costs across covered periods.' },
    { name: 'Uninsured Motorist', pct: '+5%', blurb: 'Protects against third parties without cover.' },
    { name: 'Rental Car', pct: '+3%', blurb: 'Replacement mobility while a vehicle is down.' },
    { name: 'Medical Payments', pct: '+2%', blurb: 'Rider and driver medical expense cover.' },
  ];

  readonly steps = [
    { n: 1, title: 'Quote', blurb: 'Enter fleet size, tier & add-ons — instant premium in INR, USD & EUR.' },
    { n: 2, title: 'Apply', blurb: 'One clean application from any active quote, 7-day validity respected.' },
    { n: 3, title: 'Pay', blurb: 'Simulated payment activates the policy for a full year.' },
    { n: 4, title: 'Claim', blurb: 'Trip-event evidence drives an instant preliminary decision, then expert review.' },
  ];
}
