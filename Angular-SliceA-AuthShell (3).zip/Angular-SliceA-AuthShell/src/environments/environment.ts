// Production environment — the gateway is reached through whatever
// reverse proxy hosts the deployed frontend, so a relative base is correct.
export const environment = {
  production: true,
  apiBaseUrl: '/api',
};
