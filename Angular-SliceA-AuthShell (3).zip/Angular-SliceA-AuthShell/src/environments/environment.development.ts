// Development environment — /api is proxied to http://localhost:5000
// by proxy.conf.json (ng serve --proxy-config proxy.conf.json).
export const environment = {
  production: false,
  apiBaseUrl: '/api',
};
