# Slice D — Admin workspace (dashboard FR7.1/FR7.2 · policies FR9.1 · claims explorer FR9.2 · review & decision FR5.14–5.15/FR6.1 · surveyor approvals)

The final UI slice. All contracts below were read from the backend files
themselves (`DashboardDto.cs`, `ClaimDtos.cs`, `PolicyDtos.cs`,
`ClaimsController.cs`, `PoliciesController.cs`, `SurveyorController.cs`).

## Endpoints wired

| Endpoint | FR | Used by |
|---|---|---|
| `GET /api/dashboard` | 7.1 | Overview: 5 metric tiles + Review-Required renewal list |
| `GET /api/claims?isFlagged=true` | 7.2 | Overview: flagged-claims attention strip (top 5 + total) |
| `GET /api/policies` (status/tier/sortOrder/paging) | 9.1 | All-policies page |
| `GET /api/claims` (search/status/claimType/isFlagged/sortOrder/paging) | 9.2 | Claims explorer |
| `GET /api/claims/{id}` + `GET /api/claims/{id}/review` | 5.14 | Review screen (two fetches, side by side) |
| `POST /api/claims/{id}/decision` | 5.15/6.1 | Decision form (`{decision, finalAmountInr, overrideNote}` → 200 with the decided claim) |
| `GET /api/surveyors/pending` | — | Approvals page |
| `POST /api/surveyors/{id}/approve` / `…/reject {reason}` | — | Approvals page (toast from `MessageResponse.message`) |

**Deliberately NOT built (doc Appendix D):** the sixth dashboard metric
(pending surveyor registrations → item D2), any admin *action* on
Review-Required renewals (informational flag → item D10). The approvals
page already covers pending surveyors, so nothing is lost at demo time.

## Files & paste order

New components — scaffold first (creates `.css`/spec shells; the pack ships
two richer specs you keep, the CLI's default ones you can delete):

```bash
ng g c features/policies/admin-policies
ng g c features/claims/admin-claims
ng g c features/claims/claim-review
ng g c features/admin/surveyor-approvals
```

| File | Action |
|---|---|
| `src/app/core/models/claim.model.ts` | **Replace** — superset (company C-B + surveyor C + admin types) |
| `src/app/core/services/claims-api.service.ts` | **Replace** — superset (+ `adminList/review/decide`) |
| `src/app/core/services/policy.service.ts` | **Replace** — superset (+ `adminList`) |
| `src/app/features/dashboard/models/dashboard.model.ts` | New |
| `src/app/features/dashboard/services/dashboard.service.ts` | New |
| `src/app/features/dashboard/admin-dashboard/admin-dashboard.ts` | **Replace the Slice A stub** (same path, same class name) |
| `src/app/features/dashboard/admin-dashboard/admin-dashboard.html` | Replace stub template |
| `src/app/features/policies/admin-policies/*` | New (2 files) |
| `src/app/features/claims/admin-claims/*` | New (2 files) |
| `src/app/features/claims/claim-review/*` | New (3 files incl. spec) |
| `src/app/features/admin/models/pending-surveyor.model.ts` | New |
| `src/app/features/admin/services/admin-surveyor.service.ts` | New |
| `src/app/features/admin/surveyor-approvals/*` | New (3 files incl. spec) |
| `src/app/shared/layouts/app-layout/app-layout.ts` | **Replace** — cumulative nav (also adds Company → Profile) |

## Routes

In `app.routes.ts` replace the flat admin line

```ts
{ path: 'admin', component: AdminDashboard, canActivate: [roleGuard(['Admin'])] },
```

with a children block:

```ts
{
  path: 'admin',
  canActivate: [roleGuard(['Admin'])],
  children: [
    { path: '', component: AdminDashboard },
    { path: 'policies', component: AdminPolicies },
    { path: 'claims', component: AdminClaims },
    { path: 'claims/:id', component: ClaimReview },
    { path: 'surveyors', component: SurveyorApprovals },
  ],
},
```

```ts
import { AdminDashboard } from './features/dashboard/admin-dashboard/admin-dashboard'; // already imported by Slice A
import { AdminPolicies } from './features/policies/admin-policies/admin-policies';
import { AdminClaims } from './features/claims/admin-claims/admin-claims';
import { ClaimReview } from './features/claims/claim-review/claim-review';
import { SurveyorApprovals } from './features/admin/surveyor-approvals/surveyor-approvals';
```

(The company `profile` route came with Slice A2’s README — the layout nav for
it is already in this pack’s cumulative `app-layout.ts`.)

## Behaviour notes

- **Counts everywhere (standing rule):** status chips on both explorer lists
  fire one `pageSize=1` read per chip (respecting the other active filters),
  explorer also shows the flagged total; dashboards read server aggregates.
- **Claims explorer** deep-links: `?flagged=true` (from the overview strip),
  `?status=Paid` (from the payouts tile). Search applies on Enter/button;
  clearing the box resets.
- **Review/decision gating is data-driven:** rows only link to the review
  screen once a report exists (`SurveyorReportSubmitted`, `Paid`, `Rejected`);
  the decision form appears solely at `SurveyorReportSubmitted`. Approve
  pre-fills the surveyor's recommended amount (server data, editable — the
  client never computes payouts). Override note is enforced client-side when
  you differ from the recommendation; the backend re-checks (400).
- **SurveyorDto normalizer (the one honest unknown):** AuthService's
  `SurveyorDto` file was never pasted, so `normalizePendingSurveyor` tolerates
  alias keys (`fullName|name`, `irdaiLicenseNumber|licenseNumber`, …). If any
  card field renders as `—`, paste me `AuthService.Application/DTOs` and I'll
  align the mapper in one edit. Approve/reject bodies are already exact.
- **sortOrder values sent:** `'asc' | 'desc'` (matches both controllers’
  "sortOrder" string; ascending/descending per FR9.1/FR9.2).

## Quick test plan

1. Login as admin → Overview shows 5 tiles; approve∶reject shows `—` until the
   first rejection this month.
2. Explorer: search a seeded claim number; flip chips and watch counts add up;
   open a `Report submitted` claim → Decide.
3. Approve with a changed amount and no note while differing from the
   recommendation → inline error; add a note → success toast, back in explorer
   the row is **Paid** with the final amount.
4. Approvals: register a fresh surveyor in another browser/incognito → the row
   appears; reject with reason → that account's login shows the reason; approve
   the rest → "All caught up".
5. `ng test` → report.
