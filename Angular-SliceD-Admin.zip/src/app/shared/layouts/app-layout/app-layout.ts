import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { Role } from '../../../core/constants/roles';

interface NavLink {
  label: string;
  route: string;
  exact?: boolean;
}

// Cumulative role-based navbar (slices A–D): company workspace incl. profile,
// surveyor workspace, full admin workspace.
const ROLE_NAV: Record<Role, NavLink[]> = {
  Company: [
    { label: 'Dashboard', route: '/company', exact: true },
    { label: 'Get a quote', route: '/company/quotes/new' },
    { label: 'My quotes', route: '/company/quotes' },
    { label: 'My policies', route: '/company/policies' },
    { label: 'My claims', route: '/company/claims' },
    { label: 'Profile', route: '/company/profile' },
  ],
  Surveyor: [
    { label: 'Open queue', route: '/surveyor', exact: true },
    { label: 'My investigations', route: '/surveyor/assigned' },
  ],
  Admin: [
    { label: 'Overview', route: '/admin', exact: true },
    { label: 'Policies', route: '/admin/policies' },
    { label: 'Claims', route: '/admin/claims' },
    { label: 'Surveyor approvals', route: '/admin/surveyors' },
  ],
};

@Component({
  selector: 'app-app-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app-layout.html',
  styleUrl: './app-layout.css',
})
export class AppLayout {
  readonly auth = inject(AuthService);

  links(): NavLink[] {
    const r = this.auth.role();
    return r ? ROLE_NAV[r] : [];
  }
}
