// AuthService surveyor-approval contracts (SurveyorController.cs).
// Approve/reject return MessageResponse ({ message }). The pending list
// returns SurveyorDto[] — AuthService's DTO file was never pasted, so the
// normalizer below tolerates the plausible property aliases (all JSON keys
// arrive camelCase). If the cards render "—" fields, align this mapper with
// the real DTO.

export interface MessageResponse {
  message: string;
}

export interface PendingSurveyor {
  id: string;
  fullName: string;
  email: string;
  contactInfo: string | null;
  irdaiLicenseNumber: string | null;
  licenseValidUntil: string | null;
  requestedAtUtc: string | null;
}

type Raw = Record<string, any>;

const pick = (r: Raw, ...keys: string[]): any => {
  for (const k of keys) {
    if (r[k] != null && r[k] !== '') return r[k];
  }
  return null;
};

export function normalizePendingSurveyor(r: Raw): PendingSurveyor {
  return {
    id: pick(r, 'id', 'userId', 'surveyorId') ?? '',
    fullName: pick(r, 'fullName', 'name', 'displayName') ?? '—',
    email: pick(r, 'email', 'userName') ?? '—',
    contactInfo: pick(r, 'contactInfo', 'phone', 'contact'),
    irdaiLicenseNumber: pick(r, 'irdaiLicenseNumber', 'licenseNumber', 'licenceNumber'),
    licenseValidUntil: pick(r, 'licenseValidUntil', 'licenceValidUntil', 'licenseValidTill'),
    requestedAtUtc: pick(r, 'requestedAtUtc', 'createdAtUtc', 'registeredAtUtc', 'createdAt'),
  };
}
