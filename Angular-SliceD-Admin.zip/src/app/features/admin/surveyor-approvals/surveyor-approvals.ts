import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AdminSurveyorService } from '../services/admin-surveyor.service';
import { PendingSurveyor } from '../models/pending-surveyor.model';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';

// Admin surveyor-approval gate — pending registrations can be approved
// (account activates) or rejected with a reason (shown to the surveyor at
// their next login attempt).
@Component({
  selector: 'app-surveyor-approvals',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './surveyor-approvals.html',
  styleUrl: './surveyor-approvals.css',
})
export class SurveyorApprovals {
  private readonly fb = inject(FormBuilder);
  private readonly api = inject(AdminSurveyorService);
  private readonly alerts = inject(AlertService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly pending = signal<PendingSurveyor[] | null>(null);

  /** Id of the row a mutation is in flight for (disables its buttons). */
  readonly acting = signal<string | null>(null);
  /** Id of the row whose reject form is open. */
  readonly rejectingFor = signal<string | null>(null);

  readonly reason = this.fb.nonNullable.control('', [Validators.required, Validators.minLength(5)]);

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api.pending().subscribe({
      next: (list) => {
        this.pending.set(list);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  approve(s: PendingSurveyor): void {
    if (this.acting()) return;
    this.acting.set(s.id);
    this.api.approve(s.id).subscribe({
      next: (res) => {
        this.alerts.success(res.message || `${s.fullName} approved.`);
        this.removeFromList(s.id);
        this.acting.set(null);
      },
      error: (err) => {
        this.alerts.error(responseErrorText(err));
        this.acting.set(null);
      },
    });
  }

  beginReject(s: PendingSurveyor): void {
    this.rejectingFor.set(s.id);
    this.reason.reset('');
  }

  cancelReject(): void {
    this.rejectingFor.set(null);
  }

  confirmReject(s: PendingSurveyor): void {
    if (this.reason.invalid || this.acting()) return;
    this.acting.set(s.id);
    this.api.reject(s.id, this.reason.value.trim()).subscribe({
      next: (res) => {
        this.alerts.success(res.message || `${s.fullName} rejected.`);
        this.removeFromList(s.id);
        this.rejectingFor.set(null);
        this.acting.set(null);
      },
      error: (err) => {
        this.alerts.error(responseErrorText(err));
        this.acting.set(null);
      },
    });
  }

  private removeFromList(id: string): void {
    this.pending.update((list) => (list ?? []).filter((s) => s.id !== id));
  }

  fmt(iso: string | null): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
