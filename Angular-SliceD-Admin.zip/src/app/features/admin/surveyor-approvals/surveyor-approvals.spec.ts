import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { SurveyorApprovals } from './surveyor-approvals';

describe('SurveyorApprovals', () => {
  let component: SurveyorApprovals;
  let fixture: ComponentFixture<SurveyorApprovals>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SurveyorApprovals],
      providers: [provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(SurveyorApprovals);
    component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });
});
