import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { MessageResponse, PendingSurveyor, normalizePendingSurveyor } from '../models/pending-surveyor.model';

const API = environment.apiBaseUrl;

// Surveyor approval gate — AuthService /api/surveyors (Admin-only).
@Injectable({ providedIn: 'root' })
export class AdminSurveyorService {
  private readonly http = inject(HttpClient);

  /** Pending registrations awaiting an admin decision (plain array, not paged). */
  pending(): Observable<PendingSurveyor[]> {
    return this.http
      .get<unknown>(`${API}/surveyors/pending`)
      .pipe(map((res) => (Array.isArray(res) ? res : []).map(normalizePendingSurveyor)));
  }

  approve(id: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${API}/surveyors/${id}/approve`, {});
  }

  /** Reason travels in the body (RejectSurveyorRequest.reason). */
  reject(id: string, reason: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${API}/surveyors/${id}/reject`, { reason });
  }
}
