// FR7.1 — GET /api/dashboard, verbatim from DashboardDto.cs.
import { PolicyListItem } from '../../../core/models/policy.model';

export interface DashboardMetrics {
  activePolicies: number;               // EffectiveStatus == Active right now
  claimsThisMonth: number;              // created in the current calendar month
  totalPayoutThisMonthInr: number;      // final amounts of claims Paid this month
  approvalToRejectionRatio: number | null; // approvals ÷ rejections this month; null when 0 rejections
  quoteConversionRate: number;          // 0..1, from GET /api/quotes/stats (Admin JWT forwarded)
}

export interface Dashboard {
  metrics: DashboardMetrics;
  reviewRequiredRenewalCount: number;
  reviewRequiredRenewals: PolicyListItem[]; // informational attention list (D10)
}
