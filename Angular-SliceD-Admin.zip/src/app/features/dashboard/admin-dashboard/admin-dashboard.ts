import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DashboardService } from '../services/dashboard.service';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { Dashboard } from '../models/dashboard.model';
import { ClaimListItem, REPORTED_STATUSES } from '../../../core/models/claim.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

// FR7.1 — admin overview: the five aggregated metrics + the Review-Required
// renewal attention list. FR7.2 — flagged claims are surfaced as a second
// attention strip, read from the claims list endpoint with isFlagged=true.
// (Replaces the Slice A placeholder at the same path.)
@Component({
  selector: 'app-admin-dashboard',
  imports: [CommonModule, RouterLink, MoneyPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './admin-dashboard.html',
  styleUrl: './admin-dashboard.css',
})
export class AdminDashboard {
  private readonly dashboardApi = inject(DashboardService);
  private readonly claimsApi = inject(ClaimsApiService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly dash = signal<Dashboard | null>(null);

  /** FR7.2 — flagged claims attention strip (all statuses, newest page). */
  readonly flagged = signal<Paged<ClaimListItem> | null>(null);

  constructor() {
    this.dashboardApi.get().subscribe({
      next: (d) => {
        this.dash.set(d);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });

    this.claimsApi.adminList({ isFlagged: true, page: 1, pageSize: 5 }).subscribe({
      next: (pg) => this.flagged.set(pg),
      error: () => undefined, // attention strip is best-effort; metrics matter
    });
  }

  /** Ratio is null when there were zero rejections this month. */
  ratioText(d: Dashboard): string {
    const r = d.metrics.approvalToRejectionRatio;
    return r == null ? '—' : `${this.trim(r)} : 1`;
  }

  conversionText(d: Dashboard): string {
    return `${this.trim(d.metrics.quoteConversionRate * 100)}%`;
  }

  private trim(n: number): string {
    return n.toLocaleString('en-IN', { maximumFractionDigits: 1 });
  }

  reviewable(status: string): boolean {
    return (REPORTED_STATUSES as readonly string[]).includes(status);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      case 'UnderInvestigation':
      case 'SurveyorReportSubmitted':
        return 'bg-blue-100 text-blue-800';
      case 'AwaitingSurveyorPickup':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  pretty(status: string): string {
    return status.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  fmt(iso: string | null): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
