import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Dashboard } from '../models/dashboard.model';

const API = environment.apiBaseUrl;

// FR7.1 — the single dashboard endpoint (Admin-only): five metrics +
// Review-Required renewal attention list. The sixth metric (pending surveyor
// registrations) is deliberately NOT shown — deferred to item D2.
@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly http = inject(HttpClient);

  get(): Observable<Dashboard> {
    return this.http.get<Dashboard>(`${API}/dashboard`);
  }
}
