import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { AdminClaimFilter, ClaimListItem, CLAIM_TYPES, REPORTED_STATUSES } from '../../../core/models/claim.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

const STATUS_FILTERS = [
  { key: 'All', label: 'All' },
  { key: 'AwaitingSurveyorPickup', label: 'Awaiting pickup' },
  { key: 'UnderInvestigation', label: 'Under investigation' },
  { key: 'SurveyorReportSubmitted', label: 'Report submitted' },
  { key: 'Paid', label: 'Paid' },
  { key: 'Rejected', label: 'Rejected' },
];

// FR9.2 — admin claims explorer: search by claim number / vehicle, filter by
// status / claim type / flagged, sort by incident date. Rows with a surveyor
// report open the review & decision screen.
@Component({
  selector: 'app-admin-claims',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './admin-claims.html',
  styleUrl: './admin-claims.css',
})
export class AdminClaims {
  private readonly claimsApi = inject(ClaimsApiService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<ClaimListItem> | null>(null);
  readonly statusFilter = signal('All');
  readonly claimType = signal('');
  readonly flaggedOnly = signal(false);
  readonly sortOrder = signal<'asc' | 'desc'>('desc');
  readonly page = signal(1);

  /** Two-stage search: the box edits `searchInput`; `appliedSearch` is what
   *  the server sees (Apply / Enter / Clear). */
  readonly searchInput = signal('');
  readonly appliedSearch = signal('');

  /** Server-side counts per status chip + the flagged chip (pageSize=1 reads). */
  readonly counts = signal<Record<string, number | null>>({});
  readonly flaggedTotal = signal<number | null>(null);

  readonly filters = STATUS_FILTERS;
  readonly claimTypes = CLAIM_TYPES;

  constructor() {
    const route = inject(ActivatedRoute);
    const q = route.snapshot.queryParamMap;
    if (q.get('flagged') === 'true') this.flaggedOnly.set(true);
    const st = q.get('status');
    if (st && STATUS_FILTERS.some((f) => f.key === st)) this.statusFilter.set(st);
    this.reload();
    this.refreshCounts();
  }

  /** Counts respect the current search / type / flagged filters. */
  private refreshCounts(): void {
    const base = this.baseFilter();
    for (const f of this.filters) {
      this.claimsApi
        .adminList({ ...base, page: 1, pageSize: 1, status: f.key === 'All' ? undefined : f.key })
        .subscribe({
          next: (pg) => this.counts.update((c) => ({ ...c, [f.key]: pg.total })),
          error: () => undefined,
        });
    }
    this.claimsApi.adminList({ ...base, page: 1, pageSize: 1, isFlagged: true }).subscribe({
      next: (pg) => this.flaggedTotal.set(pg.total),
      error: () => undefined,
    });
  }

  private baseFilter(): AdminClaimFilter {
    return {
      search: this.appliedSearch() || undefined,
      claimType: this.claimType() || undefined,
      isFlagged: this.flaggedOnly() ? true : undefined,
    };
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.claimsApi
      .adminList({
        ...this.baseFilter(),
        status: this.statusFilter() === 'All' ? undefined : this.statusFilter(),
        sortOrder: this.sortOrder(),
        page: this.page(),
      })
      .subscribe({
        next: (pg) => {
          this.paged.set(pg);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }

  onSearchInput(value: string): void {
    this.searchInput.set(value);
    if (!value.trim() && this.appliedSearch()) this.clearSearch();
  }

  applySearch(): void {
    this.appliedSearch.set(this.searchInput().trim());
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  clearSearch(): void {
    this.searchInput.set('');
    this.appliedSearch.set('');
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  setStatus(f: string): void {
    if (this.statusFilter() === f) return;
    this.statusFilter.set(f);
    this.page.set(1);
    this.reload();
  }

  setType(t: string): void {
    this.claimType.set(t);
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  toggleFlagged(): void {
    this.flaggedOnly.set(!this.flaggedOnly());
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  setSort(s: 'asc' | 'desc'): void {
    this.sortOrder.set(s);
    this.page.set(1);
    this.reload();
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  /** Only claims with a surveyor report can open the review screen. */
  reviewable(status: string): boolean {
    return (REPORTED_STATUSES as readonly string[]).includes(status);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      case 'UnderInvestigation':
      case 'SurveyorReportSubmitted':
        return 'bg-blue-100 text-blue-800';
      case 'AwaitingSurveyorPickup':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  pretty(status: string): string {
    return status.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  fmt(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
