import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimDetails, ClaimReview as ClaimReviewModel, FieldVerification } from '../../../core/models/claim.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';

const FIELD_LABELS: Record<string, string> = {
  DriverInfo: 'Driver info',
  PassengerInfo: 'Passenger info',
  TripEventLog: 'Trip event log',
  Documents: 'Documents',
};

// FR5.14 — side-by-side review: the rules engine's preliminary determination
// next to the surveyor's full report. FR5.15 — the final decision lives here;
// an override note is mandatory when it differs from the recommendation.
// FR6.1 — Approve records the simulated payout in the same request.
@Component({
  selector: 'app-claim-review',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, MoneyPipe],
  templateUrl: './claim-review.html',
  styleUrl: './claim-review.css',
})
export class ClaimReview {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly claimsApi = inject(ClaimsApiService);
  private readonly alerts = inject(AlertService);
  private readonly fb = inject(FormBuilder);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly details = signal<ClaimDetails | null>(null);
  readonly review = signal<ClaimReviewModel | null>(null);
  /** /review errors before a report exists — shown as a friendly state. */
  readonly reviewUnavailable = signal<string | null>(null);

  readonly deciding = signal(false);
  readonly decisionError = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    decision: ['' as '' | 'Approve' | 'Reject', Validators.required],
    finalAmountInr: [null as number | null],
    overrideNote: [''],
  });

  constructor() {
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) {
      this.error.set('Missing claim id.');
      this.loading.set(false);
      return;
    }

    // Two independent fetches: the review endpoint only works once a report
    // exists, while the detail works for every claim the Admin can see.
    this.claimsApi.get(id).subscribe({
      next: (d) => {
        this.details.set(d);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });

    this.claimsApi.review(id).subscribe({
      next: (r) => {
        this.review.set(r);
        // Pre-fill the payout input with the surveyor's recommended amount —
        // server-provided data, still fully editable; never computed here.
        if (r.report.recommendedAmountInr != null) {
          this.form.controls.finalAmountInr.setValue(r.report.recommendedAmountInr);
        }
      },
      error: (err) => this.reviewUnavailable.set(responseErrorText(err)),
    });
  }

  get decisionValue(): '' | 'Approve' | 'Reject' {
    return this.form.controls.decision.value;
  }

  recommendation(): string | null {
    return this.review()?.report.recommendation ?? null;
  }

  needsAmount(): boolean {
    return this.decisionValue === 'Approve';
  }

  /** FR5.15 — note mandatory when the decision differs from the recommendation. */
  needsOverride(): boolean {
    const d = this.decisionValue;
    const r = this.recommendation();
    return !!d && !!r && d !== r;
  }

  decided(): boolean {
    const s = this.details()?.status;
    return s === 'Paid' || s === 'Rejected';
  }

  canDecide(): boolean {
    return this.details()?.status === 'SurveyorReportSubmitted' && !!this.review();
  }

  submit(): void {
    if (this.form.invalid || this.deciding()) return;
    const note = this.form.controls.overrideNote.value.trim();
    const amount = this.form.controls.finalAmountInr.value;

    if (this.needsAmount() && (amount == null || amount < 0)) {
      this.decisionError.set('Enter the final payout amount in ₹.');
      return;
    }
    if (this.needsOverride() && !note) {
      this.decisionError.set(
        'An override note is required — your decision differs from the surveyor\u2019s recommendation.',
      );
      return;
    }

    const d = this.details();
    if (!d) return;
    this.deciding.set(true);
    this.decisionError.set(null);

    const decision = this.decisionValue as 'Approve' | 'Reject';
    this.claimsApi
      .decide(d.id, {
        decision,
        finalAmountInr: decision === 'Approve' ? amount : null,
        overrideNote: note || null,
      })
      .subscribe({
        next: (res) => {
          this.alerts.success(`Decision recorded — ${res.claimNumber} is now ${res.status}.`);
          this.router.navigateByUrl('/admin/claims');
        },
        error: (err) => {
          this.deciding.set(false);
          this.decisionError.set(responseErrorText(err));
        },
      });
  }

  fieldLabel(name: string): string {
    return FIELD_LABELS[name] ?? name;
  }

  fieldChip(status: string): string {
    switch (status) {
      case 'Verified':
        return 'bg-green-100 text-green-800';
      case 'Suspicious':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  fields(): FieldVerification[] {
    return this.review()?.fieldVerifications ?? this.details()?.fieldVerifications ?? [];
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      case 'UnderInvestigation':
      case 'SurveyorReportSubmitted':
        return 'bg-blue-100 text-blue-800';
      case 'AwaitingSurveyorPickup':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  pretty(status: string): string {
    return status.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  fmt(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }

  fmtTime(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime())
      ? '—'
      : d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  }
}
