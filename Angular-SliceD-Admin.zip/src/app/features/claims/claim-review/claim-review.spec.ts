import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { ClaimReview } from './claim-review';

describe('ClaimReview', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClaimReview],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    const fixture: ComponentFixture<ClaimReview> = TestBed.createComponent(ClaimReview);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('requires an override note when the decision differs from the recommendation', () => {
    const fixture = TestBed.createComponent(ClaimReview);
    const c = fixture.componentInstance;
    (c as any).review.set({
      claimId: 'x',
      claimNumber: 'CLM-1',
      vehicleNumber: 'TS09AB1234',
      claimType: 'Own Vehicle Damage',
      claimedAmountInr: 1000,
      derivedPeriod: 'Period 2',
      preliminaryDecision: 'Covered',
      preliminaryAmountInr: 900,
      isFlagged: false,
      flagReason: null,
      fieldVerifications: [],
      report: { id: 'r', overallOutcome: 'Genuine', recommendation: 'Approve', recommendedAmountInr: 900, notes: 'ok', submittedAtUtc: new Date().toISOString() },
    });
    c.form.controls.decision.setValue('Reject');
    expect(c.needsOverride()).toBeTrue();
    c.form.controls.decision.setValue('Approve');
    expect(c.needsOverride()).toBeFalse();
  });
});
