import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PolicyService } from '../../../core/services/policy.service';
import { PolicyListItem } from '../../../core/models/policy.model';
import { Paged } from '../../../core/models/paged';
import { TIER_OPTIONS } from '../../../core/constants/pricing';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

const STATUS_FILTERS = [
  { key: 'All', label: 'All' },
  { key: 'Pending', label: 'Pending' },
  { key: 'Active', label: 'Active' },
  { key: 'Expired', label: 'Expired' },
  { key: 'Cancelled', label: 'Cancelled' },
];

// FR9.1 — admin policy list: filter by status and tier, sort by creation
// date. Read-only: admin actions on policies are out of scope (review-
// required renewals are an informational flag, item D10).
@Component({
  selector: 'app-admin-policies',
  imports: [CommonModule, MoneyPipe],
  templateUrl: './admin-policies.html',
  styleUrl: './admin-policies.css',
})
export class AdminPolicies {
  private readonly policyApi = inject(PolicyService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<PolicyListItem> | null>(null);
  readonly statusFilter = signal('All');
  readonly tier = signal('');
  readonly sortOrder = signal<'asc' | 'desc'>('desc');
  readonly page = signal(1);
  /** Server-side counts per status chip (one pageSize=1 read each). */
  readonly counts = signal<Record<string, number | null>>({});

  readonly filters = STATUS_FILTERS;
  readonly tiers = TIER_OPTIONS.map((t) => t.key);

  constructor() {
    this.reload();
    this.refreshCounts();
  }

  private refreshCounts(): void {
    for (const f of this.filters) {
      this.policyApi
        .adminList({ page: 1, pageSize: 1, status: f.key === 'All' ? undefined : f.key, tier: this.tier() || undefined })
        .subscribe({
          next: (pg) => this.counts.update((c) => ({ ...c, [f.key]: pg.total })),
          error: () => undefined,
        });
    }
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.policyApi
      .adminList({
        page: this.page(),
        status: this.statusFilter() === 'All' ? undefined : this.statusFilter(),
        tier: this.tier() || undefined,
        sortOrder: this.sortOrder(),
      })
      .subscribe({
        next: (pg) => {
          this.paged.set(pg);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }

  setStatus(f: string): void {
    if (this.statusFilter() === f) return;
    this.statusFilter.set(f);
    this.page.set(1);
    this.reload();
  }

  setTier(t: string): void {
    this.tier.set(t);
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  setSort(s: 'asc' | 'desc'): void {
    this.sortOrder.set(s);
    this.page.set(1);
    this.reload();
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Pending':
        return 'bg-amber-100 text-amber-800';
      case 'Cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  fmt(iso: string | null): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
