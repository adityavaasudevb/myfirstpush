// InsuranceService (claims) contract — verbatim shape from ClaimDtos.cs.
// JSON is camelCase; datetimes are ISO strings.
// Covers company (B), surveyor (C) and admin (D) flows.

// ---- catalog constants (claim types per Section 3 mapping; trip event
// types per FR5.2) ----
export const CLAIM_TYPES = [
  'Third-Party Liability',
  'Own Vehicle Damage',
  'Uninsured Motorist',
  'Medical Expense',
  'Rental Car',
] as const;

export const TRIP_EVENT_TYPES = [
  'AppOnline',
  'RideAccepted',
  'PassengerPickedUp',
  'RideCompleted',
  'AppOffline',
] as const;

// State machine (FR5): Submitted → AwaitingSurveyorPickup →
// UnderInvestigation → SurveyorReportSubmitted → Paid | Rejected
export const CLAIM_STATUSES = [
  'Submitted',
  'AwaitingSurveyorPickup',
  'UnderInvestigation',
  'SurveyorReportSubmitted',
  'Paid',
  'Rejected',
] as const;

/** Statuses that have a surveyor report — only these can open the admin
 *  review/decision screen. */
export const REPORTED_STATUSES = ['SurveyorReportSubmitted', 'Paid', 'Rejected'] as const;

// ---- intake ----

/** One trip-log event submitted with the claim (FR5.2). */
export interface TripEventInput {
  eventType: string;
  occurredAtUtc: string;
}

/** Body of POST /api/claims. When appNotInUseDeclared is true the event
 *  validation doesn't run (claim classifies App Off); supplied events are ignored. */
export interface CreateClaimRequest {
  policyId: string;
  driverName: string;
  driverLicenceNumber: string;
  vehicleNumber: string;
  passengerName: string;
  passengerContact: string;
  incidentAtUtc: string;
  incidentLocation: string;
  description: string;
  claimedAmountInr: number;
  claimType: string;
  documentLink: string;
  appNotInUseDeclared: boolean;
  tripEvents: TripEventInput[] | null;
}

/** Intake response — claim number + preliminary rules-engine outcome. */
export interface CreateClaimResponse {
  claimId: string;
  claimNumber: string;
  status: string; // AwaitingSurveyorPickup after rules processing
  derivedPeriod: string;
  preliminaryDecision: string;
  preliminaryAmountInr: number | null;
  isFlagged: boolean;
  flagReason: string | null;
}

// ---- lists ----

export interface ClaimListItem {
  id: string;
  claimNumber: string;
  vehicleNumber: string;
  claimType: string;
  incidentAtUtc: string;
  claimedAmountInr: number;
  status: string;
  isFlagged: boolean;
  finalPayoutAmountInr: number | null;
}

/** Surveyor queue / assigned row (FR9.3). */
export interface ClaimQueueItem {
  id: string;
  claimNumber: string;
  vehicleNumber: string;
  claimType: string;
  claimedAmountInr: number;
  incidentAtUtc: string;
  incidentLocation: string;
  derivedPeriod: string;
  preliminaryDecision: string;
  isFlagged: boolean;
  flagReason: string | null;
  status: string;
  createdAtUtc: string;
}

// ---- detail & children ----

export interface TripEvent {
  id: string;
  eventType: string;
  occurredAtUtc: string;
}

export interface FieldVerification {
  id: string;
  fieldName: string;
  status: string; // Pending | Verified | Suspicious
  note: string | null;
}

export interface SurveyorReport {
  id: string;
  overallOutcome: string;
  recommendation: string;
  recommendedAmountInr: number | null;
  notes: string;
  submittedAtUtc: string;
}

export interface ClaimStatusHistoryItem {
  fromStatus: string | null;
  toStatus: string;
  changedAtUtc: string;
  changedByUserId: string | null;
}

/** Full claim (FR5.17): intake, preliminary outcome, children, report, history. */
export interface ClaimDetails {
  id: string;
  claimNumber: string;
  policyId: string;
  policyNumber: string;
  driverName: string;
  driverLicenceNumber: string;
  vehicleNumber: string;
  passengerName: string;
  passengerContact: string;
  incidentAtUtc: string;
  incidentLocation: string;
  description: string;
  claimedAmountInr: number;
  claimType: string;
  documentLink: string;
  appNotInUseDeclared: boolean;
  derivedPeriod: string;
  preliminaryDecision: string;
  preliminaryAmountInr: number | null;
  isFlagged: boolean;
  flagReason: string | null;
  status: string;
  assignedSurveyorId: string | null;
  finalPayoutAmountInr: number | null;
  createdAtUtc: string;
  tripEvents: TripEvent[];
  fieldVerifications: FieldVerification[];
  report: SurveyorReport | null;
  statusHistory: ClaimStatusHistoryItem[];
}

// ---- surveyor actions ----

/** Body of POST verify-field. Status must be Verified or Suspicious. */
export interface VerifyFieldRequest {
  fieldName: string;
  status: 'Verified' | 'Suspicious';
  note: string | null;
}

/** Body of POST report — 409 while any field is Pending; one report per claim. */
export interface SubmitReportRequest {
  overallOutcome: string;
  recommendation: string;
  recommendedAmountInr: number | null;
  notes: string;
}

// ---- admin list / review / decision ----

/** FR9.2 — admin claims list query (GET /api/claims). */
export interface AdminClaimFilter {
  search?: string;      // claim number / vehicle number
  status?: string;
  claimType?: string;
  isFlagged?: boolean;
  sortOrder?: 'asc' | 'desc'; // by incident date
  page?: number;
  pageSize?: number;
}

/** FR5.14 — preliminary determination + the surveyor's full report, side by side. */
export interface ClaimReview {
  claimId: string;
  claimNumber: string;
  vehicleNumber: string;
  claimType: string;
  claimedAmountInr: number;
  derivedPeriod: string;
  preliminaryDecision: string;
  preliminaryAmountInr: number | null;
  isFlagged: boolean;
  flagReason: string | null;
  fieldVerifications: FieldVerification[];
  report: SurveyorReport;
}

/** FR5.15 — body of POST decision. overrideNote is mandatory whenever the
 *  decision differs from the surveyor's recommendation (400 otherwise). */
export interface ClaimDecisionRequest {
  decision: 'Approve' | 'Reject';
  finalAmountInr: number | null;
  overrideNote: string | null;
}

/** FR6.1 — Approve simulates the payout in the same request (→ Paid). */
export interface ClaimDecisionResponse {
  claimId: string;
  claimNumber: string;
  status: string; // Paid | Rejected
  finalPayoutAmountInr: number | null;
}
