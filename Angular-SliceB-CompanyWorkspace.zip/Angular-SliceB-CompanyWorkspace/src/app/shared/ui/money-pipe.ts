import { Pipe, PipeTransform } from '@angular/core';

// Formats INR in the en-IN grouping style: 114400 → ₹1,14,400.
const inr = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

@Pipe({ name: 'money' })
export class MoneyPipe implements PipeTransform {
  transform(value: number | null | undefined): string {
    return value == null ? '—' : inr.format(value);
  }
}
