import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { QuoteService } from '../services/quote.service';
import { Quote, TierName } from '../models/quote.model';
import { TIER_OPTIONS, TIER_BASE_PER_VEHICLE, ADD_ON_OPTIONS } from '../constants/pricing';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-new-quote',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe],
  templateUrl: './new-quote.html',
  styleUrl: './new-quote.css',
})
export class NewQuote {
  private readonly fb = inject(FormBuilder);
  private readonly quotes = inject(QuoteService);

  readonly tiers = TIER_OPTIONS;
  readonly addOns = ADD_ON_OPTIONS;

  readonly form = this.fb.nonNullable.group({
    fleetSize: [1, [Validators.required, Validators.min(1)]],
    tier: ['Comprehensive' as TierName, Validators.required],
  });

  private readonly selectedAddOns = signal<ReadonlySet<string>>(new Set(['EngineProtect']));
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly quote = signal<Quote | null>(null);

  hasAddOn(key: string): boolean {
    return this.selectedAddOns().has(key);
  }

  toggleAddOn(key: string): void {
    const next = new Set(this.selectedAddOns());
    next.has(key) ? next.delete(key) : next.add(key);
    this.selectedAddOns.set(next);
    this.quote.set(null); // a change invalidates the displayed estimate
  }

  tierRate(): number {
    return TIER_BASE_PER_VEHICLE[this.form.controls.tier.value as TierName];
  }

  tierRateFor(key: TierName): number {
    return TIER_BASE_PER_VEHICLE[key];
  }

  baseTotal(): number {
    return this.tierRate() * (this.form.controls.fleetSize.value || 0);
  }

  addOnsTotal(): number {
    const q = this.quote();
    return q ? Math.max(q.estimatedCost - this.baseTotal(), 0) : 0;
  }

  formatFx(value: number, ccy: 'USD' | 'EUR'): string {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: ccy, maximumFractionDigits: 0 }).format(value);
  }

  estimate(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    const v = this.form.getRawValue();
    this.quotes
      .create({ fleetSize: v.fleetSize, tier: v.tier as TierName, addOns: [...this.selectedAddOns()] })
      .subscribe({
        next: (q) => {
          this.quote.set(q);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }
}
