import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Quote, QuoteRequest } from '../models/quote.model';

const API = environment.apiBaseUrl;

// QuoteService client (doc §6.3). POST creates AND persists the quote;
// the estimate comes back on the returned row. Ownership comes from the token.
@Injectable({ providedIn: 'root' })
export class QuoteService {
  private readonly http = inject(HttpClient);

  create(body: QuoteRequest): Observable<Quote> {
    return this.http.post<Quote>(`${API}/quotes`, body).pipe(map(normalize));
  }

  /** FR3.4 — caller's quotes (newest first from the server). */
  mine(): Observable<Quote[]> {
    return this.http.get<Quote[]>(`${API}/quotes/company`).pipe(map((qs) => qs.map(normalize)));
  }

  get(id: string): Observable<Quote> {
    return this.http.get<Quote>(`${API}/quotes/${id}`).pipe(map(normalize));
  }
}

// Defensive: some rows may return addOns as a comma-separated string straight
// from Postgres; the UI always works with a real array.
function normalize(q: Quote): Quote {
  const a = q.addOns as unknown;
  return {
    ...q,
    addOns: Array.isArray(a)
      ? a
      : typeof a === 'string' && a.length
        ? a.split(',').map((s) => s.trim())
        : [],
  };
}
