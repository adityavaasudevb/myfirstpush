import { TierName } from '../models/quote.model';

// Display labels + server-published rates (FR3.2 / §9.2) — INR per vehicle.
export const TIER_OPTIONS: { key: TierName; blurb: string }[] = [
  { key: 'Basic', blurb: 'Essential cover for lean fleets.' },
  { key: 'Standard', blurb: 'Balanced protection for most commercial fleets.' },
  { key: 'Comprehensive', blurb: 'Widest inclusions for high-uptime fleets.' },
];

export const TIER_BASE_PER_VEHICLE: Record<TierName, number> = {
  Basic: 1200,
  Standard: 1600,
  Comprehensive: 2400,
};

export const ADD_ON_OPTIONS: { key: string; label: string; blurb: string }[] = [
  { key: 'ZeroDep', label: 'Zero depreciation', blurb: 'Full claim value — no depreciation deduction.' },
  { key: 'EngineProtect', label: 'Engine protect', blurb: 'Covers hydrostatic and oil-leak engine damage.' },
  { key: 'TyreProtect', label: 'Tyre protect', blurb: 'Tyre and tube replacement on road damage.' },
  { key: 'FastTrackClaims', label: 'FastTrack Claims', blurb: 'Priority lane for approved claims.' },
];
