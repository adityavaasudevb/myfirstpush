// QuoteService models — mirrors the POST /api/quotes contract (doc §6.3).
// The estimate (base + add-ons + conversion metadata) is computed server-side.

export type TierName = 'Basic' | 'Standard' | 'Comprehensive';
export type QuoteStatus = 'Active' | 'Expired' | 'Converted';

export interface QuoteRequest {
  fleetSize: number;
  tier: TierName;
  addOns: string[];
}

export interface ConversionMeta {
  asOf: string;   // when the FX rate snapshot was taken
  stale: boolean; // true when the snapshot is older than tolerated
}

export interface Quote {
  id: string;
  companyId: string;
  fleetSize: number;
  tier: string;
  addOns: string[]; // service normalizes this even if the DB stores a comma-string
  estimatedCost: number;
  currency: string; // 'INR'
  exchangeRate: number; // 1.0 for INR
  usdEstimate?: number | null; // present when conversion metadata is available
  eurEstimate?: number | null;
  conversionMeta?: ConversionMeta | null;
  status: QuoteStatus | string;
  validUntil: string;
  createdAt: string;
}
