# Slice B — Company Workspace: Step B1 (New Quote)

## 0 · Swagger checkpoint first (60 seconds)
Open `:5000/swagger` (or the Quote service's Swagger) → `POST /api/quotes`:
- Confirm the request body keys: `fleetSize` (number), `tier` (string), `addOns` (string[]).
- Confirm the response is the quote row itself (our models assume that shape).
If a key differs, it's a one-word change in `features/quotes/models/quote.model.ts`.

## 1 · Generate (CLI entry points)
```
ng g s features/quotes/services/quote
ng g c features/quotes/new-quote
ng g pipe shared/ui/money
```
Then paste the bodies from this zip (models, pricing constants, service, page, pipe).
The quote service spec the CLI generates needs the usual two providers in TestBed:
`provideHttpClient()` + `provideHttpClientTesting()`.

## 2 · Wire routes
In `app.routes.ts`, inside the `companyShell` children (after the `''` dashboard entry):
```
{ path: 'quotes/new', component: NewQuote },
```
and add `NewQuote` to the imports from `features/quotes/new-quote/new-quote`.

In `layouts/company-shell/company-dashboard/company-dashboard.html`, point the
**New quote** quick action at `"/company/quotes/new"` (it currently links to `/company`).

## 3 · Test
Login as `company@swiftfleet.in` → workspace → **New quote** → adjust fleet/tier/add-ons →
**Get estimate**. The card must show the backend's estimate (₹ + base/add-on split +
conversion chips or the INR-final fallback chip) and a valid-until date.
