#!/usr/bin/env python3
"""
Synthetic evidence documents for the TNC Insurance capstone demo.

10 documents = 2 per type (FIR, RepairEstimate, MedicalBill, TowingReceipt, RentalInvoice).
Each type has one CLEAN document (must produce zero findings) and one with PLANTED
DEFECTS (must produce the findings listed in README.md).

Everything here is fake and watermarked as such. Layouts follow the four templates the
user supplied: BNSS-173 FIR format, auto repair quote with Parts/Labour subtotals,
Indian hospital bill with Gross/Discount/Net columns and a detailed-breakup page,
US-style towing receipt.

Regenerate:  python3 generate_demo_documents.py
"""

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)
import os

OUT = os.path.dirname(os.path.abspath(__file__))

# Per-lane brand constants — a lane file overrides these before building.
WORKSHOP = "SRI BALAJI AUTO WORKS"
WORKSHOP_SUB = "Multi-brand body shop \u00b7 Plot 14, Gachibowli Main Road, Hyderabad - 500032"
HOSPITAL = "SRI SAI MULTISPECIALITY HOSPITAL"
HOSPITAL_SUB = "Plot 3, Sector 2, Hitec City, Hyderabad - 500081 \u00b7 Telangana \u00b7 GSTIN 36AABCS1429P1ZQ"
PHARMACY_NAME = "SRI VENKATESWARA PHARMACY"
RENTAL_NAME = "DRIVEEASY RENTALS"
RENTAL_SUB = "Kondapur, Hyderabad - 500084 \u00b7 GSTIN 36AAECD7788K1Z2"
WORKSHOP_GSTIN = "36ABCDE1234F1Z5"
REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
BLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
pdfmetrics.registerFont(TTFont("DV", REG))
pdfmetrics.registerFont(TTFont("DV-B", BLD))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV", boldItalic="DV-B")

INK = colors.HexColor("#1a1a1a")
MUTED = colors.HexColor("#5f6b7a")
RULE = colors.HexColor("#c9d1d9")
ACCENT = colors.HexColor("#0b3d63")
WASH = colors.HexColor("#f4f6f8")

S_ORG = ParagraphStyle("org", fontName="DV-B", fontSize=13, leading=15.5, textColor=ACCENT)
S_ORGSUB = ParagraphStyle("orgsub", fontName="DV", fontSize=7.8, leading=10, textColor=MUTED)
S_TITLE = ParagraphStyle("title", fontName="DV-B", fontSize=10.5, leading=13,
                         alignment=TA_CENTER, textColor=INK, spaceBefore=1, spaceAfter=1)
S_SEC = ParagraphStyle("sec", fontName="DV-B", fontSize=8.4, leading=11, textColor=ACCENT,
                       spaceBefore=6, spaceAfter=3)
S_BODY = ParagraphStyle("body", fontName="DV", fontSize=8.5, leading=12, textColor=INK)
S_SMALL = ParagraphStyle("small", fontName="DV", fontSize=7, leading=9.4, textColor=MUTED)
S_CELL = ParagraphStyle("cell", fontName="DV", fontSize=8.2, leading=10.6, textColor=INK)
S_CELLR = ParagraphStyle("cellr", fontName="DV", fontSize=8.2, leading=10.6, textColor=INK,
                         alignment=TA_RIGHT)
S_HDR = ParagraphStyle("hdr", fontName="DV-B", fontSize=8.2, leading=10.6, textColor=colors.white)
S_AMT = ParagraphStyle("amt", fontName="DV-B", fontSize=8.8, leading=11.5, alignment=TA_RIGHT)


def inr(v, dp=True):
    s = f"{v:.2f}" if dp else f"{int(round(v))}"
    whole, _, frac = s.partition(".")
    neg = whole.startswith("-")
    whole = whole.lstrip("-")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:]); head = head[:-2]
        if head: parts.insert(0, head)
        whole = ",".join(parts) + "," + tail
    return ("-" if neg else "") + "\u20b9" + whole + ("." + frac if frac else "")


def _chrome(canvas, doc):
    canvas.saveState()
    canvas.setFont("DV-B", 25)
    canvas.setFillColorRGB(0.905, 0.925, 0.94)
    canvas.translate(A4[0] / 2, A4[1] / 2)
    canvas.rotate(33)
    for y in (-130, 0, 130):
        canvas.drawCentredString(0, y, "SAMPLE  \u00b7  SYNTHETIC DEMO DOCUMENT")
    canvas.restoreState()
    canvas.saveState()
    canvas.setStrokeColor(RULE); canvas.setLineWidth(0.6)
    canvas.line(16 * mm, 10 * mm, A4[0] - 16 * mm, 10 * mm)
    canvas.setFont("DV", 6.5); canvas.setFillColor(MUTED)
    canvas.drawString(16 * mm, 7.0 * mm,
                      "SAMPLE \u2014 synthetic capstone demo document. Not a real record.")
    canvas.drawRightString(A4[0] - 16 * mm, 7.0 * mm, f"{doc.title}  \u00b7  {doc.page}")
    canvas.restoreState()


def header(org, sub, title, meta):
    story = [Paragraph(org, S_ORG), Paragraph(sub, S_ORGSUB), Spacer(1, 5)]
    r = Table([[""]], colWidths=[178 * mm], rowHeights=[2])
    r.setStyle(TableStyle([("LINEABOVE", (0, 0), (-1, -1), 1.3, ACCENT)]))
    story += [r, Spacer(1, 3), Paragraph(title, S_TITLE), Spacer(1, 3)]
    if meta:
        rows = [[Paragraph(f"<b>{k}</b>", S_CELL), Paragraph(str(v), S_CELL)] for k, v in meta]
        t = Table(rows, colWidths=[44 * mm, 134 * mm])
        t.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (0, -1), WASH),
            ("BOX", (0, 0), (-1, -1), 0.55, RULE),
            ("INNERGRID", (0, 0), (-1, -1), 0.35, RULE),
            ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 2.6), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
        ]))
        story += [t, Spacer(1, 3)]
    return story


def table(headers, rows, widths, align_right_from=2, zebra=True):
    data = [[Paragraph(h, S_HDR) for h in headers]]
    for r in rows:
        line = []
        for i, cell in enumerate(r):
            st = S_CELLR if i >= align_right_from else S_CELL
            line.append(Paragraph(str(cell), st))
        data.append(line)
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.55, RULE),
        ("INNERGRID", (0, 0), (-1, -1), 0.3, RULE),
        ("LEFTPADDING", (0, 0), (-1, -1), 3.5), ("RIGHTPADDING", (0, 0), (-1, -1), 3.5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.4), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.4),
    ]
    if zebra:
        style.append(("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, WASH]))
    t.setStyle(TableStyle(style))
    return t


def totals(rows, width_left=122 * mm, width_right=56 * mm):
    data = []
    for label, value, bold in rows:
        data.append([Paragraph(label, S_CELLR), Paragraph(value, S_AMT if bold else S_CELLR)])
    t = Table(data, colWidths=[width_left, width_right])
    t.setStyle(TableStyle([
        ("LINEABOVE", (0, -1), (-1, -1), 1.0, ACCENT),
        ("BACKGROUND", (0, -1), (-1, -1), WASH),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2.6), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.6),
    ]))
    return t


def signatures(pairs):
    cells = [Paragraph(f"<b>{a}</b><br/>{b}", S_BODY) for a, b in pairs]
    t = Table([cells], colWidths=[178 * mm / len(pairs)] * len(pairs))
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.5, RULE),
        ("INNERGRID", (0, 0), (-1, -1), 0.35, RULE),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def build(filename, story):
    path = os.path.join(OUT, filename)
    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=12 * mm, bottomMargin=11 * mm,
                            title=filename.replace(".pdf", ""),
                            author="Synthetic demo document", subject="Capstone artefact")
    doc.build(story, onFirstPage=_chrome, onLaterPages=_chrome)
    print("wrote", filename)


# =============================================================================
# FIR
# =============================================================================
def fir(filename, *, district, ps, year, fir_no, reg_date, occ_from, occ_to, place,
        complainant, father, age, occupation, address, accused, delay_reason,
        vehicle_self, vehicle_other, property_desc, property_value, narrative,
        action, officer, rank, gd_entry, received_time="11:05 hrs"):
    meta = [
        ("District", district),
        ("Police Station", ps),
        ("Year", year),
        ("F.I.R. No.", fir_no),
        ("Date of registration", reg_date),
        ("Acts &amp; Sections", "Bharatiya Nyaya Sanhita 2023 \u2014 Sec. 281 (rash driving), Sec. 125(a)"),
        ("General Diary entry", gd_entry),
    ]
    story = header(
        f"{ps} POLICE STATION", f"{district} \u00b7 Government of Telangana \u00b7 Police Department",
        "FIRST INFORMATION REPORT \u2014 (Under Section 173 BNSS)", meta)

    story += [Paragraph("OCCURRENCE", S_SEC)]
    occ = [
        [Paragraph("<b>Date &amp; time of occurrence</b>", S_CELL),
         Paragraph(f"From: {occ_from} &nbsp;&nbsp; To: {occ_to}", S_CELL)],
        [Paragraph("<b>Place of occurrence</b>", S_CELL), Paragraph(place, S_CELL)],
        [Paragraph("<b>Information received at P.S.</b>", S_CELL),
         Paragraph(f"{reg_date} at {received_time} \u00b7 GD entry {gd_entry}", S_CELL)],
        [Paragraph("<b>Reason for delay in reporting</b>", S_CELL), Paragraph(delay_reason, S_CELL)],
    ]
    t = Table(occ, colWidths=[52 * mm, 126 * mm])
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("BACKGROUND", (0, 0), (0, -1), WASH),
        ("BOX", (0, 0), (-1, -1), 0.55, RULE), ("INNERGRID", (0, 0), (-1, -1), 0.35, RULE),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 2.8), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.8),
    ]))
    story += [t]

    story += [Paragraph("COMPLAINANT / INFORMANT", S_SEC)]
    story += [table(["Field", "Particulars"],
                    [["Name", complainant], ["Father's name / age", f"{father} &middot; {age}"],
                     ["Occupation", occupation], ["Address", address], ["Nationality", "Indian"]],
                    [40 * mm, 138 * mm], align_right_from=99)]

    story += [Paragraph("ACCUSED / SUSPECT", S_SEC)]
    story += [table(["Field", "Particulars"],
                    [["Name", accused[0]], ["Father's name", accused[1]], ["Address", accused[2]]],
                    [40 * mm, 138 * mm], align_right_from=99)]

    story += [Paragraph("VEHICLES INVOLVED", S_SEC)]
    story += [table(["Registration", "Make / model", "Role"],
                    [[vehicle_self[0], vehicle_self[1], "Vehicle of the complainant"],
                     [vehicle_other[0], vehicle_other[1], "Vehicle that dashed from behind"]],
                    [38 * mm, 92 * mm, 48 * mm], align_right_from=99)]

    # property particulars folded into the narrative paragraph to keep the FIR on one page
    story += [Paragraph("FIRST INFORMATION CONTENTS (F.I.R. narrative)", S_SEC),
              Paragraph(narrative, S_BODY)]

    story += [Spacer(1, 6), Paragraph("ACTION TAKEN BY OFFICER IN CHARGE", S_SEC),
              Paragraph(action, S_BODY), Spacer(1, 6),
              KeepTogether([signatures([("Signed: informant", f"{complainant}"),
                          ("Signed: Officer In Charge",
                           f"{officer}<br/>{rank} &middot; {reg_date}")])])]
    build(filename, story)


# =============================================================================
# REPAIR ESTIMATE
# =============================================================================
def repair(filename, *, est_no, date, customer, vehicle, model, odometer, job_card,
           parts, labour, supplies, tax_rate_printed, tax_amount_printed,
           total_printed, remarks, footer_note="", discount_printed=0):
    parts_sub = round(sum(p[4] for p in parts), 2)
    labour_sub = round(sum(l[3] for l in labour), 2)
    meta = [("Estimate No.", est_no), ("Date", date), ("Customer", customer),
            ("Vehicle", f"{vehicle} \u2014 {model}"), ("Odometer", odometer),
            ("Job card", job_card), ("GSTIN", WORKSHOP_GSTIN)]
    story = header(WORKSHOP, WORKSHOP_SUB, "REPAIR ESTIMATE / QUOTATION", meta)

    story += [Paragraph("PARTS", S_SEC),
              table(["Part no.", "Description (OEM / aftermarket / used)", "Qty", "Unit price", "Amount"],
                    [[p[0], p[1], p[2], inr(p[3]), inr(p[4])] for p in parts],
                    [22 * mm, 86 * mm, 12 * mm, 28 * mm, 30 * mm]),
              Spacer(1, 2), totals([("Parts subtotal", inr(parts_sub), False)])]

    story += [Paragraph("LABOUR", S_SEC),
              table(["Job", "Hours", "Rate", "Amount"],
                    [[l[0], l[1], inr(l[2]), inr(l[3])] for l in labour],
                    [104 * mm, 16 * mm, 28 * mm, 30 * mm], align_right_from=1),
              Spacer(1, 2), totals([("Labour subtotal", inr(labour_sub), False)])]

    base = parts_sub + labour_sub + supplies
    rowset = [("Shop supplies and disposal", inr(supplies), False)]
    if discount_printed:
        rowset.append(("Less: goodwill discount", "\u2212" + inr(discount_printed)[1:], False))
    rowset += [(f"Tax at {tax_rate_printed:g}%", inr(tax_amount_printed), False),
               ("Estimated total", inr(total_printed), True)]
    story += [Spacer(1, 3), totals(rowset)]
    story += [Spacer(1, 2), Paragraph(footer_note, S_SMALL)]

    story += [Paragraph("WORKSHOP REMARKS", S_SEC), Paragraph(remarks, S_BODY), Spacer(1, 8),
              Paragraph("AUTHORIZATION", S_BODY),
              Paragraph("I authorize the repairs listed above for the estimated total shown. "
                        "No additional work will be carried out without the customer's approval.", S_SMALL),
              Spacer(1, 6),
              signatures([(f"For {WORKSHOP}", "S. Prasad<br/>Service Advisor"),
                          ("Customer acknowledgement", f"{customer}<br/>Date: {date}")])]
    build(filename, story)
    return base


# =============================================================================
# HOSPITAL BILL — layout follows the Vyapar "Hospital Bill Book" template:
# two sections (professional fees + billing heads), GST% per line, one discount,
# final amount, amount paid, balance. No gross/discount/net columns.
# =============================================================================
def hospital(filename, *, bill_no, bill_datetime, patient, address, ip_no, consultant,
             department, accommodation, room_no, diagnosis, admission, discharge,
             payment, prof_fees, billing_heads, subtotal_printed, discount_printed,
             final_printed, paid_printed, balance_printed, declaration):
    """prof_fees / billing_heads rows: (description, unit, qty, price, gst_pct, amount_printed)"""
    meta = [("Bill No.", bill_no), ("Bill date &amp; time", bill_datetime),
            ("Name of patient", patient), ("Address", address),
            ("Date / time of admission", admission), ("Date / time of discharge", discharge),
            ("Treating doctor", consultant), ("Department", department),
            ("Accommodation type", accommodation), ("Room no. / IP no.", room_no),
            ("Diagnosis", diagnosis), ("Payment mode", payment)]
    story = header(HOSPITAL, HOSPITAL_SUB, "HOSPITAL BILL", meta)

    cols = ["Sl", "Particulars", "Unit", "Qty", "Price / unit", "GST (%)", "Amount"]
    widths = [8 * mm, 74 * mm, 18 * mm, 12 * mm, 26 * mm, 16 * mm, 28 * mm]

    story += [Paragraph("TOTAL PROFESSIONAL FEES", S_SEC)]
    story += [table(cols, [[i + 1, r[0], r[1], r[2], inr(r[3]), f"{r[4]:g}%", inr(r[5])]
                           for i, r in enumerate(prof_fees)], widths, align_right_from=2)]
    pf_sum = sum(r[5] for r in prof_fees)
    story += [Spacer(1, 2), totals([("Professional fees subtotal", inr(pf_sum), False)])]

    story += [Paragraph("BILLING HEADS", S_SEC)]
    story += [table(cols, [[i + 1, r[0], r[1], r[2], inr(r[3]), f"{r[4]:g}%", inr(r[5])]
                           for i, r in enumerate(billing_heads)], widths, align_right_from=2)]
    bh_sum = sum(r[5] for r in billing_heads)
    story += [Spacer(1, 2), totals([("Billing heads subtotal", inr(bh_sum), False)])]

    story += [Spacer(1, 4),
              totals([("Sub total", inr(subtotal_printed), False),
                      ("Discount", inr(discount_printed), False),
                      ("Final amount", inr(final_printed), True),
                      ("Amount paid", inr(paid_printed), False),
                      ("Balance", inr(balance_printed), False)])]
    story += [Spacer(1, 3), Paragraph(declaration, S_SMALL), Spacer(1, 10),
              signatures([("Client's signature", patient),
                          ("Authorised signatory \u00b7 hospital seal", "For Sri Sai Multispeciality Hospital")])]
    build(filename, story)


# =============================================================================
# PHARMACY INVOICE — layout follows a retail pharmacy GST invoice:
# MRP, CGST%, SGST%, taxable, total per line; discount at the foot.
# Included to prove the same checks work on a third money layout.
# =============================================================================
def pharmacy(filename, *, invoice_no, date_time, customer, items, total_printed,
             discount_printed, net_printed):
    """items: (qty, name, hsn, batch, expiry, mrp, cgst, sgst, taxable, total)"""
    meta = [("Invoice No.", invoice_no), ("Date / time", date_time), ("Customer", customer),
            ("GSTIN", "36AAFCA5954P1ZX"), ("Branch", "Gachibowli, Hyderabad"),
            ("Licence", "TS/HYD/20B/4471")]
    story = header(PHARMACY_NAME,
                   "Door 3-14, Gachibowli Main Road, Hyderabad - 500032 \u00b7 Toll 1800 500 0101",
                   "TAX INVOICE", meta)
    story += [table(["Qty", "Item name", "HSN", "Batch", "Expiry", "MRP", "CGST", "SGST", "Taxable", "Total"],
                    [[i[0], i[1], i[2], i[3], i[4], inr(i[5], dp=False), f"{i[6]:g}%",
                      f"{i[7]:g}%", inr(i[8]), inr(i[9])] for i in items],
                    [10 * mm, 52 * mm, 16 * mm, 20 * mm, 16 * mm, 16 * mm, 12 * mm, 12 * mm, 18 * mm, 18 * mm],
                    align_right_from=5)]
    story += [Spacer(1, 3),
              totals([("Total", inr(total_printed), False),
                      ("Discount", inr(discount_printed), False),
                      ("Net total", inr(net_printed), True)])]
    story += [Spacer(1, 4),
              Paragraph("Medicines dispensed against a valid prescription. Not returnable after "
                        "dispatch. For Sri Venkateswara Pharmacy \u00b7 Pharmacist.", S_SMALL)]
    build(filename, story)


# =============================================================================
# TOWING RECEIPT
# =============================================================================
def towing(filename, *, receipt_no, date, time, company, address, phone, make, model, year,
           tag, vin, owner, from_loc, to_loc, reason, services, tax_rate, tax_amount,
           total_printed, paid, operator, truck, payment_method):
    meta = [("Date", date), ("Time", time), ("Receipt #", receipt_no),
            ("Company", company), ("Address", address), ("Phone", phone),
            ("Payment method", payment_method)]
    story = header(company, "Vehicle recovery and roadside assistance \u00b7 Hyderabad",
                   "TOWING RECEIPT", meta)

    story += [Paragraph("VEHICLE INFORMATION", S_SEC)]
    story += [table(["Field", "Value"],
                    [["Make / model / year", f"{make} {model} ({year})"],
                     ["Tag # (registration)", tag], ["VIN", vin], ["Registered owner", owner],
                     ["Vehicle location", from_loc], ["Vehicle towed to", to_loc],
                     ["Reason for towing", reason]],
                    [52 * mm, 126 * mm], align_right_from=99)]

    story += [Paragraph("DESCRIPTION OF SERVICES", S_SEC)]
    sub = sum(s[1] for s in services)
    story += [table(["Description of service", "Cost"],
                    [[s[0], inr(s[1])] for s in services],
                    [150 * mm, 28 * mm])]
    story += [Spacer(1, 2),
              totals([("Subtotal", inr(sub), False),
                      (f"Tax ({tax_rate:g}%)", inr(tax_amount), False),
                      ("Total", inr(total_printed), True),
                      ("Amount paid", inr(paid), False)])]
    story += [Spacer(1, 10),
              signatures([("Operator name / truck no.", f"{operator}<br/>Truck {truck}"),
                          ("Authorised signature", f"For {company}")])]
    build(filename, story)


# =============================================================================
# RENTAL INVOICE
# =============================================================================
def rental(filename, *, invoice_no, date, customer, vehicle, period, booking, items,
           tax_rate, tax_amount, total_printed, note):
    sub = sum(i[3] for i in items)
    meta = [("Invoice No.", invoice_no), ("Invoice date", date), ("Customer", customer),
            ("Rental vehicle", vehicle), ("Rental period", period),
            ("Booking reference", booking), ("GSTIN", "36AAECD7788K1Z2")]
    story = header(RENTAL_NAME, RENTAL_SUB,
                   "TAX INVOICE \u2014 VEHICLE RENTAL", meta)
    story += [Paragraph("PARTICULARS", S_SEC),
              table(["Description", "Qty", "Rate", "Amount"],
                    [[i[0], i[1], inr(i[2]), inr(i[3])] for i in items],
                    [104 * mm, 14 * mm, 26 * mm, 34 * mm], align_right_from=1)]
    story += [Spacer(1, 2),
              totals([("Subtotal", inr(sub), False), (f"GST @ {tax_rate:g}%", inr(tax_amount), False),
                      ("Invoice total", inr(total_printed), True)])]
    story += [Spacer(1, 3), Paragraph(note, S_SMALL), Spacer(1, 10),
              Paragraph("For DriveEasy Rentals \u00b7 Authorised signatory", S_BODY)]
    build(filename, story)


# =============================================================================
# THE TEN DOCUMENTS
# =============================================================================
if __name__ == "__main__":
    raise SystemExit("_base.py is a toolkit only — run lane_a_greenfield.py or lane_b_ui.py.")
