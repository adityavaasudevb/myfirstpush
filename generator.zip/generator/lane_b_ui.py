#!/usr/bin/env python3
"""
LANE B — "Coastal Spice Logistics" UI lane video documents.
Everything here is typed into the UI from lane-b-ui/README-B.md; the SQL is only used
to backdate the policy term after it is created in the UI.

CLEAN    Claim A  Own Vehicle Damage, Rs 58,650, incident 05 Nov 2026 10:22 IST
         FIR-01-clean / RepairEstimate-01-clean / TowingReceipt-01-clean

UNCLEAN  Claim B  Own Vehicle Damage, Rs 52,780, incident 05 Nov 2026 16:45 IST
         FIR-02-defects / RepairEstimate-02-defects / TowingReceipt-02-defects
         One story: a rear-end hit. The claim form is correct; the PAPERWORK is wrong.
           1  FIR names TG13MX4477, the claim form and the estimate say TG13MX4747
           2  FIR records the occurrence as 04 Nov 14:00-15:00 (a day early), and the FIR
              was registered on 09 Nov for that 04 Nov occurrence, marked "No delay"
           3  estimate carries one line twice: rear bumper assembly Rs 12,000 x2
           4  estimate is dated 03 Nov, two days BEFORE the claimed 05 Nov incident
           5  towing receipt is dated 06 Nov - a day AFTER the incident
           6  estimate total Rs 57,820 > claimed Rs 52,780
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _base
from _base import fir, repair, towing

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lane-b-ui", "documents")
os.makedirs(OUT, exist_ok=True)
_base.OUT = OUT

WS = "SRI VENKATA SAI MOTORS"
_base.WORKSHOP = WS
_base.WORKSHOP_SUB = "Door 5-9-88, Kukatpally Housing Board Colony, Hyderabad - 500072 \u00b7 GSTIN 36AAGFS9931R1Z4"
_base.WORKSHOP_GSTIN = "36AAGFS9931R1Z4"

CAR = "TG13MX4747"          # the claim form's vehicle (correct on both claims)
CAR_TYPO = "TG13MX4477"     # the FIR-02 transposition
PEOPLE = ("Suresh Pillai", "Harish Pillai", "41 years / 1985",
          "Driver (commercial taxi)")
ADDR = "H.No. 2-22/7, KPHB Colony, Kukatpally, Hyderabad - 500072"

# =============================================================================
# CLAIM A — clean.  Incident 05-Nov-2026 10:22.
# parts 31,860 + labour 15,570 + supplies 2,000 = 49,430 ; 18% = 8,897.40 ; total 58,327.40
# =============================================================================
fir("FIR-01-clean.pdf",
    district="Hyderabad", ps="Kukatpally", year="2026", fir_no="0264 / 2026",
    reg_date="05 November 2026",
    occ_from="05-Nov-2026 10:10 hrs", occ_to="05-Nov-2026 10:40 hrs",
    place="KPHB Phase 6 main road, near the vegetable market, Hyderabad - 500072",
    complainant=PEOPLE[0], father=PEOPLE[1], age=PEOPLE[2], occupation=PEOPLE[3],
    address=ADDR,
    accused=("Unknown \u2014 being traced", "Unknown", "Unknown"),
    delay_reason="No delay",
    vehicle_self=(CAR, "Maruti Suzuki Ertiga (commercial taxi)"),
    vehicle_other=("TG07GH5521", "Tata Ace goods carrier"),
    property_desc="Damage to front bumper, bonnet edge and right headlamp of TG13MX4747",
    property_value=58327,
    narrative=("At about 10:22 hrs on 5 November 2026 the complainant was driving his Maruti Suzuki "
               "Ertiga bearing registration TG13MX4747 south on the KPHB Phase 6 main road, carrying "
               "one passenger, when a Tata Ace goods carrier bearing registration TG07GH5521 reversed "
               "out of a side lane without warning and struck the front of his vehicle. The front "
               "bumper, bonnet edge and right headlamp were damaged. The complainant and the passenger "
               "sustained no injuries. The goods carrier driver stopped and exchanged details and the "
               "vehicle was later taken to Sri Venkata Sai Motors. Property damaged: front bumper, bonnet "
               "edge and right headlamp, estimated at Rs 58,327."),
    action=("Case registered. Vehicle TG13MX4747 inspected on 5 November 2026. Notice issued to "
            "TG07GH5521 owner. Investigation is in progress."),
    officer="V. Ramanaiah", rank="Head Constable", gd_entry="No. 7 / 05.11.2026",
    received_time="12:20 hrs")

repair("RepairEstimate-01-clean.pdf", est_no="SVSM/EST/26/0614", date="05 November 2026",
       customer="Coastal Spice Logistics Pvt Ltd", vehicle=CAR, model="Maruti Suzuki Ertiga",
       odometer="94,120 km", job_card="JC-26-1104",
       parts=[("MS-EB-3302", "Front bumper assembly (OEM)", 1, 1, 9600.00),
              ("MS-BN-1180", "Bonnet edge panel", 1, 1, 7450.00),
              ("MS-HL-7720", "Headlamp assembly \u2014 right", 1, 1, 12400.00),
              ("MS-GR-2215", "Grille and clips", 1, 1, 2410.00)],
       labour=[("Bumper removal and refit", 4, 780.00, 3120.00),
               ("Bonnet edge repair and paint", 7, 890.00, 6230.00),
               ("Headlamp alignment", 2, 780.00, 1560.00),
               ("Paint booth \u2014 two panels", 5, 932.00, 4660.00)],
       supplies=2000,
       tax_rate_printed=18, tax_amount_printed=8897.40, total_printed=58327.40,
       remarks=("Vehicle received on 5 November 2026 at 13:30 hrs. No damage to the radiator or "
                "structural members. Alignment checked and found within tolerance."),
       footer_note="Estimate valid for 20 days. Delivery in 5 working days.")

towing("TowingReceipt-01-clean.pdf", receipt_no="KPR / 2207", date="05 November 2026",
       time="12:05 hrs", company="Kukatpally Recovery Services",
       address="Plot 21, KPHB Phase 6, Hyderabad - 500072", phone="+91 40 2715 2207",
       make="Maruti Suzuki", model="Ertiga", year="2019", tag=CAR,
       vin="MA3ERLD1S00K77193", owner="Coastal Spice Logistics Pvt Ltd",
       from_loc="KPHB Phase 6 main road, near the vegetable market",
       to_loc="Sri Venkata Sai Motors, Door 5-9-88, KPHB Colony",
       reason="Road traffic accident \u2014 front-end damage, headlamp not functional",
       services=[("Flatbed tow \u2014 2 km", 1200), ("Winch pull from kerb", 400)],
       tax_rate=0, tax_amount=0, total_printed=1600, paid=1600,
       operator="Naveen Reddy", truck="TG09TR1188", payment_method="UPI (GPay)")

# =============================================================================
# CLAIM B — unclean.  Claim form: CAR, 05-Nov-2026 16:45, claimed Rs 52,780.
# parts 36,700 (bumper counted twice) + labour 10,800 + supplies 1,500 = 49,000
# 18% = 8,820 ; total 57,820. Dated 03 Nov (defect 4).
# =============================================================================
fir("FIR-02-defects.pdf",
    district="Hyderabad", ps="Kukatpally", year="2026", fir_no="0291 / 2026",
    reg_date="09 November 2026",
    occ_from="04-Nov-2026 14:00 hrs", occ_to="04-Nov-2026 15:00 hrs",
    place="KPHB Phase 6 main road, near the vegetable market, Hyderabad - 500072",
    complainant=PEOPLE[0], father=PEOPLE[1], age=PEOPLE[2], occupation=PEOPLE[3],
    address=ADDR,
    accused=("Unknown \u2014 being traced", "Unknown", "Unknown"),
    delay_reason="No delay",
    vehicle_self=(CAR_TYPO, "Maruti Suzuki Ertiga (commercial taxi)"),
    vehicle_other=("TG07GH5521", "Tata Ace goods carrier"),
    property_desc="Damage to rear bumper and tailgate of TG13MX4477",
    property_value=52780,
    narrative=("The complainant states that on 4 November 2026 between 14:00 and 15:00 hrs he was "
               "driving his Maruti Suzuki Ertiga bearing registration TG13MX4477 on the KPHB Phase 6 "
               "main road when a Tata Ace goods carrier bearing registration TG07GH5521 reversed out "
               "of a side lane and struck the rear of his vehicle. The rear bumper and tailgate were "
               "damaged. No injuries were reported. The vehicle was later shifted for repairs."),
    action=("Case registered. Vehicle TG13MX4477 produced for inspection on 9 November 2026. "
            "Investigation is in progress."),
    officer="V. Ramanaiah", rank="Head Constable", gd_entry="No. 19 / 09.11.2026",
    received_time="10:15 hrs")

repair("RepairEstimate-02-defects.pdf", est_no="SVSM/EST/26/0602", date="03 November 2026",
       customer="Coastal Spice Logistics Pvt Ltd", vehicle=CAR, model="Maruti Suzuki Ertiga",
       odometer="94,905 km", job_card="JC-26-1098",
       parts=[("MS-RB-4410", "Rear bumper assembly (OEM)", 1, 12000.00, 12000.00),
              ("MS-TG-8810", "Tailgate outer panel", 1, 8400.00, 8400.00),
              ("MS-RL-6602", "Rear combination lamp \u2014 right", 1, 4300.00, 4300.00),
              ("MS-RB-4410", "Rear bumper assembly (OEM)", 1, 12000.00, 12000.00)],
       labour=[("Bumper removal and refit", 3, 800.00, 2400.00),
               ("Tailgate dent and paint", 8, 850.00, 6800.00),
               ("Paint booth \u2014 two panels", 2, 800.00, 1600.00)],
       supplies=1500,
       tax_rate_printed=18, tax_amount_printed=8820, total_printed=57820,
       remarks=("Vehicle received on 3 November 2026. Rear structure inspected and found "
                "serviceable. Delivery in 4 working days."),
       footer_note="Estimate valid for 15 days. Parts subject to availability.")

towing("TowingReceipt-02-defects.pdf", receipt_no="KPR / 2241", date="06 November 2026",
       time="09:15 hrs", company="Kukatpally Recovery Services",
       address="Plot 21, KPHB Phase 6, Hyderabad - 500072", phone="+91 40 2715 2207",
       make="Maruti Suzuki", model="Ertiga", year="2019", tag=CAR,
       vin="MA3ERLD1S00K77193", owner="Coastal Spice Logistics Pvt Ltd",
       from_loc="KPHB Phase 6 main road, near the vegetable market",
       to_loc="Sri Venkata Sai Motors, Door 5-9-88, KPHB Colony",
       reason="Road traffic accident \u2014 rear-end damage, tailgate not closing",
       services=[("Flatbed tow \u2014 2 km", 1200), ("Storage \u2014 1 day", 400)],
       tax_rate=18, tax_amount=288, total_printed=1888, paid=1888,
       operator="Naveen Reddy", truck="TG09TR1188", payment_method="UPI (GPay)")

print("\nLane B documents written to", os.path.abspath(OUT))
