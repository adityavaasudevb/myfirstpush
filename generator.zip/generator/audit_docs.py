#!/usr/bin/env python3
"""Verify every stated invariant in the generated PDFs by re-extracting the printed text."""
import os, re, sys
import pymupdf

def txt(path):
    return " ".join(" ".join(p.get_text() for p in pymupdf.open(path)).split())

def money(s):
    return float(s.replace("\u20b9", "").replace(",", "").replace("\u2212", "-"))

def find_amount_after(text, label):
    i = text.find(label)
    if i < 0: return None
    tail = text[i + len(label): i + len(label) + 40]
    m = re.search(r"\u20b9\s?([\d,]+(?:\.\d{2})?)", tail)
    return money(m.group(1)) if m else None

def check(name, cond, detail=""):
    print(("  PASS " if cond else "  FAIL ") + name + (f"   {detail}" if detail else ""))
    return cond

def audit_lane_a(d):
    ok = True
    e = txt(os.path.join(d, "RepairEstimate-01-clean.pdf"))
    print("\nRepairEstimate-01-clean")
    parts = sum([24600, 3950, 12200, 2350]); labour = sum([5100, 3400, 5400, 1500])
    base = parts + labour + 1800
    ok &= check("parts subtotal prints", find_amount_after(e, "Parts subtotal") == parts, f"{parts}")
    ok &= check("labour subtotal prints", find_amount_after(e, "Labour subtotal") == labour, f"{labour}")
    ok &= check("base 60,300", base == 60300, str(base))
    tax = find_amount_after(e, "Tax at 18%")
    ok &= check("tax = 18% of base", abs(tax - base * 0.18) < 1, f"printed {tax}")
    total = find_amount_after(e, "Estimated total")
    ok &= check("total = base + tax", abs(total - (base + tax)) < 1, f"printed {total}")

    e2 = txt(os.path.join(d, "RepairEstimate-02-defects.pdf"))
    print("\nRepairEstimate-02-defects")
    p2 = sum([14800, 9600, 9800]); l2 = sum([6800, 3400, 2550]); b2 = p2 + l2 + 1200
    tax2 = find_amount_after(e2, "Tax at 18%")
    total2 = find_amount_after(e2, "Estimated total")
    ok &= check("PLANTED: tax overstated vs 18%", abs(tax2 - b2 * 0.18) > 1, f"printed {tax2} vs expected {b2*0.18:.0f}")
    ok &= check("total still reconciles with the inflated tax", abs(total2 - (b2 + tax2)) < 1, f"{total2}")

    t1 = txt(os.path.join(d, "TowingReceipt-01-clean.pdf"))
    print("\nTowingReceipt-01-clean")
    ok &= check("subtotal 2,000", find_amount_after(t1, "Subtotal") == 2000)
    ok &= check("total 2,000", find_amount_after(t1, "Total") == 2000)
    t2 = txt(os.path.join(d, "TowingReceipt-02-defects.pdf"))
    print("\nTowingReceipt-02-defects")
    ok &= check("PLANTED: other workshop (Sri Kalyan)", "Sri Kalyan Motors" in t2)
    ok &= check("no Meghna destination on the defective tow", "towed to Meghna" not in t2 and "to: Meghna" not in t2.lower())

    f1 = txt(os.path.join(d, "FIR-01-clean.pdf"))
    print("\nFIR-01-clean")
    ok &= check("complainant Karthik Iyer", "Karthik Iyer" in f1)
    ok &= check("vehicle TG11LK3607", "TG11LK3607" in f1)
    ok &= check("occurrence 10-Nov 10:55-11:20", "10-Nov-2026 10:55" in f1 and "10-Nov-2026 11:20" in f1)
    ok &= check("received after the collision (13:10)", "13:10 hrs" in f1)
    return ok

def audit_lane_b(d):
    ok = True
    e = txt(os.path.join(d, "RepairEstimate-01-clean.pdf"))
    print("\n[B] RepairEstimate-01-clean")
    parts, labour, sup = 31860, 15570, 2000
    base = parts + labour + sup
    ok &= check("parts subtotal", find_amount_after(e, "Parts subtotal") == parts, parts)
    ok &= check("labour subtotal", find_amount_after(e, "Labour subtotal") == labour, labour)
    tax = find_amount_after(e, "Tax at 18%")
    total = find_amount_after(e, "Estimated total")
    ok &= check("tax = 18% of 49,430", abs(tax - base * 0.18) < 1, tax)
    ok &= check("total = 58,327.40", abs(total - (base + tax)) < 0.01, total)

    e2 = txt(os.path.join(d, "RepairEstimate-02-defects.pdf"))
    print("\n[B] RepairEstimate-02-defects")
    ok &= check("PLANTED: dated 03 Nov 2026 (before the 05 Nov claim)", "03 November 2026" in e2)
    ok &= check("PLANTED: rear bumper assembly repeated", e2.count("Rear bumper assembly") == 2,
                f"count={e2.count('Rear bumper assembly')}")
    ok &= check("PLANTED: total 57,820 exceeds claimed 52,780", find_amount_after(e2, "Estimated total") == 57820)
    parts2, lab2, sup2 = 12000 + 8400 + 4300 + 12000, 2400 + 6800 + 1600, 1500
    tax2 = find_amount_after(e2, "Tax at 18%")
    ok &= check("tax row is internally 18% of the printed base", abs(tax2 - (parts2+lab2+sup2) * 0.18) < 1,
                f"printed {tax2} vs {(parts2+lab2+sup2)*0.18:.0f}")
    ok &= check("defect is ONLY the duplicate: base minus one bumper = 37,000",
                parts2 + lab2 + sup2 - 12000 == 37000)

    f2 = txt(os.path.join(d, "FIR-02-defects.pdf"))
    print("\n[B] FIR-02-defects")
    ok &= check("PLANTED: reg typo TG13MX4477", "TG13MX4477" in f2)
    ok &= check("correct reg TG13MX4747 absent", "TG13MX4747" not in f2)
    ok &= check("PLANTED: occurrence 04-Nov", "04-Nov-2026 14:00" in f2)
    ok &= check("PLANTED: registered 09 Nov, 'No delay'", "09 November 2026" in f2 and "No delay" in f2)

    t2 = txt(os.path.join(d, "TowingReceipt-02-defects.pdf"))
    print("\n[B] TowingReceipt-02-defects")
    ok &= check("PLANTED: towing dated 06 Nov (a day after the 05 Nov incident)", "06 November 2026" in t2)
    ok &= check("correct reg on the tow", "TG13MX4747" in t2)
    return ok


if __name__ == "__main__":
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    ok = audit_lane_a(os.path.join(root, "lane-a-sql", "documents"))
    ok &= audit_lane_b(os.path.join(root, "lane-b-ui", "documents"))
    print("\nALL CHECKS PASS" if ok else "\nSOME CHECKS FAILED")
    sys.exit(0 if ok else 1)
