#!/usr/bin/env python3
"""
LANE A — "Greenfield Fabrication Works" SQL lane test documents.
Claim incident: 10 November 2026, 11:05 IST.  Policy term: 01 Oct 2026 -> 30 Sep 2027.

CLEAN chain  (Claim A, Own Vehicle Damage, Rs 68,900)
  FIR-01-clean / RepairEstimate-01-clean / TowingReceipt-01-clean
  Every value matches the claim form row in lane-a-sql/README-A.md.

DEFECT chain (Claim B, Own Vehicle Damage, Rs 44,500) - no FIR, only 2 documents
  RepairEstimate-02 and TowingReceipt-02. Planted defects are listed in README-A.md.

Run:  python3 lane_a_greenfield.py     (writes into ../lane-a-sql/documents/)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _base
from _base import fir, repair, towing, hospital, pharmacy

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lane-a-sql", "documents")
os.makedirs(OUT, exist_ok=True)
_base.OUT = OUT

# ---- lane identity -----------------------------------------------------------
WS = "MEGHNA AUTO BODY WORKS"
_base.WORKSHOP = WS
_base.WORKSHOP_SUB = "Survey 44/2, Miyapur X Roads, Hyderabad - 500049 \u00b7 GSTIN 36AAPFM4412L1ZK"
_base.WORKSHOP_GSTIN = "36AAPFM4412L1ZK"
HOSP = "AADHYA MULTISPECIALITY HOSPITAL"
_base.HOSPITAL = HOSP
_base.HOSPITAL_SUB = "Plot 22, Nizampet Road, Bachupally, Hyderabad - 500090 \u00b7 GSTIN 36AAECA2211M1Z8"

CAR1 = ("TG11LK3607", "Ashok Leyland Dost (commercial load vehicle)")
CAR2 = ("TG11LK3607", "Ashok Leyland Dost (commercial load vehicle)")

# =============================================================================
# CLAIM A  (clean)  incident 10-Nov-2026 11:05, claimed Rs 71,154
# =============================================================================
fir("FIR-01-clean.pdf",
    district="Rangareddy", ps="Miyapur", year="2026", fir_no="0218 / 2026",
    reg_date="10 November 2026",
    occ_from="10-Nov-2026 10:55 hrs", occ_to="10-Nov-2026 11:20 hrs",
    place="Miyapur X Roads, opposite the metro pillar 1189, Hyderabad - 500049",
    complainant="Karthik Iyer", father="Ramanathan", age="36 years / 1990",
    occupation="Driver (goods vehicle)",
    address="H.No. 8-1-44, Madeenaguda, Miyapur, Hyderabad - 500049",
    accused=("Unknown \u2014 being traced", "Unknown", "Unknown"),
    delay_reason="No delay",
    vehicle_self=("TG11LK3607", "Ashok Leyland Dost (commercial load vehicle)"),
    vehicle_other=("TG09EF2214", "Mahindra Bolero pick-up"),
    property_desc="Damage to left door, left mirror and load-body side panel of TG11LK3607",
    property_value=71154,
    narrative=("On 10 November 2026 between 10:55 and 11:20 hrs the complainant was driving his Ashok "
               "Leyland Dost bearing registration TG11LK3607 on the Miyapur main road and had slowed to "
               "turn left into the service lane when a Mahindra Bolero pick-up bearing registration "
               "TG09EF2214 overtook from the left and scraped the left side of his vehicle. The left door, "
               "left mirror and load-body side panel were damaged. The complainant was alone and was not "
               "injured. The offending vehicle stopped ahead and its driver fled on foot. The vehicle was "
               "later towed to Meghna Auto Body Works. Property damaged: door, mirror and load-body side "
               "panel, estimated at Rs 68,900."),
    action=("Case registered. Vehicle TG11LK3607 inspected by the motor vehicle inspector on 10 November "
            "2026. Requisition issued to trace TG09EF2214. Investigation is in progress."),
    officer="P. Anjaneyulu", rank="Sub-Inspector of Police", gd_entry="No. 12 / 10.11.2026",
    received_time="13:10 hrs")

repair("RepairEstimate-01-clean.pdf", est_no="MAB/EST/2026/0418", date="10 November 2026",
       customer="Greenfield Fabrication Works Pvt Ltd", vehicle=CAR1[0], model="Ashok Leyland Dost",
       odometer="1,18,440 km", job_card="JC-2026-0921",
       parts=[("AL-D-2231", "Door assembly \u2014 left (OEM)", 1, 24600.00, 24600.00),
              ("AL-M-0091", "Mirror assembly \u2014 left, electric", 1, 3950.00, 3950.00),
              ("AL-P-4470", "Side panel \u2014 load body, MS sheet", 1, 12200.00, 12200.00),
              ("AL-C-1120", "Door lock and latch set", 1, 2350.00, 2350.00)],
       labour=[("Dent and shape correction", 6, 850.00, 5100.00),
               ("Refit and alignment of door", 4, 850.00, 3400.00),
               ("Paint booth \u2014 two panels", 6, 900.00, 5400.00),
               ("Electrical refit \u2014 mirror and lock", 2, 750.00, 1500.00)],
       supplies=1800,
       tax_rate_printed=18, tax_amount_printed=10854, total_printed=71154,
       remarks=("Vehicle received on 10 November 2026 at 14:10 hrs with left-side impact damage. "
                "No structural damage to the chassis. Loading body found serviceable."),
       footer_note=("Estimate prepared from physical inspection after removal of the left door trim. "
                    "Estimate valid for 20 days. Delivery in 6 working days."))

towing("TowingReceipt-01-clean.pdf", receipt_no="MRT / 1164", date="10 November 2026",
       time="12:45 hrs", company="Miyapur Road Towing",
       address="Survey 9, Miyapur X Roads, Hyderabad - 500049", phone="+91 40 2304 1164",
       make="Ashok Leyland", model="Dost", year="2022", tag=CAR1[0],
       vin="MB1KAA22SKJ000419", owner="Greenfield Fabrication Works Pvt Ltd",
       from_loc="Miyapur X Roads, opposite metro pillar 1189",
       to_loc="Meghna Auto Body Works, Survey 44/2, Miyapur X Roads",
       reason="Road traffic accident \u2014 left-side collision damage, door not operational",
       services=[("Flatbed tow \u2014 3 km", 1400), ("Door tie-down and safety film", 350),
                 ("Loading assistance", 250)],
       tax_rate=0, tax_amount=0, total_printed=2000, paid=2000,
       operator="Mahesh Goud", truck="TG09TR3390", payment_method="UPI (PhonePe)")

# =============================================================================
# CLAIM B  (defects)  two documents only: estimate + towing, no FIR
# Claim form says: vehicle TG11LK3607, incident 10-Nov-2026 16:40, claimed Rs 44,500
#   D1  estimate is for a DIFFERENT vehicle (TG11LK3617)
#   D2  estimate is dated 08-Nov-2026, two days BEFORE the incident
#   D3  "Tax at 18%" is printed as Rs 11,160; 18% of the Rs 48,150 base is Rs 8,667
#       (Rs 2,493 overstated). Lines->subtotal and subtotal+tax->total are both consistent,
#       so only a rate check catches it.
#   D4  invoice total Rs 59,310 > claimed Rs 44,500
#   D5  towing drops the vehicle at Sri Kalyan Motors, but the repair estimate is from
#       Meghna Auto Body Works -> the two documents describe different repairers
# =============================================================================
repair("RepairEstimate-02-defects.pdf", est_no="MAB/EST/2026/0431", date="08 November 2026",
       customer="Greenfield Fabrication Works Pvt Ltd", vehicle="TG11LK3617", model="Ashok Leyland Dost",
       odometer="1,21,905 km", job_card="JC-2026-0934",
       parts=[("AL-CL-7712", "Clutch plate assembly (OEM)", 1, 14800.00, 14800.00),
              ("AL-PL-3301", "Pressure plate", 1, 9600.00, 9600.00),
              ("AL-BR-1180", "Brake drum \u2014 rear pair", 2, 4900.00, 9800.00)],
       labour=[("Gearbox removal and refit", 8, 850.00, 6800.00),
               ("Clutch replacement", 4, 850.00, 3400.00),
               ("Brake overhaul", 3, 850.00, 2550.00)],
       supplies=1200,
       tax_rate_printed=18, tax_amount_printed=11160, total_printed=59310,
       remarks=("Vehicle received on 8 November 2026 for clutch and brake work. Front end inspected "
                "and found serviceable."),
       footer_note="Estimate valid for 15 days. Spares subject to availability.")

towing("TowingReceipt-02-defects.pdf", receipt_no="MRT / 1188", date="10 November 2026",
       time="17:30 hrs", company="Miyapur Road Towing",
       address="Survey 9, Miyapur X Roads, Hyderabad - 500049", phone="+91 40 2304 1164",
       make="Ashok Leyland", model="Dost", year="2022", tag=CAR1[0],
       vin="MB1KAA22SKJ000419", owner="Greenfield Fabrication Works Pvt Ltd",
       from_loc="Miyapur X Roads", to_loc="Sri Kalyan Motors, Kukatpally",
       reason="Vehicle recovered after breakdown \u2014 clutch failure, vehicle not drivable",
       services=[("Flatbed tow \u2014 3 km", 1400), ("Storage \u2014 2 days", 600)],
       tax_rate=18, tax_amount=360, total_printed=2360, paid=2360,
       operator="Mahesh Goud", truck="TG09TR3390", payment_method="Cash")

# =============================================================================
# MEDICAL pair - written now, used by the v3.4 medical flow, not by the demo lanes
# =============================================================================
hospital("MedicalBill-01-clean.pdf", bill_no="AMH/IP/26/7710",
         bill_datetime="11 November 2026, 18:40 hrs",
         patient="Karthik Iyer", address="H.No. 8-1-44, Madeenaguda, Miyapur, Hyderabad - 500049",
         ip_no="IP-26-33418", consultant="Dr. S. Nadella", department="Orthopaedics",
         accommodation="General ward", room_no="GW-214", diagnosis="Contusion to left forearm and wrist sprain",
         admission="10 November 2026, 15:05 hrs", discharge="11 November 2026, 11:30 hrs",
         payment="UPI",
         prof_fees=[("Orthopaedic consultation", "Visit", 2, 700.00, 0, 1400.00),
                    ("Wound dressing \u2014 forearm", "Session", 2, 450.00, 0, 900.00),
                    ("Physiotherapy \u2014 wrist", "Session", 1, 800.00, 0, 800.00)],
         billing_heads=[("Room charges \u2014 general ward", "Day", 1, 1800.00, 0, 1800.00),
                        ("Nursing care", "Day", 1, 900.00, 0, 900.00),
                        ("Pharmacy and consumables", "Lump sum", 1, 2340.00, 12, 2620.80),
                        ("X-ray \u2014 left wrist AP and lateral", "Film", 2, 550.00, 12, 1232.00)],
         subtotal_printed=9652.80, discount_printed=0,
         final_printed=9652.80, paid_printed=9652.80, balance_printed=0,
         declaration="Certified that the patient named above was treated at this hospital and was "
                     "discharged on 11 November 2026.")

pharmacy("MedicalBill-03-pharmacy.pdf", invoice_no="APX-26033214",
         date_time="11 November 2026, 20:15 hrs",
         customer="Karthik Iyer \u2014 Rx from Dr. S. Nadella",
         items=[(1, "Wrist brace \u2014 elastic, medium", "30059090", "WB-M-2210", "Oct-28", 640, 6, 6, 640.00, 716.80),
                (1, "Diclofenac gel 30 g", "30049099", "DG-30-1102", "Mar-28", 165, 6, 6, 165.00, 184.80),
                (1, "Surgical dressing pack", "30059010", "SDP-2210", "Dec-28", 190, 6, 6, 190.00, 212.80)],
         total_printed=1114.40, discount_printed=0.00, net_printed=1114.40)

print("\nLane A documents written to", os.path.abspath(OUT))
