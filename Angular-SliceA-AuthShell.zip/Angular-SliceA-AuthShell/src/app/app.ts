import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AlertsComponent } from './shared/toast/toast';

// Root — layouts own the chrome; the root only hosts toast notifications.
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, AlertsComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <tnc-alerts />
    <router-outlet />
  `,
})
export class AppComponent {}
