import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

// App layout — role-aware navbar for all authenticated workspaces.
@Component({
  selector: 'tnc-app-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (auth.user(); as u) {
      <header class="sticky top-0 z-50 border-b border-warm bg-white/90 backdrop-blur">
        <div class="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <a routerLink="/" class="flex items-center gap-3">
            <span class="grid h-9 w-9 place-items-center rounded-full bg-primary font-serif text-lg font-bold text-white">H</span>
            <span class="font-serif text-lg font-semibold tracking-tight text-primary">TNC Fleet Insurance</span>
          </a>

          <nav class="flex items-center gap-1 text-sm font-medium">
            @if (u.role === 'Company') {
              <a class="nav-link" routerLink="/company" routerLinkActive="nav-active" [routerLinkActiveOptions]="{ exact: true }">Workspace</a>
            } @else if (u.role === 'Surveyor') {
              <a class="nav-link" routerLink="/surveyor" routerLinkActive="nav-active" [routerLinkActiveOptions]="{ exact: true }">Workspace</a>
            } @else if (u.role === 'Admin') {
              <a class="nav-link" routerLink="/admin" routerLinkActive="nav-active" [routerLinkActiveOptions]="{ exact: true }">Workspace</a>
            }
          </nav>

          <div class="flex items-center gap-3">
            <div class="hidden text-right sm:block">
              <p class="text-xs font-semibold text-ink">{{ u.email }}</p>
              <p class="text-[11px] uppercase tracking-wide text-ink-soft">{{ u.role }}</p>
            </div>
            <button type="button" class="btn-outline !px-3 !py-1.5" (click)="auth.logout()">Sign out</button>
          </div>
        </div>
      </header>
    }

    <main>
      <router-outlet />
    </main>
  `,
  styles: [
    `
      .nav-link {
        padding: 0.375rem 0.75rem;
        border-radius: 0.5rem;
        color: var(--color-ink-soft);
        transition: color 150ms ease, background-color 150ms ease;
      }
      .nav-link:hover {
        color: var(--color-primary);
        background: var(--color-warm-light);
      }
      .nav-active {
        color: var(--color-primary);
        background: var(--color-primary-faint);
      }
    `,
  ],
})
export class AppLayoutComponent {
  readonly auth = inject(AuthService);
}
