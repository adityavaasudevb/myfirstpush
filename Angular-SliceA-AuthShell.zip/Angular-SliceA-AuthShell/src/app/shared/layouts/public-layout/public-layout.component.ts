import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

// Public layout — slim brand header + footer for landing and auth pages.
@Component({
  selector: 'tnc-public-layout',
  imports: [RouterOutlet, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex min-h-screen flex-col bg-warm-lightest">
      <header class="border-b border-warm bg-white">
        <div class="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <a routerLink="/" class="flex items-center gap-3">
            <span class="grid h-9 w-9 place-items-center rounded-full bg-primary font-serif text-lg font-bold text-white">H</span>
            <span class="font-serif text-lg font-semibold tracking-tight text-primary">TNC Fleet Insurance</span>
          </a>
          <a routerLink="/auth" class="btn-primary">Sign in</a>
        </div>
      </header>

      <main class="flex flex-1 flex-col">
        <router-outlet />
      </main>

      <footer class="border-t border-warm bg-white py-6">
        <p class="mx-auto max-w-6xl px-4 text-xs text-ink-soft">
          TNC Fleet Insurance · A training project styled after The Hartford brand system (claret · fuchsia · warm grey).
        </p>
      </footer>
    </div>
  `,
})
export class PublicLayoutComponent {}
