import { Injectable, Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { NgClass } from '@angular/common';

// ---- AlertService: app-wide toast notifications ----
export type AlertKind = 'success' | 'error' | 'info';
export interface AlertMsg {
  id: number;
  kind: AlertKind;
  text: string;
}

@Injectable({ providedIn: 'root' })
export class AlertService {
  readonly alerts = signal<AlertMsg[]>([]);
  private nextId = 1;

  show(kind: AlertKind, text: string, autoDismissMs = 4500): void {
    const msg: AlertMsg = { id: this.nextId++, kind, text };
    this.alerts.update((list) => [...list, msg]);
    if (autoDismissMs > 0) {
      setTimeout(() => this.dismiss(msg.id), autoDismissMs);
    }
  }
  success(text: string): void { this.show('success', text); }
  error(text: string): void { this.show('error', text, 6000); }
  info(text: string): void { this.show('info', text); }
  dismiss(id: number): void {
    this.alerts.update((list) => list.filter((a) => a.id !== id));
  }
}

// ---- AlertsComponent: renders the toast stack ----
@Component({
  selector: 'tnc-alerts',
  imports: [NgClass],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fixed top-4 right-4 z-[100] flex w-[min(24rem,90vw)] flex-col gap-2">
      @for (a of alerts.alerts(); track a.id) {
        <div
          class="card flex items-start gap-3 border-l-4 px-4 py-3 text-sm shadow-lg shadow-ink/5"
          [ngClass]="{
            'border-l-success': a.kind === 'success',
            'border-l-danger': a.kind === 'error',
            'border-l-accent': a.kind === 'info',
          }"
        >
          <span class="mt-0.5 h-2 w-2 shrink-0 rounded-full"
                [ngClass]="{
                  'bg-success': a.kind === 'success',
                  'bg-danger': a.kind === 'error',
                  'bg-accent': a.kind === 'info',
                }"></span>
          <p class="flex-1 leading-snug text-ink">{{ a.text }}</p>
          <button
            type="button"
            class="cursor-pointer text-ink-soft transition-colors hover:text-ink"
            aria-label="Dismiss"
            (click)="alerts.dismiss(a.id)"
          >✕</button>
        </div>
      }
    </div>
  `,
})
export class AlertsComponent {
  readonly alerts = inject(AlertService);
}
