import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';
import { AlertService } from '../../../shared/toast/toast';

// Surveyor application — full IRDAI form; lands in the admin approval queue.
@Component({
  selector: 'tnc-register-surveyor',
  imports: [ReactiveFormsModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-1 items-center justify-center px-4 py-16">
      <div class="w-full max-w-lg">
        <div class="card p-8">
          <h1 class="font-serif text-2xl font-semibold text-ink">Apply as a surveyor</h1>
          <p class="mt-1 text-sm text-ink-soft">Our admin team reviews every application before access is granted.</p>

          @if (error(); as e) {
            <p class="mt-4 rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger">{{ e }}</p>
          }

          <form class="mt-6 grid gap-4 sm:grid-cols-2" [formGroup]="form" (ngSubmit)="submit()">
            <div class="sm:col-span-2">
              <label class="label" for="s-name">Full name</label>
              <input id="s-name" class="input" formControlName="name" placeholder="Suresh Kumar" />
            </div>
            <div>
              <label class="label" for="s-email">Email</label>
              <input id="s-email" type="email" class="input" formControlName="email" placeholder="you@survey.in" />
            </div>
            <div>
              <label class="label" for="s-pass">Password</label>
              <input id="s-pass" type="password" class="input" formControlName="password" placeholder="Min. 6 characters" />
            </div>
            <div>
              <label class="label" for="s-contact">Contact info</label>
              <input id="s-contact" class="input" formControlName="contactInfo" placeholder="+91-98xxx-xxxxx" />
            </div>
            <div>
              <label class="label" for="s-lic">IRDAI licence valid until</label>
              <input id="s-lic" type="date" class="input" formControlName="licenseValidUntil" />
            </div>
            <div class="sm:col-span-2">
              <label class="label" for="s-irdai">IRDAI licence number</label>
              <input id="s-irdai" class="input" formControlName="irdaiLicenseNumber" placeholder="IRDAI/SLA/2024/014533" />
            </div>

            <button type="submit" class="btn-primary sm:col-span-2" [disabled]="form.invalid || busy()">
              {{ busy() ? 'Submitting…' : 'Submit application' }}
            </button>
          </form>

          <p class="mt-5 text-center text-xs leading-relaxed text-ink-soft">
            After submission you'll see a confirmation. You'll be able to sign in
            once an administrator approves your licence.
          </p>
          <p class="mt-3 text-center text-sm text-ink-soft">
            Already approved? <a class="link" routerLink="/auth/login/surveyor">Sign in</a>
          </p>
        </div>
      </div>
    </div>
  `,
})
export class RegisterSurveyorPage {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly alerts = inject(AlertService);
  private readonly router = inject(Router);

  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    contactInfo: ['', Validators.required],
    irdaiLicenseNumber: ['', Validators.required],
    licenseValidUntil: ['', Validators.required], // yyyy-mm-dd from <input type=date>
  });

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);

    this.auth.registerSurveyor(this.form.getRawValue()).subscribe({
      next: () => {
        this.alerts.success('Application received — an administrator will review your licence shortly.');
        this.router.navigateByUrl('/');
      },
      error: (err) => {
        this.busy.set(false);
        this.error.set(responseErrorText(err));
      },
    });
  }
}
