import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';

// Role cards: Continue as Company / Surveyor (+ quiet admin link).
@Component({
  selector: 'tnc-auth-entry',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-1 items-center justify-center px-4 py-16">
        <div class="w-full max-w-3xl">
          <h1 class="text-center font-serif text-3xl font-semibold text-ink">Welcome back.</h1>
          <p class="mt-2 text-center text-sm text-ink-soft">Choose how you'd like to continue.</p>

          <div class="mt-10 grid gap-5 sm:grid-cols-2">
            <!-- Company card -->
            <div class="card flex flex-col p-8 transition-shadow duration-150 hover:shadow-lg hover:shadow-ink/5">
              <span class="grid h-11 w-11 place-items-center rounded-full bg-primary-faint text-xl">🏢</span>
              <h2 class="mt-4 font-serif text-xl font-semibold text-ink">I'm a company</h2>
              <p class="mt-1 flex-1 text-sm leading-relaxed text-ink-soft">
                Quotes, policies, claims and renewals for your ride-share fleet.
              </p>
              <a routerLink="/auth/login/company" class="btn-primary mt-6">Continue as company</a>
              <p class="mt-3 text-center text-xs text-ink-soft">
                New here? <a routerLink="/auth/register/company" class="link">Create a company account</a>
              </p>
            </div>

            <!-- Surveyor card -->
            <div class="card flex flex-col p-8 transition-shadow duration-150 hover:shadow-lg hover:shadow-ink/5">
              <span class="grid h-11 w-11 place-items-center rounded-full bg-primary-faint text-xl">🔍</span>
              <h2 class="mt-4 font-serif text-xl font-semibold text-ink">I'm a surveyor</h2>
              <p class="mt-1 flex-1 text-sm leading-relaxed text-ink-soft">
                Inspect claims, verify evidence and submit your report. IRDAI licence required.
              </p>
              <a routerLink="/auth/login/surveyor" class="btn-outline mt-6">Continue as surveyor</a>
              <p class="mt-3 text-center text-xs text-ink-soft">
                New here? <a routerLink="/auth/register/surveyor" class="link">Apply as a surveyor</a>
              </p>
            </div>
          </div>

          <p class="mt-10 text-center text-xs text-ink-soft">
            Administrator? <a routerLink="/auth/login/admin" class="link">Sign in here</a>
          </p>
        </div>
    </div>
  `,
})
export class AuthEntryPage {}
