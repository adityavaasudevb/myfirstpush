import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';

// Company registration — email + password only (profile comes after first login).
@Component({
  selector: 'tnc-register-company',
  imports: [ReactiveFormsModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-1 items-center justify-center px-4 py-16">
      <div class="w-full max-w-md">
        <div class="card p-8">
          <h1 class="font-serif text-2xl font-semibold text-ink">Create your company account</h1>
          <p class="mt-1 text-sm text-ink-soft">Two fields now — your fleet profile comes right after sign-in.</p>

          @if (error(); as e) {
            <p class="mt-4 rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger">{{ e }}</p>
          }

          <form class="mt-6 space-y-4" [formGroup]="form" (ngSubmit)="submit()">
            <div>
              <label class="label" for="email">Work email</label>
              <input id="email" type="email" class="input" formControlName="email" placeholder="fleet@yourcompany.com" />
              @if (form.controls.email.touched && form.controls.email.invalid) {
                <p class="mt-1 text-xs text-danger">A valid email is required.</p>
              }
            </div>
            <div>
              <label class="label" for="password">Password</label>
              <input id="password" type="password" class="input" formControlName="password" placeholder="Min. 6 chars, upper, lower, digit, symbol" />
              @if (form.controls.password.touched && form.controls.password.invalid) {
                <p class="mt-1 text-xs text-danger">Minimum 6 characters.</p>
              }
            </div>

            <button type="submit" class="btn-primary w-full" [disabled]="form.invalid || busy()">
              {{ busy() ? 'Creating…' : 'Create account' }}
            </button>
          </form>

          <p class="mt-5 text-center text-sm text-ink-soft">
            Already registered? <a class="link" routerLink="/auth/login/company">Sign in</a>
          </p>
        </div>
      </div>
    </div>
  `,
})
export class RegisterCompanyPage {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);
    const { email, password } = this.form.getRawValue();

    this.auth.registerCompany(email, password).subscribe({
      next: () =>
        this.router.navigate(['/auth/login/company'], { queryParams: { registered: 1 } }),
      error: (err) => {
        this.busy.set(false);
        this.error.set(responseErrorText(err));
      },
    });
  }
}
