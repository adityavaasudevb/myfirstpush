import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { NgClass } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';
import { homeForRole } from '../../../core/guards/auth.guard';

type LoginRole = 'company' | 'surveyor' | 'admin';

@Component({
  selector: 'tnc-login',
  imports: [ReactiveFormsModule, RouterLink, NgClass],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-1 items-center justify-center px-4 py-16">
      <div class="w-full max-w-md">
        <div class="card p-8">
          <h1 class="font-serif text-2xl font-semibold text-ink">{{ heading() }}</h1>
          <p class="mt-1 text-sm text-ink-soft">{{ subheading() }}</p>

          <!-- registered-success banner -->
          @if (justRegistered()) {
            <p class="mt-4 rounded-xl border border-success/30 bg-success-soft px-4 py-3 text-sm text-success">
              Account created — sign in to continue.
            </p>
          }

          <!-- inline error / status banner -->
          @if (banner(); as b) {
            <p class="mt-4 rounded-xl px-4 py-3 text-sm"
               [ngClass]="b.kind === 'error'
                 ? 'border border-danger/30 bg-danger-soft text-danger'
                 : 'border border-warning/30 bg-warning-soft text-warning'">
              {{ b.text }}
            </p>
          }

          <form class="mt-6 space-y-4" [formGroup]="form" (ngSubmit)="submit()">
            <div>
              <label class="label" for="email">Email</label>
              <input id="email" type="email" class="input" formControlName="email"
                     placeholder="you@company.com" autocomplete="email" />
            </div>
            <div>
              <label class="label" for="password">Password</label>
              <input id="password" type="password" class="input" formControlName="password"
                     placeholder="••••••••" autocomplete="current-password" />
            </div>

            <button type="submit" class="btn-primary w-full" [disabled]="form.invalid || busy()">
              {{ busy() ? 'Signing in…' : 'Sign in' }}
            </button>
          </form>

          @if (role() !== 'admin') {
            <p class="mt-5 text-center text-sm text-ink-soft">
              No account?
              <a class="link" [routerLink]="['/auth/register', role()]">Register here</a>
            </p>
          }
          <p class="mt-2 text-center text-xs">
            <a routerLink="/auth" class="text-ink-soft transition-colors hover:text-primary">← Choose a different role</a>
          </p>
        </div>
      </div>
    </div>
  `,
})
export class LoginPage {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  readonly role = signal<LoginRole>((this.route.snapshot.paramMap.get('role') as LoginRole) || 'company');
  readonly busy = signal(false);
  readonly banner = signal<{ kind: 'error' | 'info'; text: string } | null>(null);
  readonly justRegistered = signal(this.route.snapshot.queryParamMap.has('registered'));

  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });

  heading(): string {
    switch (this.role()) {
      case 'surveyor': return 'Surveyor sign in';
      case 'admin': return 'Administrator sign in';
      default: return 'Company sign in';
    }
  }
  subheading(): string {
    switch (this.role()) {
      case 'surveyor': return 'Approved IRDAI surveyors only.';
      case 'admin': return 'Internal access.';
      default: return 'Quotes, policies and claims for your fleet.';
    }
  }

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.banner.set(null);
    const { email, password } = this.form.getRawValue();

    this.auth.login(email, password).subscribe({
      next: (u) => this.router.navigateByUrl(homeForRole(u.role)),
      error: (err) => {
        this.busy.set(false);
        const text = responseErrorText(err);
        if (err?.status === 403 && text.includes('SURVEYOR_PENDING_APPROVAL')) {
          this.banner.set({
            kind: 'info',
            text: 'Your surveyor registration is awaiting admin approval. You will be able to sign in once approved.',
          });
        } else if (err?.status === 403 && text.toLowerCase().includes('reject')) {
          this.banner.set({ kind: 'error', text });
        } else if (err?.status === 401) {
          this.banner.set({ kind: 'error', text: 'Invalid email or password.' });
        } else {
          this.banner.set({ kind: 'error', text });
        }
      },
      complete: () => this.busy.set(false),
    });
  }
}
