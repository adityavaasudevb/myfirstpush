import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

// Surveyor workspace — slice C replaces this with the live claim queue,
// pickup, investigation and report screens.
@Component({
  selector: 'tnc-surveyor-queue',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="mx-auto max-w-3xl px-4 py-16">
      <div class="card p-10 text-center">
        <span class="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary-faint font-serif text-2xl text-primary">H</span>
        <h1 class="mt-6 font-serif text-3xl font-semibold text-ink">Surveyor workspace</h1>
        <p class="mt-2 text-sm text-ink-soft">
          Signed in as <span class="font-semibold text-ink">{{ auth.user()?.email }}</span>
        </p>
        <p class="mx-auto mt-4 max-w-md text-sm leading-relaxed text-ink-soft">
          Slice C brings the claim queue, field-level investigation and report submission here.
        </p>
        <div class="mt-8 flex items-center justify-center gap-3">
          <a routerLink="/" class="btn-outline">Back to landing</a>
        </div>
      </div>
    </section>
  `,
})
export class SurveyorQueuePage {
  readonly auth = inject(AuthService);
}
