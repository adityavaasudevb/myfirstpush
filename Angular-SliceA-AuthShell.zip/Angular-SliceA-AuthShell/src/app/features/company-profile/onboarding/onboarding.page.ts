import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService, responseErrorText } from '../../../core/services/auth.service';
import { CompanyProfileService } from '../services/company-profile.service';
import { AlertService } from '../../../shared/toast/toast';

// One-time fleet profile creation (FR2.2) — fresh companies land here after
// their first login because GET /api/companies/me returned 404.
@Component({
  selector: 'tnc-profile-create',
  imports: [ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-16">
      <div class="w-full max-w-lg">
        <div class="card p-8">
          <p class="text-xs font-bold uppercase tracking-[0.18em] text-accent">Step 1 of 1</p>
          <h1 class="mt-2 font-serif text-2xl font-semibold text-ink">Tell us about your fleet</h1>
          <p class="mt-1 text-sm text-ink-soft">
            This becomes your company identity on quotes, policies and claims. You can update it anytime.
          </p>

          @if (error(); as e) {
            <p class="mt-4 rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger">{{ e }}</p>
          }

          <form class="mt-6 grid gap-4 sm:grid-cols-2" [formGroup]="form" (ngSubmit)="submit()">
            <div class="sm:col-span-2">
              <label class="label" for="p-name">Company name</label>
              <input id="p-name" class="input" formControlName="name" placeholder="SwiftFleet Mobility Pvt Ltd" />
            </div>
            <div>
              <label class="label" for="p-reg">Registration number (CIN)</label>
              <input id="p-reg" class="input" formControlName="registrationNumber" placeholder="U74999TN2019PTC138821" />
            </div>
            <div>
              <label class="label" for="p-fleet">Fleet size</label>
              <input id="p-fleet" type="number" min="1" class="input" formControlName="fleetSize" placeholder="25" />
            </div>
            <div>
              <label class="label" for="p-person">Contact person</label>
              <input id="p-person" class="input" formControlName="contactPerson" placeholder="Ananya Rao" />
            </div>
            <div>
              <label class="label" for="p-phone">Phone</label>
              <input id="p-phone" class="input" formControlName="phone" placeholder="+91-98450-22110" />
            </div>
            <div class="sm:col-span-2">
              <label class="label" for="p-email">Company email</label>
              <input id="p-email" type="email" class="input" formControlName="email" />
            </div>

            <button type="submit" class="btn-primary sm:col-span-2" [disabled]="form.invalid || busy()">
              {{ busy() ? 'Saving…' : 'Create profile & enter workspace' }}
            </button>
          </form>
        </div>
      </div>
    </div>
  `,
})
export class ProfileCreatePage {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly profiles = inject(CompanyProfileService);
  private readonly alerts = inject(AlertService);
  private readonly router = inject(Router);

  readonly busy = signal(false);
  readonly error = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    registrationNumber: ['', Validators.required],
    contactPerson: ['', Validators.required],
    email: [this.auth.user()?.email ?? '', [Validators.required, Validators.email]],
    phone: ['', Validators.required],
    fleetSize: [1, [Validators.required, Validators.min(1)]],
  });

  submit(): void {
    if (this.form.invalid || this.busy()) return;
    this.busy.set(true);
    this.error.set(null);

    this.profiles.create(this.form.getRawValue()).subscribe({
      next: () => {
        this.alerts.success('Fleet profile created — welcome aboard.');
        this.router.navigateByUrl('/company');
      },
      error: (err) => {
        this.busy.set(false);
        this.error.set(responseErrorText(err));
      },
    });
  }
}
