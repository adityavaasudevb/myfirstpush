import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';

// P0 — Landing: what the team's home page links into.
// Content = design doc §3 pricing, in plain insurance language.
@Component({
  selector: 'tnc-landing',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div>
      <!-- hero -->
      <section class="mx-auto max-w-6xl px-4 py-16 sm:py-24">
        <div class="grid items-center gap-10 sm:grid-cols-2">
          <div>
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-accent">For ride-share fleets</p>
            <h1 class="mt-4 font-serif text-4xl font-semibold leading-tight tracking-tight text-ink sm:text-5xl">
              Insurance that moves<br />at the speed of your fleet.
            </h1>
            <p class="mt-5 max-w-md text-base leading-relaxed text-ink-soft">
              Quote in seconds, apply in minutes, and let verified trip-event evidence drive fair
              claim decisions — all in one transparent workspace.
            </p>
            <div class="mt-8 flex flex-wrap gap-3">
              <a routerLink="/auth" class="btn-primary !px-6 !py-3">Start a quote</a>
              <a href="#pricing" class="btn-outline">See tiers &amp; add-ons</a>
            </div>
          </div>

          <!-- heritage mark: serif H in a ring of twelve dots -->
          <div class="hidden justify-center sm:flex">
            <svg viewBox="0 0 200 200" class="h-64 w-64 text-primary" aria-hidden="true">
              @for (d of dots; track $index) {
                <circle [attr.cx]="d[0]" [attr.cy]="d[1]" r="4.5" fill="currentColor" opacity="0.35" />
              }
              <circle cx="100" cy="100" r="58" fill="currentColor" />
              <text x="100" y="122" text-anchor="middle" font-size="72" fill="#f9f7f5"
                    font-family="Georgia, 'Times New Roman', serif" font-weight="700">H</text>
            </svg>
          </div>
        </div>
      </section>

      <!-- tiers -->
      <section id="pricing" class="border-y border-warm bg-white">
        <div class="mx-auto max-w-6xl px-4 py-16">
          <h2 class="font-serif text-3xl font-semibold text-ink">Two tiers. Priced per vehicle.</h2>
          <p class="mt-2 text-sm text-ink-soft">Base premium starts at <span class="font-semibold text-ink">₹15,000 per vehicle per year</span>, scaled by tier and add-ons.</p>

          <div class="mt-8 grid gap-6 sm:grid-cols-2">
            <div class="card p-8">
              <p class="text-xs font-bold uppercase tracking-[0.18em] text-ink-soft">Tier A</p>
              <h3 class="mt-2 font-serif text-2xl font-semibold text-ink">Essential</h3>
              <p class="mt-1 text-sm text-ink-soft">App online, before a ride is accepted.</p>
              <ul class="mt-5 space-y-2 text-sm text-ink">
                <li class="flex gap-2"><span class="text-primary">✓</span>Covers <b>Period 1</b> — online, waiting for requests</li>
                <li class="flex gap-2"><span class="text-primary">✓</span>Up to <b>₹25,00,000</b> per claim</li>
                <li class="flex gap-2"><span class="text-primary">✓</span>Third-party &amp; own-damage core cover</li>
              </ul>
            </div>
            <div class="card relative overflow-hidden p-8">
              <span class="absolute right-0 top-0 rounded-bl-xl bg-accent px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-white">Most chosen</span>
              <p class="text-xs font-bold uppercase tracking-[0.18em] text-primary">Tier B</p>
              <h3 class="mt-2 font-serif text-2xl font-semibold text-ink">Complete</h3>
              <p class="mt-1 text-sm text-ink-soft">End-to-end cover across every active period.</p>
              <ul class="mt-5 space-y-2 text-sm text-ink">
                <li class="flex gap-2"><span class="text-primary">✓</span>Covers <b>Periods 1–3</b> — online, en route, with passenger</li>
                <li class="flex gap-2"><span class="text-primary">✓</span>Up to <b>₹1,00,00,000</b> per claim</li>
                <li class="flex gap-2"><span class="text-primary">✓</span>Premium scales with add-ons (up to ~<b>1.6×</b>)</li>
              </ul>
            </div>
          </div>

          <!-- add-ons -->
          <h3 class="mt-12 font-serif text-2xl font-semibold text-ink">Add-ons that shape your premium</h3>
          <div class="mt-5 grid gap-4 sm:grid-cols-4">
            @for (a of addons; track a.name) {
              <div class="card p-5">
                <p class="font-serif text-xl font-semibold text-primary">{{ a.pct }}</p>
                <p class="mt-1 text-sm font-semibold text-ink">{{ a.name }}</p>
                <p class="mt-1 text-xs leading-relaxed text-ink-soft">{{ a.blurb }}</p>
              </div>
            }
          </div>
        </div>
      </section>

      <!-- how it works -->
      <section class="mx-auto max-w-6xl px-4 py-16">
        <h2 class="font-serif text-3xl font-semibold text-ink">From quote to payout, four clean steps.</h2>
        <div class="mt-8 grid gap-6 sm:grid-cols-4">
          @for (s of steps; track s.n) {
            <div class="relative pl-10">
              <span class="absolute left-0 top-0 grid h-7 w-7 place-items-center rounded-full bg-primary font-serif text-sm font-semibold text-white">{{ s.n }}</span>
              <p class="text-sm font-semibold text-ink">{{ s.title }}</p>
              <p class="mt-1 text-xs leading-relaxed text-ink-soft">{{ s.blurb }}</p>
            </div>
          }
        </div>
        <div class="mt-12 card flex flex-col items-center gap-4 bg-primary p-8 text-center sm:flex-row sm:text-left">
          <p class="flex-1 font-serif text-xl text-white">Ready to see your fleet's number?</p>
          <a routerLink="/auth" class="btn-outline !border-white !bg-white !text-primary">Get your quote →</a>
        </div>
      </section>
    </div>
  `,
})
export class LandingPage {
  // twelve dots on a circle (r=84, centre 100,100) — The Hartford heritage mark homage
  readonly dots = Array.from({ length: 12 }, (_, i) => {
    const angle = (i * 30 * Math.PI) / 180 - Math.PI / 2;
    return [100 + 84 * Math.cos(angle), 100 + 84 * Math.sin(angle)];
  });

  readonly addons = [
    { name: 'Physical Damage', pct: '+12%', blurb: 'Own-vehicle repair costs across covered periods.' },
    { name: 'Uninsured Motorist', pct: '+5%', blurb: 'Protects against third parties without cover.' },
    { name: 'Rental Car', pct: '+3%', blurb: 'Replacement mobility while a vehicle is down.' },
    { name: 'Medical Payments', pct: '+2%', blurb: 'Rider and driver medical expense cover.' },
  ];

  readonly steps = [
    { n: 1, title: 'Quote', blurb: 'Enter fleet size, tier & add-ons — instant premium in INR, USD & EUR.' },
    { n: 2, title: 'Apply', blurb: 'One clean application from any active quote, 7-day validity respected.' },
    { n: 3, title: 'Pay', blurb: 'Simulated payment activates the policy for a full year.' },
    { n: 4, title: 'Claim', blurb: 'Trip-event evidence drives an instant preliminary decision, then expert review.' },
  ];
}
