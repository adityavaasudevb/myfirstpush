import { Routes } from '@angular/router';
import { PublicLayoutComponent } from './shared/layouts/public-layout/public-layout.component';
import { AppLayoutComponent } from './shared/layouts/app-layout/app-layout.component';
import { LandingPage } from './features/landing/landing.page';
import { RoleCardsPage } from './features/auth/role-cards/role-cards.page';
import { LoginPage } from './features/auth/login/login.page';
import { RegisterCompanyPage } from './features/auth/register-company/register-company.page';
import { RegisterSurveyorPage } from './features/auth/register-surveyor/register-surveyor.page';
import { OnboardingPage } from './features/company-profile/onboarding/onboarding.page';
import { CompanyDashboardPage } from './features/dashboard/company-dashboard/company-dashboard.page';
import { SurveyorQueuePage } from './features/claims/surveyor-queue/surveyor-queue.page';
import { AdminDashboardPage } from './features/dashboard/admin-dashboard/admin-dashboard.page';
import { guestGuard, roleGuard } from './core/guards/auth.guard';
import { companyProfileGuard, onboardingGuard } from './features/company-profile/company-profile.guard';

export const routes: Routes = [
  // ---- Public chrome ----
  {
    path: '',
    component: PublicLayoutComponent,
    children: [
      { path: '', component: LandingPage },
      { path: 'auth', component: RoleCardsPage, canActivate: [guestGuard] },
      { path: 'auth/login/:role', component: LoginPage, canActivate: [guestGuard] },
      { path: 'auth/register/company', component: RegisterCompanyPage, canActivate: [guestGuard] },
      { path: 'auth/register/surveyor', component: RegisterSurveyorPage, canActivate: [guestGuard] },
    ],
  },

  // ---- Authenticated chrome ----
  {
    path: '',
    component: AppLayoutComponent,
    children: [
      {
        path: 'company',
        canActivate: [roleGuard(['Company'])],
        children: [
          { path: '', component: CompanyDashboardPage, canActivate: [companyProfileGuard] },
          { path: 'onboarding', component: OnboardingPage, canActivate: [onboardingGuard] },
        ],
      },
      { path: 'surveyor', component: SurveyorQueuePage, canActivate: [roleGuard(['Surveyor'])] },
      { path: 'admin', component: AdminDashboardPage, canActivate: [roleGuard(['Admin'])] },
    ],
  },

  { path: '**', redirectTo: '' },
];
