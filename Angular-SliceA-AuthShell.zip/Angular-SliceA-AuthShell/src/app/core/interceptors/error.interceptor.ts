import { inject } from '@angular/core';
import { HttpInterceptorFn, HttpContextToken } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { AlertService } from '../../shared/toast/toast';
import { ApiError } from '../models/api-error.model';

/** Set SKIP_ERROR_TOAST on a request's context to handle errors locally
 *  (e.g. forms that draw their own inline banners). */
export const SKIP_ERROR_TOAST = new HttpContextToken<boolean>(() => false);

/** Global error surfacing: 5xx and network failures become toasts with the
 *  correlation ID for support. 401/403 are flow concerns (login banners,
 *  interceptor refresh) and are never toasted; 4xx business errors default
 *  to local handling in forms — the toast is skipped unless a page doesn't
 *  opt out (interceptor chain order: auth runs first, error last). */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const alerts = inject(AlertService);
  return next(req).pipe(
    catchError((err: { status?: number; error?: ApiError; statusText?: string }) => {
      const status = err?.status ?? 0;
      if (req.context.get(SKIP_ERROR_TOAST)) return throwError(() => err);
      if (status === 401 || status === 403) return throwError(() => err);
      if (status === 0 || status >= 500) {
        const ref = err?.error?.correlationId ? ` (ref: ${err.error.correlationId})` : '';
        alerts.error(`Something went wrong on our side — please retry.${ref}`);
      }
      return throwError(() => err);
    }),
  );
};
