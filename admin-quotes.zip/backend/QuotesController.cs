// PATH ON YOUR MACHINE: src/Services/Quote/QuoteService.API/Controllers/QuotesController.cs
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using QuoteService.Application.Dtos;
using QuoteService.Application.Interfaces;

namespace QuoteService.API.Controllers;

/// <summary>Section 6.3 — five endpoints, no more, no fewer.</summary>
[ApiController]
[Route("api/quotes")]
[Authorize]
public class QuotesController : ControllerBase
{
    private readonly IQuoteService _quotes;
    public QuotesController(IQuoteService quotes) => _quotes = quotes;

    // AuthService mints standard "sub"/"role" claims; inbound claim mapping is disabled,
    // so ClaimTypes.NameIdentifier does NOT work — read "sub" directly (FR1.2).
    private string CallerId => User.FindFirstValue("sub")!;

    /// <summary>FR3.1/FR3.2 — create a persisted quote; response = requested tier + alternate-tier estimate + USD/EUR (FR3.6).</summary>
    [HttpPost]
    [Authorize(Roles = "Company")]
    public async Task<IActionResult> Create([FromBody] CreateQuoteRequest request, CancellationToken ct)
        => StatusCode(StatusCodes.Status201Created, await _quotes.CreateAsync(CallerId, request, ct));

    // NOTE: the two literal routes ("company", "stats") sit next to "{id:guid}" on purpose —
    // attribute routing resolves literals before parameters, so order in the file does not matter,
    // but keeping them adjacent makes the intent obvious.

    /// <summary>FR3.3 — single quote; status flips to Expired lazily on read; 403 if it isn't yours.</summary>
    [HttpGet("{id:guid}")]
    [Authorize(Roles = "Company")]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
        => Ok(await _quotes.GetByIdAsync(id, CallerId, ct));

    /// <summary>
    /// FR3.5 + FR9.4 — own quote history with status + created-date filters, shared-trimmed paging.
    /// v3.4 — an Admin calling this route gets EVERY company's quotes, because the admin
    /// explorer needs the same filters over the whole book; a Company always gets its own.
    /// The branch is here and nowhere else: the service takes a null owner to mean "all",
    /// and only this action can produce a null.
    /// </summary>
    [HttpGet("company")]
    [Authorize(Roles = "Company,Admin")]
    public async Task<IActionResult> History(
        [FromQuery] string? status,
        [FromQuery] DateTimeOffset? from,
        [FromQuery] DateTimeOffset? to,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 10,
        CancellationToken ct = default)
        => Ok(await _quotes.GetHistoryAsync(
            User.IsInRole("Admin") ? null : CallerId, status, from, to, page, pageSize, ct));

    /// <summary>
    /// v3.4 — the admin quote explorer: every company's quotes, unfiltered by owner.
    /// Separate route so /api/quotes/company keeps meaning "mine" for a Company token,
    /// even if the roles are ever widened by accident.
    /// </summary>
    [HttpGet("all")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> All(
        [FromQuery] string? status,
        [FromQuery] DateTimeOffset? from,
        [FromQuery] DateTimeOffset? to,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 10,
        CancellationToken ct = default)
        => Ok(await _quotes.GetAllAsync(status, from, to, page, pageSize, ct));

    /// <summary>
    /// FR3.4 — INTER-SERVICE ENDPOINT. Called by InsuranceService (never the Angular app)
    /// with the company's forwarded JWT at policy-apply time, per Section 4. The
    /// Roles = "Company" check still works because the forwarded token carries it.
    /// 404 missing / 403 not yours / 410 expired / 409 already converted.
    /// </summary>
    [HttpPost("{id:guid}/convert")]
    [Authorize(Roles = "Company")]
    public async Task<IActionResult> Convert(Guid id, CancellationToken ct)
        => Ok(await _quotes.ConvertAsync(id, CallerId, ct));

    /// <summary>FR7.1 — dashboard aggregation feed; InsuranceService calls it with the Admin's forwarded JWT.</summary>
    [HttpGet("stats")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Stats(CancellationToken ct)
        => Ok(await _quotes.GetStatsAsync(ct));
}
