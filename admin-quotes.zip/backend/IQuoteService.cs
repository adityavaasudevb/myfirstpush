// PATH ON YOUR MACHINE: src/Services/Quote/QuoteService.Application/Interfaces/IQuoteService.cs
// Both application service contracts + the FX rates record in one file (house rule).
using QuoteService.Application.Dtos;
using TNCInsurance.Shared.Models;

namespace QuoteService.Application.Interfaces;

public interface IQuoteService
{
    Task<CreateQuoteResponse> CreateAsync(string ownerUserId, CreateQuoteRequest request, CancellationToken ct = default);
    Task<QuoteDto> GetByIdAsync(Guid id, string callerUserId, CancellationToken ct = default);
    /// <summary>
    /// FR3.5/FR9.4 — quote history. <paramref name="ownerUserId"/> null means "every
    /// company" and is Admin-only; the controller decides, this method just obeys.
    /// </summary>
    Task<PagedResult<QuoteDto>> GetHistoryAsync(string? ownerUserId, string? status,
        DateTimeOffset? createdFrom, DateTimeOffset? createdTo, int page, int pageSize, CancellationToken ct = default);

    /// <summary>v3.4 — the admin explorer: all quotes from all companies, same filters.</summary>
    Task<PagedResult<QuoteDto>> GetAllAsync(string? status,
        DateTimeOffset? createdFrom, DateTimeOffset? createdTo, int page, int pageSize, CancellationToken ct = default);
    Task<QuoteConvertDto> ConvertAsync(Guid id, string callerUserId, CancellationToken ct = default);
    Task<QuoteStatsDto> GetStatsAsync(CancellationToken ct = default);
}

/// <summary>USD-based exchange rates from open.er-api.com (FR3.6), with a cached/configurable fallback flag.</summary>
public record FxRates(decimal InrPerUsd, decimal EurPerUsd, bool UsedFallback);

public interface IFxRateService
{
    Task<FxRates> GetRatesAsync(CancellationToken ct = default);
}
