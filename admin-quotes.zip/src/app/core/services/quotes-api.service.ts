import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Quote } from '../models/quote.model';
import { Paged, unwrapPaged } from '../models/paged';

const API = environment.apiBaseUrl;

/** Server page size for the admin quote explorer (change in one place). */
export const PAGE_SIZE = 25;

/**
 * Admin-side quote reads (v3.4). The company-side QuoteService is a separate
 * client on purpose: this one only ever calls the admin routes, so a mistake
 * here cannot ask for the wrong company's book.
 *
 * GET /api/quotes/all — Admin only, every company's quotes.
 * Ownership is decided server-side; the client never sends an owner id.
 */
@Injectable({ providedIn: 'root' })
export class QuotesApiService {
  private readonly http = inject(HttpClient);

  /** Admin explorer: all quotes, status + created-date filters, newest first.
   *  Pass pageSize 1 for cheap per-chip count reads. */
  adminList(filter?: {
    status?: string;
    from?: string;
    to?: string;
    page?: number;
    pageSize?: number;
  }): Observable<Paged<Quote>> {
    let params = new HttpParams()
      .set('page', filter?.page ?? 1)
      .set('pageSize', filter?.pageSize ?? PAGE_SIZE);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.from) params = params.set('from', filter.from);
    if (filter?.to) params = params.set('to', filter.to);
    return this.http
      .get<unknown>(`${API}/quotes/all`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizeQuote)));
  }
}

// ---------------------------------------------------------------- normalise
// Same defensive mapping the company quote service uses: the backend's DTO is
// authoritative, but this tolerates the older field names so the template
// never has to care which shape it received.
type Raw = Record<string, any>;

function num(...cands: unknown[]): number {
  for (const c of cands) if (typeof c === 'number') return c;
  return 0;
}
function str(...cands: unknown[]): string {
  for (const c of cands) if (typeof c === 'string' && c.length) return c;
  return '';
}

function normalizeQuote(q: Raw): Quote {
  return {
    id: str(q.id),
    quoteNumber: str(q.quoteNumber),
    fleetSize: num(q.fleetSize),
    tier: str(q.tier),
    addOns: Array.isArray(q.addOns)
      ? (q.addOns as string[])
      : typeof q.addOns === 'string' && q.addOns.length
        ? (q.addOns as string).split(',').map((s) => s.trim())
        : [],
    premiumInr: num(q.premiumInr, q.estimatedPremiumInr, q.premium, q.totalPremiumInr),
    estimatedPremiumUsd: num(q.estimatedPremiumUsd, q.premiumUsd),
    estimatedPremiumEur: num(q.estimatedPremiumEur, q.premiumEur),
    usedFallbackRate: Boolean(q.usedFallbackRate),
    status: str(q.status, q.effectiveStatus),
    createdAtUtc: str(q.createdAtUtc, q.createdUtc, q.createdAt, q.createdOn, q.createdDate),
    expiresAtUtc: str(q.expiresAtUtc, q.expiresUtc, q.expiresAt, q.expiryDate, q.expiryDateUtc),
  };
}
