import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AdminQuotes } from './admin-quotes';

describe('AdminQuotes', () => {
  let component: AdminQuotes;
  let fixture: ComponentFixture<AdminQuotes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminQuotes],
      providers: [provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();

    fixture = TestBed.createComponent(AdminQuotes);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('shows a dash, not zero, before any count lands', () => {
    expect(component.counts()['All']).toBeUndefined();
  });
});
