import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuotesApiService } from '../../../core/services/quotes-api.service';
import { Quote } from '../../../core/models/quote.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

const STATUS_FILTERS = [
  { key: 'All', label: 'All' },
  { key: 'Active', label: 'Active' },
  { key: 'Converted', label: 'Converted' },
  { key: 'Expired', label: 'Expired' },
];

/**
 * v3.4 — admin quote explorer.
 *
 * Reads GET /api/quotes/all. This screen exists because the admin previously
 * had no way to see the quote book at all: the only quote route was
 * /api/quotes/company, which is scoped to the caller's own company, so an
 * Admin got an empty list and had to infer demand from the conversion metric.
 *
 * Read-only by design. A quote is the company's intent, not the platform's
 * decision — nothing here converts, expires or deletes one.
 *
 * NOTE ON "COMPANY WISE": the Quote table stores OwnerUserId, not the company
 * name (that lives in CustomerService, one service away). Rather than call
 * CustomerService once per row — an N+1 across a service boundary — this
 * screen groups by owner id, which is the honest identifier the quote
 * actually carries. Widening it to a name needs CompanyName snapshotted onto
 * the quote at creation (the same trick D4 proposes for policies).
 */
@Component({
  selector: 'app-admin-quotes',
  imports: [CommonModule, MoneyPipe],
  templateUrl: './admin-quotes.html',
  styleUrl: './admin-quotes.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminQuotes {
  private readonly quotesApi = inject(QuotesApiService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<Quote> | null>(null);

  readonly statusFilter = signal('All');
  readonly from = signal('');
  readonly to = signal('');
  readonly sortOrder = signal<'asc' | 'desc'>('desc');
  readonly page = signal(1);

  /** Server-side counts per status chip (one pageSize=1 read each). */
  readonly counts = signal<Record<string, number | null>>({});

  readonly filters = STATUS_FILTERS;

  constructor() {
    this.reload();
    this.refreshCounts();
  }

  private refreshCounts(): void {
    for (const f of this.filters) {
      this.quotesApi
        .adminList({
          page: 1,
          pageSize: 1,
          status: f.key === 'All' ? undefined : f.key,
          from: this.from() || undefined,
          to: this.to() || undefined,
        })
        .subscribe({
          next: (pg) => this.counts.update((c) => ({ ...c, [f.key]: pg.total })),
          error: () => undefined, // a chip count is a convenience; a dash is fine
        });
    }
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.quotesApi
      .adminList({
        page: this.page(),
        status: this.statusFilter() === 'All' ? undefined : this.statusFilter(),
        from: this.from() || undefined,
        to: this.to() || undefined,
      })
      .subscribe({
        next: (pg) => {
          this.paged.set(pg);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }

  setStatus(f: string): void {
    if (this.statusFilter() === f) return;
    this.statusFilter.set(f);
    this.page.set(1);
    this.reload();
  }

  setFrom(v: string): void {
    this.from.set(v);
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  setTo(v: string): void {
    this.to.set(v);
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  clearDates(): void {
    this.from.set('');
    this.to.set('');
    this.page.set(1);
    this.reload();
    this.refreshCounts();
  }

  setSort(s: 'asc' | 'desc'): void {
    this.sortOrder.set(s);
    // Sorting is client-side over the current page: the admin route does not
    // take a sortOrder parameter, and adding one is a backend change we do
    // not need for a read-only explorer. The page itself is newest-first.
    const pg = this.paged();
    if (!pg) return;
    const items = [...pg.items].sort((a, b) => {
      const av = a.createdAtUtc, bv = b.createdAtUtc;
      return s === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    this.paged.set({ ...pg, items });
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    const total = this.totalPages();
    // Keep the pager readable: at most 7 buttons around the current page.
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const start = Math.max(1, Math.min(this.page() - 3, total - 6));
    return Array.from({ length: 7 }, (_, i) => start + i);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Converted':
        return 'bg-blue-100 text-blue-800';
      case 'Expired':
        return 'bg-warm-light text-ink-soft';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  addOnText(q: Quote): string {
    return q.addOns.length ? q.addOns.join(', ') : 'None';
  }

  /** Short, greppable owner handle. See the header note on why this is an id. */
  ownerShort(q: Quote): string {
    const s = q.ownerUserId ?? '';
    return s ? s.slice(0, 8) : '—';
  }

  fmt(iso: string): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
