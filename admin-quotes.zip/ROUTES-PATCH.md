# Wiring the admin quotes page — 3 lines

## 1. `src/app/app.routes.ts`

Add the import beside the other admin imports:

```ts
import { AdminQuotes } from './features/quotes/admin-quotes/admin-quotes';
```

Then, inside the authenticated `AppLayout` children, next to the existing
`admin` route:

```ts
      { path: 'admin', component: AdminDashboard, canActivate: [roleGuard(['Admin'])] },
      { path: 'admin/quotes', component: AdminQuotes, canActivate: [roleGuard(['Admin'])] },   // NEW
```

## 2. Nav bar

In `app-layout.html` (or wherever the admin links live), beside
"Policy explorer" / "Claims explorer":

```html
<a routerLink="/admin/quotes" routerLinkActive="text-primary" class="...">Quotes</a>
```

Match the class list of the neighbouring links — do not invent a new one.

## 3. Gateway

**No change.** `/api/quotes/{**rest}` already forwards `/api/quotes/all` to
QuoteService on :5003. Nothing to add to `appsettings.json`.
