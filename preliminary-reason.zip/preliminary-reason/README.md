# Preliminary reason — what changed, where, and how to apply it

## What the gap actually was

`ClaimRulesEngine.Evaluate()` **already returned the reason**:

```csharp
return new RuleEngineResult(PreliminaryDecisions.Reject, "App not in use", null);
```

`ClaimService` threw it away. It read `.Decision` and `.PreliminaryAmountInr` off the result and
never touched `.Reason`, then said so in a comment:

> The preliminary reject reason is deterministic from derivedPeriod+tier and intentionally not
> persisted (Section 5 lists no such column).

So the UI showed **Approve** / **Reject** and nothing else. That is the bug.

## The fix — re-run the function, don't re-implement it

`ReasonFrom(...)` calls `ClaimRulesEngine.Evaluate` again with the claim's stored period and type
and the parent policy's tier/add-ons, and returns `result.Reason`. It does **not** contain a second
copy of the precedence rules — if rule #3 changes, this changes with it, because it *is* rule #3.

Rule #5 (Approve) returns no reason by design, so one sentence is composed from the amount the
engine already computed. Still the engine's number.

**No column, no migration, no backfill.** The claim table stores the four inputs; the sentence is a
pure function of them, so it can never drift from the decision it explains.

## The engine file — the thing that was missing from FINAL

`InsuranceService.Domain/Services/ClaimRulesEngine.cs` was never in `02-backend`, because it was
not part of the v3.4 diff. It lives here:

```
source/packs/InsuranceService/InsuranceService.Domain/Services/ClaimRulesEngine.cs
source/packs/InsuranceService/InsuranceService.Domain/Services/CoveragePeriodDeriver.cs
```

Both have now been copied into `FINAL/02-backend/InsuranceService.Domain/Services/`.

⚠ **If your solution already has `ClaimRulesEngine.cs`, do not copy the file over yours.** Compare
`RuleEngineResult` first: it must expose `string? Reason`. The shipped engine does. If yours only
returns `(Decision, Amount)`, add `Reason` to the record and pass it at each of the four returns —
that is the one-line change the whole feature depends on.

⚠ **`ClaimTypes` vs `InsuranceClaimTypes`.** The pack's engine uses `ClaimTypes.RequiredAddOn`;
`FINAL/02-backend/.../Constants/InsuranceConstants.cs` declares it as `InsuranceClaimTypes`. One of
those names is wrong on your machine. If the build says *"The name 'ClaimTypes' does not exist"*,
rename the reference in `ClaimRulesEngine.cs` to `InsuranceClaimTypes`. If it says
*"The name 'InsuranceClaimTypes' does not exist"* in `ClaimService.cs`, it is the reverse. It is a
rename, not a logic change.

## The 7 files — exact workspace paths

Copy each one over the same relative path in your solution. All are under
`/home/user/FINAL/` on the workspace.

| # | Workspace file | Lands at (in your solution) |
|---|---|---|
| 1 | `FINAL/02-backend/InsuranceService.Infrastructure/Services/ClaimService.cs` | `src/Services/Insurance/InsuranceService.Infrastructure/Services/ClaimService.cs` |
| 2 | `FINAL/02-backend/InsuranceService.Application/Dtos/ClaimDtos.cs` | `src/Services/Insurance/InsuranceService.Application/Dtos/ClaimDtos.cs` |
| 3 | `FINAL/03-frontend/core/models/claim.model.ts` | `src/app/core/models/claim.model.ts` |
| 4 | `FINAL/03-frontend/features/claims/file-claim/file-claim.html` | `src/app/features/claims/file-claim/file-claim.html` |
| 5 | `FINAL/03-frontend/features/claims/investigate-claim/investigate-claim.html` | `src/app/features/claims/investigate-claim/investigate-claim.html` |
| 6 | `FINAL/03-frontend/features/claims/claim-review/claim-review.html` | `src/app/features/claims/claim-review/claim-review.html` |
| 7 | `FINAL/03-frontend/features/claims/claim-details/claim-details.html` | `src/app/features/claims/claim-details/claim-details.html` |

Files 1 and 2 are backend; 3–7 are frontend. Nothing else changes: no SQL, no `appsettings`, no
route, no gateway rule, no migration.

## What each branch now shows

| Branch | Sentence |
|---|---|
| App Off | `App not in use` |
| Period 2/3 on Tier A | `Period not covered` |
| Missing add-on | `Coverage not purchased` |
| Approve, capped | "Approved at the period limit — the claim asks for 8,00,000, the limit allows 1,00,000." |
| Approve, full | "Approved — the derived period is covered, the add-on is on the policy, and the amount is inside the limit." |
| Policy not loadable | `null` → renders as nothing, never a guess |

The three reject reasons are the engine's own strings, character for character. That matters: it
means the sentence on screen is the same one the design document specifies, not a rephrasing.

## Verify in four clicks

1. File a claim against a Tier A policy with a Period 2 incident → confirmation card shows
   **Reject · Period not covered**.
2. Open that claim as the company → details card shows the same sentence.
3. Pick it up as a surveyor → investigate screen shows it under the first-assessment chips.
4. Submit a report and open review as admin → the sentence sits under "Preliminary decision".

Seed claims already in the database will show it too, because it is derived on read from data that
was always stored.

## Not changed by this

The decision itself, the list/queue endpoints, the claim state machine, the evidence lock, the AI
audit. This is a read-side feature.
