// PATH ON YOUR MACHINE: src/Services/Insurance/InsuranceService.Application/Dtos/ClaimDtos.cs
namespace InsuranceService.Application.Dtos;

// ---- intake ----

/// <summary>One event of the trip log submitted with the claim (FR5.2).</summary>
public record TripEventInput(string EventType, DateTimeOffset OccurredAtUtc);

/// <summary>
/// FR5.1/FR5.2 — body of POST /api/claims. When AppNotInUseDeclared is true the
/// event validation does not run and the claim classifies as App Off (FR5.2);
/// any TripEvents supplied are then ignored and not persisted.
/// v3.2: PassengerCount/AdditionalPassengersNotes are OPTIONAL multi-passenger
/// data (payout is period-and-limit based, independent of headcount).
/// </summary>
public record CreateClaimRequest(
    Guid PolicyId,
    string DriverName,
    string DriverLicenceNumber,
    string VehicleNumber,
    string PassengerName,
    string PassengerContact,
    int? PassengerCount,
    string? AdditionalPassengersNotes,
    DateTimeOffset IncidentAtUtc,
    string IncidentLocation,
    string Description,
    decimal ClaimedAmountInr,
    string ClaimType,
    string? DocumentLink,          // v3.4 — legacy; evidence now arrives as uploaded files
    bool AppNotInUseDeclared,
    List<TripEventInput>? TripEvents);

/// <summary>Section 6.4 — intake response: claim number + preliminary period, decision, amount, and flags.</summary>
public record CreateClaimResponse(
    Guid ClaimId,
    string ClaimNumber,
    string Status,                        // AwaitingSurveyorPickup
    string DerivedPeriod,
    string PreliminaryDecision,
    decimal? PreliminaryAmountInr,
    bool IsFlagged,
    string? FlagReason,
    // v3.4 close-out — why the engine decided what it decided. Derived, never stored (see ClaimService).
    string? PreliminaryReason = null);

// ---- lists ----

/// <summary>Company and admin claims lists (FR9.2/FR9.4); items are projections — no child collections.</summary>
public record ClaimListItemDto(
    Guid Id,
    string ClaimNumber,
    string VehicleNumber,
    string ClaimType,
    DateTimeOffset IncidentAtUtc,
    decimal ClaimedAmountInr,
    string Status,
    bool IsFlagged,
    decimal? FinalPayoutAmountInr);

/// <summary>Surveyor queue / assigned list (FR9.3) — enough context to decide what to pick up.</summary>
public record ClaimQueueItemDto(
    Guid Id,
    string ClaimNumber,
    string VehicleNumber,
    string ClaimType,
    decimal ClaimedAmountInr,
    DateTimeOffset IncidentAtUtc,
    string IncidentLocation,
    string DerivedPeriod,
    string PreliminaryDecision,
    bool IsFlagged,
    string? FlagReason,
    string Status,
    DateTimeOffset CreatedAtUtc);

// ---- detail & children ----

public record TripEventDto(Guid Id, string EventType, DateTimeOffset OccurredAtUtc);

public record FieldVerificationDto(Guid Id, string FieldName, string Status, string? Note);

public record SurveyorReportDto(
    Guid Id,
    string OverallOutcome,
    string Recommendation,
    decimal? RecommendedAmountInr,
    string Notes,
    DateTimeOffset SubmittedAtUtc);

/// <summary>FR5.17 — one row of the status history shown on the claim detail.</summary>
public record ClaimStatusHistoryItemDto(string? FromStatus, string ToStatus, DateTimeOffset ChangedAtUtc, string? ChangedByUserId);

/// <summary>FR5.17 — full claim: intake data, preliminary outcome, children, per-field notes, report, status history.</summary>
public record ClaimDetailsDto(
    Guid Id,
    string ClaimNumber,
    Guid PolicyId,
    string PolicyNumber,
    string DriverName,
    string DriverLicenceNumber,
    string VehicleNumber,
    string PassengerName,
    string PassengerContact,
    int? PassengerCount,
    string? AdditionalPassengersNotes,
    DateTimeOffset IncidentAtUtc,
    string IncidentLocation,
    string Description,
    decimal ClaimedAmountInr,
    string ClaimType,
    string DocumentLink,
    bool AppNotInUseDeclared,
    string DerivedPeriod,
    string PreliminaryDecision,
    decimal? PreliminaryAmountInr,
    bool IsFlagged,
    string? FlagReason,
    string Status,
    string? AssignedSurveyorId,
    decimal? FinalPayoutAmountInr,
    DateTimeOffset CreatedAtUtc,
    IReadOnlyList<TripEventDto> TripEvents,
    IReadOnlyList<FieldVerificationDto> FieldVerifications,
    SurveyorReportDto? Report,
    IReadOnlyList<ClaimStatusHistoryItemDto> StatusHistory,
    // v3.4 — set on first pickup, never cleared. Drives the company's edit gate and the
    // "evidence locked" notice; null means the company can still change the files.
    DateTimeOffset? EvidenceLockedAtUtc = null,
    // v3.4 close-out — the sentence behind PreliminaryDecision. Derived at read time from the stored
    // tier / period / claim type / add-ons, so no column and no migration. Null on claims
    // filed before this change where the parent policy is no longer loadable.
    string? PreliminaryReason = null);

// ---- surveyor actions ----

/// <summary>FR5.10 — body of POST verify-field. Status must be Verified or Suspicious (never back to Pending).</summary>
public record VerifyFieldRequest(string FieldName, string Status, string? Note);

/// <summary>FR5.13 — body of POST report. Blocked (409) while any field is Pending; one report per claim. Amount required for Approve recommendations.</summary>
public record SubmitReportRequest(string OverallOutcome, string Recommendation, decimal? RecommendedAmountInr, string Notes);

// ---- admin review & decision ----

/// <summary>FR5.14 / Section 6.4 — preliminary determination + the surveyor's full report, side by side.</summary>
public record ClaimReviewDto(
    Guid ClaimId,
    string ClaimNumber,
    string VehicleNumber,
    string ClaimType,
    decimal ClaimedAmountInr,
    string DerivedPeriod,
    string PreliminaryDecision,
    decimal? PreliminaryAmountInr,
    bool IsFlagged,
    string? FlagReason,
    int? PassengerCount,
    string? AdditionalPassengersNotes,
    IReadOnlyList<FieldVerificationDto> FieldVerifications,
    SurveyorReportDto Report,
    // v3.4 close-out — derived, never stored. Shown on the admin review beside the decision.
    string? PreliminaryReason = null);

/// <summary>FR5.15 — body of POST decision. OverrideNote is mandatory when Decision differs from the surveyor's recommendation (ValidationException 400).</summary>
public record ClaimDecisionRequest(string Decision, decimal? FinalAmountInr, string? OverrideNote);

/// <summary>FR6.1 — on Approve the payout is simulated in the same request: claim becomes Paid with the final amount.</summary>
public record ClaimDecisionResponse(Guid ClaimId, string ClaimNumber, string Status, decimal? FinalPayoutAmountInr);
