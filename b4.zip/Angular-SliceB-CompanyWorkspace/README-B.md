# Slice B — Company Workspace · B2/B3 fixes + B4 (My Policies · Policy details)

Everything already shaped to the real DTOs you pasted (PolicyDtos.cs + controller +
pay behavior confirmed). This zip is CUMULATIVE — it contains the fixed B1–B3 too.

## 1 · Generate
```
ng g c features/policies/my-policies
ng g c features/policies/policy-details
```
Replace the two CLI spec files with the zip versions (router+http providers).
New shared model: `core/models/paged.ts` (Paged<T> + unwrapPaged helper).

## 2 · Routes (companyShell children, in this order)
```
{ path: 'quotes', component: MyQuotes },
{ path: 'quotes/new', component: NewQuote },
{ path: 'policies', component: MyPolicies },
{ path: 'policies/apply', component: ApplyPolicy },
{ path: 'policies/:id', component: PolicyDetailsPage },
```
IMPORTANT: `policies` and `policies/apply` BEFORE `policies/:id` (so "apply" isn't
swallowed as an id). Import `PolicyDetailsPage` from
`features/policies/policy-details/policy-details` (class name ends in `Page`
because `PolicyDetails` is the model interface's name).

## 3 · Re-paste (fix-related)
- `core/services/quote.service.ts` — real server-side paging (`page`, `pageSize=25`,
  `status` filter) via shared `unwrapPaged`; wider date-field candidates.
- `core/services/policy.service.ts` — same paging + filters.
- `features/quotes/my-quotes/*` — server paging + pager bar (Prev/1..n/Next),
  filters without client counts, dates as `Created dd-MM-yyyy · Valid until dd-MM-yyyy`.
- `features/dashboard/company-dashboard/*` — 2×2 card grid, My policies live.
- `shared/layouts/app-layout/app-layout.ts` — navbar gains **My policies**.

## 4 · Verify
1. My quotes: if you have >25 quotes, the pager appears; filters re-query the server.
2. My policies: seeded rows show (POL-2026-AA0001 Active ₹7,02,000; Raj's Tier A ₹6,00,000);
   Pending rows get a **Pay now** button (toasts + flips Active).
3. Policy details: full cover card; Pending → pay/cancel; Active → **Get renewal offer**.
   Note: the backend gates renewals to the window near expiry — on the seeded Active
   policies you'll get the gate's message (amber box). That's FR-correct behavior;
   the band card (Discount10/NoChange/Surcharge15/ReviewRequired + ratio % + adjusted
   premium) needs a policy within 15 days of expiry to demo live.
4. `ng test` green.
