import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApplyPolicyRequest,
  ApplyPolicyResponse,
  PayPolicyResponse,
  PolicyDetails,
  PolicyListItem,
  RenewalResponse,
} from '../models/policy.model';
import { Paged, unwrapPaged } from '../models/paged';

const API = environment.apiBaseUrl;

/** Server page size for policy lists (change in one place). */
export const PAGE_SIZE = 25;

// InsuranceService client (doc §6.4). Company ownership is always resolved
// server-side from the caller's token — the client never sends a company ID.
@Injectable({ providedIn: 'root' })
export class PolicyService {
  private readonly http = inject(HttpClient);

  /** FR4.1 — straight-through application; 201 Created. Starts Pending. */
  apply(body: ApplyPolicyRequest): Observable<ApplyPolicyResponse> {
    return this.http.post<ApplyPolicyResponse>(`${API}/policies/apply`, body);
  }

  /** FR4.6/FR9.4 — caller's policies, paged, optional status + created-date filters. */
  mine(filter?: { status?: string; from?: string; to?: string; page?: number }): Observable<Paged<PolicyListItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', PAGE_SIZE);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.from) params = params.set('from', filter.from);
    if (filter?.to) params = params.set('to', filter.to);
    return this.http
      .get<unknown>(`${API}/policies/company`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizePolicy)));
  }

  get(id: string): Observable<PolicyDetails> {
    return this.http.get<unknown>(`${API}/policies/${id}`).pipe(map(normalizePolicy)) as Observable<PolicyDetails>;
  }

  /** FR4.4/FR6.1 — payment activates with a 365-day term. */
  pay(id: string): Observable<PayPolicyResponse> {
    return this.http.post<PayPolicyResponse>(`${API}/policies/${id}/pay`, {});
  }

  /** FR4.5 — cancel a Pending policy (also how a renewal offer is declined). */
  cancel(id: string): Observable<void> {
    return this.http.delete<void>(`${API}/policies/${id}`);
  }

  /** FR4.7 — claims-ratio-priced renewal offer (409 outside the window or if one is already pending). */
  renew(id: string): Observable<RenewalResponse> {
    return this.http.post<RenewalResponse>(`${API}/policies/${id}/renew`, {});
  }
}

type Raw = Record<string, any>;

function normalizePolicy(p: Raw): PolicyListItem {
  return {
    ...p,
    addOns: Array.isArray(p.addOns)
      ? p.addOns
      : typeof p.addOns === 'string' && p.addOns.length
        ? p.addOns.split(',').map((s: string) => s.trim())
        : [],
    startDateUtc: p.startDateUtc ?? null,
    endDateUtc: p.endDateUtc ?? null,
  } as PolicyListItem;
}
