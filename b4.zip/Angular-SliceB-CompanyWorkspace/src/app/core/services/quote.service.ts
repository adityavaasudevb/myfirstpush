import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CreateQuoteResponse, Quote, QuoteRequest } from '../models/quote.model';
import { Paged, unwrapPaged } from '../models/paged';

const API = environment.apiBaseUrl;

/** Server page size for quote/policy lists (change in one place). */
export const PAGE_SIZE = 25;

// QuoteService client (doc §6.3). Ownership comes from the caller's token.
// The normalize* helpers adapt whatever field names the backend actually
// ships into the UI's canonical model — so the templates stay simple.
@Injectable({ providedIn: 'root' })
export class QuoteService {
  private readonly http = inject(HttpClient);

  /** FR3.1/FR3.2 — estimate + persist; response includes the alternate-tier estimate. */
  create(body: QuoteRequest): Observable<CreateQuoteResponse> {
    return this.http.post<unknown>(`${API}/quotes`, body).pipe(map(normalizeCreate));
  }

  /** FR3.5/FR9.4 — paged history, newest first, optional status filter (server-side). */
  mine(page = 1, status?: string): Observable<Paged<Quote>> {
    let params = new HttpParams().set('page', page).set('pageSize', PAGE_SIZE);
    if (status) params = params.set('status', status);
    return this.http
      .get<unknown>(`${API}/quotes/company`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizeQuote)));
  }

  get(id: string): Observable<Quote> {
    return this.http.get<unknown>(`${API}/quotes/${id}`).pipe(map(normalizeQuote));
  }

  /** FR3.4 — echoes stored inputs for InsuranceService to cross-check on apply. */
  convert(id: string): Observable<unknown> {
    return this.http.post(`${API}/quotes/${id}/convert`, {});
  }
}

type Raw = Record<string, any>;

function num(...cands: unknown[]): number {
  for (const c of cands) if (typeof c === 'number') return c;
  return 0;
}
function str(...cands: unknown[]): string {
  for (const c of cands) if (typeof c === 'string' && c.length) return c;
  return '';
}

function normalizeQuote(q: Raw): Quote {
  return {
    id: str(q.id),
    quoteNumber: str(q.quoteNumber),
    fleetSize: num(q.fleetSize),
    tier: str(q.tier),
    addOns: Array.isArray(q.addOns)
      ? (q.addOns as string[])
      : typeof q.addOns === 'string' && q.addOns.length
        ? (q.addOns as string).split(',').map((s) => s.trim())
        : [],
    premiumInr: num(q.premiumInr, q.estimatedPremiumInr, q.premium, q.totalPremiumInr),
    estimatedPremiumUsd: num(q.estimatedPremiumUsd, q.premiumUsd),
    estimatedPremiumEur: num(q.estimatedPremiumEur, q.premiumEur),
    usedFallbackRate: Boolean(q.usedFallbackRate),
    status: str(q.status, q.effectiveStatus),
    createdAtUtc: str(q.createdAtUtc, q.createdUtc, q.createdAt, q.createdOn, q.createdOnUtc, q.issuedAtUtc, q.quotedAtUtc, q.createdDate),
    expiresAtUtc: str(q.expiresAtUtc, q.expiresUtc, q.expiresAt, q.expiryUtc, q.expiryDateUtc, q.validUntil, q.validUntilUtc, q.expiresOn, q.expiresOnUtc, q.expiryDate),
  };
}

function normalizeCreate(res: Raw): CreateQuoteResponse {
  const qRaw: Raw = res.quote ?? res; // wrapped { quote, alternateTier } or bare quote
  const alt: Raw = res.alternateTier ?? qRaw.alternateTier ?? {};
  return {
    quote: normalizeQuote(qRaw),
    alternateTier: {
      tier: str(alt.tier),
      premiumInr: num(alt.premiumInr, alt.estimatedPremiumInr),
    },
  };
}
