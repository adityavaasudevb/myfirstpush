// Display options for the quote form.
// NOTE: rates and premium math live ONLY on the server (Section 3:
// "The Angular app never computes premiums; it displays server-calculated
// figures"). This file is labels + blurbs, nothing more.

export const TIER_OPTIONS: { key: 'Tier A' | 'Tier B'; blurb: string }[] = [
  { key: 'Tier A', blurb: 'Period 1 cover — while the app is in active use.' },
  { key: 'Tier B', blurb: 'Full cover — Periods 1, 2 and 3.' },
];

export const ADD_ON_OPTIONS: { key: string; blurb: string }[] = [
  { key: 'Physical Damage', blurb: 'Required for own-vehicle damage claims.' },
  { key: 'Uninsured Motorist', blurb: 'Required when the third party is uninsured.' },
  { key: 'Medical Payments', blurb: 'Required for medical-expense claims.' },
  { key: 'Rental Car', blurb: 'Replacement vehicle while yours is repaired.' },
];
