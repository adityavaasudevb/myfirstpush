// InsuranceService (policies) contract — verified against PolicyDtos.cs /
// PoliciesController.cs. JSON is camelCase; dates are ISO strings.

/** FR4.1 — POST /api/policies/apply. originQuoteId links to an existing
 *  Active quote (the FR3.4 conversion); null = straight-through application. */
export interface ApplyPolicyRequest {
  originQuoteId: string | null;
  tier: string;
  addOns: string[];
  fleetSize: number;
}

export interface ApplyPolicyResponse {
  policyId: string;
  policyNumber: string;
  premiumInr: number;
  status: string; // "Pending" until paid
}

/** FR4.4/FR6.1 — simulated payment activates the policy (365-day term). */
export interface PayPolicyResponse {
  policyId: string;
  policyNumber: string;
  status: string; // "Active"
  startDateUtc: string;
  endDateUtc: string;
}

/** FR4.7 — renewal offer (created by POST /renew); accept = pay, decline = cancel. */
export interface RenewalResponse {
  newPolicyId: string;
  newPolicyNumber: string;
  previousPremiumInr: number;
  claimsRatio: number;
  band: string; // Discount10 | NoChange | Surcharge15 | ReviewRequired
  reviewRequired: boolean;
  adjustedPremiumInr: number;
}

export type PolicyStatus = 'Pending' | 'Active' | 'Expired' | 'Cancelled';

export interface PolicyListItem {
  id: string;
  policyNumber: string;
  companyProfileId: string;
  tier: string;
  addOns: string[];
  fleetSize: number;
  premiumInr: number;
  status: PolicyStatus | string; // EffectiveStatus (lazy expiry applied)
  isRenewal: boolean;
  reviewRequired: boolean;
  createdAtUtc: string;
  startDateUtc: string | null;
  endDateUtc: string | null;
}

export interface PolicyDetails extends PolicyListItem {
  originQuoteId: string | null;
  renewedFromPolicyId: string | null;
}
