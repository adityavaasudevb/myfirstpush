// Shared paged-result shape — the backend's list endpoints return
// PagedResult<T> ({ items, page, pageSize, total }); this normalizes it
// defensively and also tolerates a bare array.

export interface Paged<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export function unwrapPaged<T>(res: unknown, normalize: (raw: any) => T): Paged<T> {
  if (Array.isArray(res)) {
    return { items: res.map(normalize), total: res.length, page: 1, pageSize: res.length || 25 };
  }
  const r = (res ?? {}) as Record<string, any>;
  const rawItems = (r.items ?? r.data ?? r.results ?? []) as any[];
  const items = rawItems.map(normalize);
  const total = r.total ?? r.totalCount ?? r.totalItems ?? r.count;
  return {
    items,
    total: typeof total === 'number' ? total : items.length,
    page: typeof r.page === 'number' ? r.page : 1,
    pageSize: typeof r.pageSize === 'number' ? r.pageSize : items.length || 25,
  };
}
