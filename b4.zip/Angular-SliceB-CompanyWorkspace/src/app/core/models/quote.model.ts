// QuoteService contract (FR3.x) — verified against the actual DTOs:
// CreateQuoteRequest(fleetSize, tier, addOns?)  →  CreateQuoteResponse(quote, alternateTier).
// JSON is camelCase. Tiers are canonical "Tier A" / "Tier B" strings.

export type TierName = 'Tier A' | 'Tier B';
export type QuoteStatus = 'Active' | 'Expired' | 'Converted';

export interface QuoteRequest {
  fleetSize: number;
  tier: TierName;
  addOns: string[];
}

export interface Quote {
  id: string;
  quoteNumber: string;
  fleetSize: number;
  tier: string;
  addOns: string[];
  premiumInr: number;
  estimatedPremiumUsd: number; // FR3.6 — live FX, rounded to 2dp
  estimatedPremiumEur: number;
  usedFallbackRate: boolean; // FR3.6 — true when the retried FX call failed and the fallback rate was used
  status: QuoteStatus | string; // server's EffectiveStatus (lazy 7-day expiry, never stored)
  createdAtUtc: string;
  expiresAtUtc: string;
}

export interface TierEstimate {
  tier: string;
  premiumInr: number;
}

/** POST /api/quotes response — the persisted quote plus the FR3.2
 *  side-by-side estimate for the tier the caller did NOT pick. */
export interface CreateQuoteResponse {
  quote: Quote;
  alternateTier: TierEstimate;
}
