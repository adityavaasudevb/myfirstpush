import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { MyQuotes } from './my-quotes';

describe('MyQuotes', () => {
  let component: MyQuotes;
  let fixture: ComponentFixture<MyQuotes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MyQuotes],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(MyQuotes);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
