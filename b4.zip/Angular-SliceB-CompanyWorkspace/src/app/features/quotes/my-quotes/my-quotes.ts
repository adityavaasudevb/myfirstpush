import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { QuoteService } from '../../../core/services/quote.service';
import { Quote } from '../../../core/models/quote.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

type StatusFilter = 'All' | 'Active' | 'Converted' | 'Expired';

@Component({
  selector: 'app-my-quotes',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './my-quotes.html',
  styleUrl: './my-quotes.css',
})
export class MyQuotes {
  private readonly quotesApi = inject(QuoteService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<Quote> | null>(null);
  readonly statusFilter = signal<StatusFilter>('All');
  readonly page = signal(1);

  readonly filters: StatusFilter[] = ['All', 'Active', 'Converted', 'Expired'];

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    const f = this.statusFilter();
    this.quotesApi.mine(this.page(), f === 'All' ? undefined : f).subscribe({
      next: (pg) => {
        this.paged.set(pg);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  setFilter(f: StatusFilter): void {
    if (this.statusFilter() === f) return;
    this.statusFilter.set(f);
    this.page.set(1);
    this.reload();
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Converted':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  /** "Created 20-06-2026 · Valid until 27-06-2026" (empty when the backend omits dates). */
  meta(q: Quote): string {
    const c = this.fmt(q.createdAtUtc);
    const e = this.fmt(q.expiresAtUtc);
    if (!c && !e) return '';
    return `Created ${c} · Valid until ${e}`;
  }

  private fmt(iso: string): string {
    if (!iso) return '—';
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
