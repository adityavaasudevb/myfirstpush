import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CompanyProfileService } from '../../company-profile/services/company-profile.service';

@Component({
  selector: 'app-company-dashboard',
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './company-dashboard.html',
  styleUrl: './company-dashboard.css',
})
export class CompanyDashboard {
  readonly auth = inject(AuthService);
  // The profile guard already loaded this by the time we render.
  readonly profile = inject(CompanyProfileService);
}
