import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { PolicyDetailsPage } from './policy-details';

describe('PolicyDetailsPage', () => {
  let component: PolicyDetailsPage;
  let fixture: ComponentFixture<PolicyDetailsPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyDetailsPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(PolicyDetailsPage);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
