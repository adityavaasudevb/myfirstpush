import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { PolicyService } from '../../../core/services/policy.service';
import { PolicyDetails, RenewalResponse } from '../../../core/models/policy.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-policy-details',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './policy-details.html',
  styleUrl: './policy-details.css',
})
export class PolicyDetailsPage {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly policies = inject(PolicyService);
  private readonly alerts = inject(AlertService);

  private readonly id = this.route.snapshot.paramMap.get('id')!;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly policy = signal<PolicyDetails | null>(null);

  readonly paying = signal(false);
  readonly cancelling = signal(false);
  readonly actionError = signal<string | null>(null);

  readonly renewing = signal(false);
  readonly renewError = signal<string | null>(null);
  readonly renewal = signal<RenewalResponse | null>(null);
  readonly payingRenewal = signal(false);
  readonly declining = signal(false);

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.policies.get(this.id).subscribe({
      next: (p) => {
        this.policy.set(p);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  pay(): void {
    this.paying.set(true);
    this.actionError.set(null);
    this.policies.pay(this.id).subscribe({
      next: () => {
        this.paying.set(false);
        this.alerts.success('Policy is now active.');
        this.reload();
      },
      error: (err) => {
        this.paying.set(false);
        this.actionError.set(responseErrorText(err));
      },
    });
  }

  cancel(): void {
    this.cancelling.set(true);
    this.actionError.set(null);
    this.policies.cancel(this.id).subscribe({
      next: () => {
        this.cancelling.set(false);
        this.alerts.info('Application cancelled.');
        this.reload();
      },
      error: (err) => {
        this.cancelling.set(false);
        this.actionError.set(responseErrorText(err));
      },
    });
  }

  renew(): void {
    this.renewing.set(true);
    this.renewError.set(null);
    this.policies.renew(this.id).subscribe({
      next: (r) => {
        this.renewal.set(r);
        this.renewing.set(false);
      },
      error: (err) => {
        this.renewing.set(false);
        this.renewError.set(responseErrorText(err)); // e.g. outside the renewal window
      },
    });
  }

  payRenewal(): void {
    const r = this.renewal();
    if (!r) return;
    this.payingRenewal.set(true);
    this.policies.pay(r.newPolicyId).subscribe({
      next: () => {
        this.alerts.success(`Renewal ${r.newPolicyNumber} is now active.`);
        this.router.navigate(['/company/policies', r.newPolicyId]);
      },
      error: (err) => {
        this.payingRenewal.set(false);
        this.alerts.error(responseErrorText(err));
      },
    });
  }

  declineRenewal(): void {
    const r = this.renewal();
    if (!r) return;
    this.declining.set(true);
    this.policies.cancel(r.newPolicyId).subscribe({
      next: () => {
        this.declining.set(false);
        this.renewal.set(null);
        this.alerts.info('Renewal offer declined.');
      },
      error: (err) => {
        this.declining.set(false);
        this.alerts.error(responseErrorText(err));
      },
    });
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Pending':
        return 'bg-amber-100 text-amber-800';
      case 'Cancelled':
        return 'bg-gray-100 text-gray-600';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  bandChip(band: string): string {
    switch (band) {
      case 'Discount10':
        return 'bg-green-100 text-green-800';
      case 'Surcharge15':
        return 'bg-amber-100 text-amber-800';
      case 'ReviewRequired':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  bandLabel(band: string): string {
    switch (band) {
      case 'Discount10':
        return '10% loyalty discount';
      case 'NoChange':
        return 'No change';
      case 'Surcharge15':
        return '15% surcharge';
      case 'ReviewRequired':
        return 'Flagged for review';
      default:
        return band;
    }
  }

  percent(ratio: number): string {
    return `${Math.round(ratio * 100)}%`;
  }
}
