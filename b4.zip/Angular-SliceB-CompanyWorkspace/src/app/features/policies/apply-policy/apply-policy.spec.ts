import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { ApplyPolicy } from './apply-policy';

describe('ApplyPolicy', () => {
  let component: ApplyPolicy;
  let fixture: ComponentFixture<ApplyPolicy>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ApplyPolicy],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(ApplyPolicy);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
