import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { PolicyService } from '../../../core/services/policy.service';
import { PolicyListItem } from '../../../core/models/policy.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';

type StatusFilter = 'All' | 'Pending' | 'Active' | 'Expired' | 'Cancelled';

@Component({
  selector: 'app-my-policies',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './my-policies.html',
  styleUrl: './my-policies.css',
})
export class MyPolicies {
  private readonly policies = inject(PolicyService);
  private readonly alerts = inject(AlertService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<PolicyListItem> | null>(null);
  readonly statusFilter = signal<StatusFilter>('All');
  readonly page = signal(1);
  readonly payingId = signal<string | null>(null);

  readonly filters: StatusFilter[] = ['All', 'Pending', 'Active', 'Expired', 'Cancelled'];

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    const f = this.statusFilter();
    this.policies.mine({ page: this.page(), status: f === 'All' ? undefined : f }).subscribe({
      next: (pg) => {
        this.paged.set(pg);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  setFilter(f: StatusFilter): void {
    if (this.statusFilter() === f) return;
    this.statusFilter.set(f);
    this.page.set(1);
    this.reload();
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  pay(p: PolicyListItem): void {
    this.payingId.set(p.id);
    this.policies.pay(p.id).subscribe({
      next: () => {
        this.payingId.set(null);
        this.alerts.success(`Policy ${p.policyNumber} is now active.`);
        this.reload();
      },
      error: (err) => {
        this.payingId.set(null);
        this.alerts.error(responseErrorText(err));
      },
    });
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800';
      case 'Pending':
        return 'bg-amber-100 text-amber-800';
      case 'Cancelled':
        return 'bg-gray-100 text-gray-600';
      default:
        return 'bg-warm-light text-ink-soft'; // Expired
    }
  }

  period(p: PolicyListItem): string {
    if (!p.startDateUtc || !p.endDateUtc) return 'Not active yet';
    return `${this.fmt(p.startDateUtc)} → ${this.fmt(p.endDateUtc)}`;
  }

  private fmt(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
