# Dashboard counts vs the lists — what is actually wrong

Four numbers were questioned. **One is a real bug. One is a labelling problem.
Two need one query each from your database before anyone can call them wrong.**

---

## 1. "28 active policies, but the list says 26" — REAL BUG, fixed here

Two different definitions of the word *active*:

```csharp
// DashboardService.cs — OLD
p.Status == PolicyStatuses.Active && p.EndDateUtc >= now

// PolicyService.ApplyStatusFilter — the explorer's "Active" chip
p.Status == PolicyStatuses.Active && p.StartDateUtc <= now && p.EndDateUtc > now
```

The dashboard's version forgets **`StartDate <= now`**. A paid renewal is
stored `Status = Active` with a start date **in the future** — the API itself
reports that row as `EffectiveStatus == "Scheduled"`, and the explorer puts it
under "Scheduled". The dashboard counted it as active anyway.

So: two paid renewals sitting in the future gives you **28 on the card and 26
in the list**, and the list is right. The dashboard was double-counting next
term's cover alongside this term's.

`DashboardService.cs` in this folder fixes the predicate to match the explorer
exactly. **Drop it in place of yours.** No other line changed.

To confirm the diagnosis before you apply it, run:

```sql
SELECT COUNT(*) AS dashboard_said
FROM Policies
WHERE Status = 'Active' AND EndDateUtc >= GETUTCDATE();

SELECT COUNT(*) AS list_says
FROM Policies
WHERE Status = 'Active'
  AND StartDateUtc <= GETUTCDATE() AND EndDateUtc > GETUTCDATE();
```

If the first is 28 and the second 26, this is your bug.

---

## 2. "Claims this month 13, but only 9" — CONFIRMED, and the 4-row gap is explained

Your query returned **13 rows**, which is exactly what the dashboard counts.
**Nine** of them have a November incident; the other **four** were filed in
November for incidents in August and October:

```
CLM-2026-9E7D54F1   filed 2026-11-11   incident 2026-08-08
CLM-2026-75A19C80   filed 2026-11-11   incident 2026-08-09
CLM-2026-27BA799E   filed 2026-11-11   incident 2026-10-31
CLM-2026-F937430A   filed 2026-11-11   incident 2026-10-30
```

13 − 4 = **9**. Nothing is miscounted. Two different questions:

| Card says | Actually counts | Your 9 is |
|---|---|---|
| "Claims this month" | claims **filed** this month | claims whose **incident** is this month |

Note those four include two claims for **August** incidents filed on 11
November — late intimation, correctly flagged by the v3.2 rule. That is the
system working, not a bug.



`claimsThisMonth` counts claims **filed** in the calendar month:

```csharp
_db.Claims.CountAsync(c => c.CreatedAtUtc >= monthStart)
```

It is not "claims decided this month" and not "claims in that status tab". The
card says **"Claims this month"**, which reads as *decided*. Change the label to
**"Claims filed this month"** and the two numbers stop arguing.

Run this to see which 13 it is counting:

```sql
SELECT ClaimNumber, Status, CreatedAtUtc, IncidentAtUtc
FROM Claims
WHERE CreatedAtUtc >= DATEFROMPARTS(YEAR(GETUTCDATE()), MONTH(GETUTCDATE()), 1)
ORDER BY CreatedAtUtc;
```



---

## 3. "Payout 87,867 but paid 1,000" — CONFIRMED CORRECT, no change needed

Your SSMS output sums to exactly the dashboard figure:

```
CLM-2026-BB0005    59,998.00   2026-11-09
CLM-2026-98B4AA4B   3,434.00   2026-11-09
CLM-2026-9C32208D  23,435.00   2026-11-16
CLM-2026-0D2D5E2D   1,000.00   2026-11-24
                  ---------
                   87,867.00   <- the card
```

**The card is right.** The ₹1,000 you were comparing against is one claim
(`0D2D5E2D`, paid yesterday) out of four decided in November.

And your claims list confirms only four rows say `Paid` — the fifth row you
saw, `CLM-2026-GFW101` at ₹3,68,000, is **not** in the November decision list,
so it was approved in an earlier month. Same shape of mistake as the policies:
a status column showing `Paid` is not the same as *approved this month*.

⚠ One real caveat this exposes: **there is no record of when the money moved.**
The card dates a payout by the **decision**, not by any payment event, because
no payment record exists (FR6.2). If a payment is ever made days after
approval, the dashboard will attribute it to the wrong month and nothing can
detect that. The card must say "approved", not "paid".

---

## 4. "Admin can't see all the quotes" — REAL GAP, and the conversion rate inherits it

`GET /api/quotes/company` is `[Authorize(Roles = "Company")]` and filters to the
caller's own quotes. **There is no admin quote list.** The only admin-facing
quote endpoint is `GET /api/quotes/stats`, which returns three integers.

**And this is why the conversion rate looks wrong.** `GetStatsAsync` counts:

```csharp
total     = all quotes
converted = quotes where Status == "Converted"
```

`Converted` is only written when a company applies for a policy. A quote that
sat for 7 days and expired is still stored as `Status = Active` — expiry is
computed lazily (`Quote.EffectiveStatus`), never persisted. So expired quotes
stay in the denominator as if they were live. **The rate is "converted ÷ ever
quoted", which understates conversion for any quote book older than a week.**
It is not wrong exactly; it is measuring a different thing from what the card
implies.

### The fix for both, in order

1. **Expose history to Admin.** In `QuotesController`, the `history` action is
   `[Authorize(Roles = "Company")]`. Add `Admin` and pass the role through to
   `GetHistoryAsync`, skipping `EnsureOwner` when the caller is Admin. Every
   filter already works — `Active` in that method means *unexpired*
   (`q.ExpiryDate > now`), which is the correct definition and already
   distinguishes expired quotes. Nothing else to build.
2. **Then the screen.** A `features/quotes/admin-quotes` page cloned from
   `admin-policies` gives company-wise history, status chips with live counts,
   and a date range. Note the table has `OwnerUserId` but **not** the company
   name — showing "company wise" needs a name, which lives in CustomerService.
   Options: snapshot `CompanyName` onto the quote at creation (one column, the
   same trick D4 proposes for policies), or call CustomerService per row (N+1,
   don't). With a demo tomorrow, I would add nothing and show the admin the
   raw list first.
3. **Fix the rate's definition at the same time.** Count expired quotes as not
   convertible:

```csharp
var now = DateTimeOffset.UtcNow;
var total     = await _db.Quotes.CountAsync(ct);
var converted = await _db.Quotes.CountAsync(q => q.Status == QuoteStatuses.Converted, ct);
var live      = await _db.Quotes.CountAsync(
    q => q.Status == QuoteStatuses.Converted || q.ExpiryDate > now, ct);   // convertible book
```

Report `converted / live` as **conversion of live quotes**, and keep
`converted / total` if you want the cumulative figure — labelled differently.
Do not silently swap one for the other.

---

## What I would do tonight, in this order

| Priority | Item | Cost |
|---|---|---|
| 1 | `DashboardService.cs` — the active-policies predicate | one file, verified |
| 2 | Rename the two cards: "Claims filed this month", "Payouts approved this month" | two strings in the template |
| 3 | Run the three SQL checks above and send me the outputs | 2 minutes |
| 4 | Admin quote list | 1 controller line + 1 page, **only if hours remain** |

Item 4 is a real gap, but it is a *new screen* the night before a demo. Item 1
is a copy-paste that removes a contradiction. Do 1 and 2, verify 3, and defer 4
to the README rather than the build.
