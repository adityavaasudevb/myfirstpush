/* ============================================================================
   LANE B — the only SQL in the video lane
   ----------------------------------------------------------------------------
   No inserts. No ids. Two optional statements, run only if you want them:

     A) backdate the term so the policy does not visibly start "this morning"
     B) end the term inside the renewal window so the Renew button works

   Both find the policy purely through the company email you registered with.
   Pick ONE of A or B — B already includes the backdating.
   ============================================================================ */

USE TncInsurance;

/* --- A) cosmetically backdated, full year ahead --------------------------- */
-- UPDATE Policies
-- SET StartDateUtc = '2026-08-01T10:00:00+00:00',
--     EndDateUtc   = '2027-07-31T10:00:00+00:00'
-- WHERE CompanyProfileId = (SELECT TOP 1 Id FROM CompanyProfiles WHERE Email = N'desk@coastalspice.in')
--   AND Status = N'Active';

/* --- B) backdated AND inside the 30-day renewal window -------------------- */
--     Renewal then prices at 2,61,360 x 0.90 = 2,35,224 (claims ratio 0.223)
UPDATE Policies
SET StartDateUtc = '2025-12-01T10:00:00+00:00',
    EndDateUtc   = '2026-11-30T10:00:00+00:00'
WHERE CompanyProfileId = (SELECT TOP 1 Id FROM CompanyProfiles WHERE Email = N'desk@coastalspice.in')
  AND Status = N'Active';

/* --- read-back: prove what you just did ---------------------------------- */
SELECT PolicyNumber, Status, PremiumInr, FleetSize, Tier, AddOns, StartDateUtc, EndDateUtc
FROM Policies
WHERE CompanyProfileId = (SELECT TOP 1 Id FROM CompanyProfiles WHERE Email = N'desk@coastalspice.in');

PRINT 'LANE B — policy term updated. Renewal window: opens 30 days before EndDateUtc.';
