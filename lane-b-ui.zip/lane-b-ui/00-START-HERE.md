# Lane B in 7 steps

Everything here is typed into the UI. The only SQL is one optional UPDATE.

```
1.  Register:  desk@coastalspice.in / Coastal@2026Desk           (Company)
               ravi.shankar@claimgrid.in / Ravi@2026Survey       (Surveyor → Admin approves)

2.  Company Profile:  Coastal Spice Logistics Pvt Ltd
                      CIN U63030TG2016PTC104417 · Nandita Rao · 9848099120 · 9 vehicles

3.  Quote: 9 vehicles, Tier B, Physical Damage + Medical Payments + Rental Car
        → premium must read  ₹2,61,360
    Convert → Pay  → note the POL-2026-XXXXXXXX it prints

4.  (Optional) run seed-lane-b-backdate.sql to move the term back

5.  File CLAIM A  (clean)   05 Nov 10:22 · ₹58,327.40 · Suresh Pillai · TG13MX4747
        uploads: FIR-01-clean · RepairEstimate-01-clean · Towing-01-clean

6.  File CLAIM B  (defect)  05 Nov 16:45 · ₹52,780 · Suresh Pillai · TG13MX4747
        uploads: FIR-02-defects · RepairEstimate-02-defects · Towing-02-defects

7.  Surveyor: pick up A → integrity check → Consistent → 4 fields verified → report Approve
              pick up B → integrity check → Inconsistent → Documents = Suspicious → report Reject
    Admin: review both, approve A, decide B, then renew the policy (if you ran the backdate)
```

Read `README-B.md` for every field value, every expected finding, and the renewal maths.
