# Lane B — the video lane (everything typed in the UI)

**Company:** Coastal Spice Logistics Pvt Ltd
**Two claims, one policy.** Claim A is clean, Claim B is the defective one. You file both through
the claim form, uploading the PDFs from `lane-b-ui/documents/`.

> Different company, people, vehicles and workshops from Lane A on purpose. Nothing here shares a
> single value with the SQL seed, so nothing can be confused during a recording.

---

## Before you record — the 6 things that must be true

| # | Check | Why it matters |
|---|---|---|
| 1 | Insurance API running, `DocumentStorage:RootPath` writable | uploads 500 without it |
| 2 | `Ai:Provider` = `vertex` **or** `inprocess` | live AI vs offline badges |
| 3 | You are logged out, then logged in fresh | stale company profile in memory |
| 4 | `Policies` table has **no** other Active policy for this company (FR4.1) | apply returns 409 |
| 5 | Uploads folder empty for this company's claims | no ghost documents |
| 6 | Browser zoom 100 %, notifications off | clean capture |

---

## 1. Accounts to create (once, ~90 seconds, on camera if you want)

| Who | Email | Password | Notes |
|---|---|---|---|
| Company | `desk@coastalspice.in` | `Coastal@2026Desk` | Register → Company |
| Surveyor | `ravi.shankar@claimgrid.in` | `Ravi@2026Survey` | Register → Surveyor, then **admin approves** |
| Admin | the existing admin | — | only approves the surveyor |

The surveyor must show as **Approved** before you pick up a claim; an unapproved surveyor gets
`403 SURVEYOR_PENDING_APPROVAL` at login. Approve *before* the claim scenes.

---

## 2. Company profile (UI → Company Profile)

| Field | Value |
|---|---|
| Company name | `Coastal Spice Logistics Pvt Ltd` |
| Registration no. (CIN) | `U63030TG2016PTC104417` |
| Contact person | `Nandita Rao` |
| Phone | `9848099120` |
| Fleet size | `9` |

The registration number is fixed at registration and shown read-only afterwards — type it once.

---

## 3. Quote (UI) → Policy (UI)

**Create quote:** fleet `9`, Tier `Tier B`, add-ons **Physical Damage + Medical Payments + Rental Car**.

Premium the system computes: `9 × 15,000 × 1.6 × (1 + .12 + .06 + .03)` = **₹2,61,360**.
Watch the number on screen match that — it is the only "magic" number in the flow.

**Convert → Pay.** The number the backend prints is `POL-2026-XXXXXXXX` (8 random hex chars).
**Write it down.** You will not need it again in the UI, but say it on camera for the record.

### After paying — one SQL statement (backdate the term)

A UI-paid policy starts *today*. That is fine here because both claims are dated **earlier the same
day**, but the term looks better (and the renewal math below is exact) if you move it back:

```sql
USE TncInsurance;

UPDATE Policies
SET StartDateUtc = '2026-08-01T10:00:00+00:00',
    EndDateUtc   = '2027-07-31T10:00:00+00:00'
WHERE CompanyProfileId = (SELECT TOP 1 Id FROM CompanyProfiles WHERE Email = N'desk@coastalspice.in')
  AND Status = N'Active';
```

**Nothing else is touched** — premium, tier, add-ons and the quote link stay as the UI created them.
Skip it and the demo still works; you just cannot renew (see §8).

---

## 4. Claim A — CLEAN (record this one as the good path)

**UI → Claims → File a claim.** Every value below is typed by you and appears identically in the PDFs.

| Field | Type this |
|---|---|
| Policy | the one Active policy (only one will be listed) |
| Claim type | `Own Vehicle Damage` |
| Driver name | `Suresh Pillai` |
| Driver licence | `TG0520170066128` |
| Vehicle number | `TG13MX4747` |
| Passenger name | `Meera Chandran` |
| Passenger contact | `9000041182` |
| Passengers aboard | `2` |
| Other passengers | `Second passenger: loader from the site, no injury.` |
| Incident date/time | **05 Nov 2026, 10:22** (local) |
| Incident location | `KPHB Phase 6 main road, near the vegetable market, Hyderabad - 500072` |
| Claimed amount | **`58327.40`** |
| Document link | `https://evidence.internal/coastal/CLM-A` |
| App not in use | unchecked |

**Trip log** (the form pre-seeds the four canonical events; type the times):

| Event | Time (local) |
|---|---|
| AppOnline | 05 Nov, 09:55 |
| RideAccepted | 05 Nov, 10:05 |
| PassengerPickedUp | 05 Nov, 10:12 |
| RideCompleted | 05 Nov, 11:05 |

Incident 10:22 sits between pickup (10:12) and completion (11:05) → **Period 3** → preliminary
**Approve ₹58,327.40**, no flag, no boundary flag (10:22 is 10 minutes off 10:12).

**Description** (paste):

> Vehicle was carrying two passengers south on the KPHB Phase 6 main road when a Tata Ace goods
> carrier reversed out of a side lane and struck the front of the vehicle. Front bumper, bonnet edge
> and right headlamp damaged. No injuries. Vehicle towed to Sri Venkata Sai Motors.

**Uploads** (Claims → this claim → Documents → upload):

| File | Document type |
|---|---|
| `FIR-01-clean.pdf` | `FIR` |
| `RepairEstimate-01-clean.pdf` | `RepairEstimate` |
| `TowingReceipt-01-clean.pdf` | `Other` |

### Why this set must come back clean

| Value | Form | FIR-01 | Estimate-01 | Towing-01 |
|---|---|---|---|---|
| Driver | Suresh Pillai | Suresh Pillai | — | — |
| Vehicle | TG13MX4747 | TG13MX4747 | TG13MX4747 | TG13MX4747 |
| Date | 05 Nov 10:22 | 05 Nov 10:10–10:40 | 05 Nov | 05 Nov 12:05 |
| Amount | ₹58,327.40 | — | ₹58,327.40 | ₹1,600 |
| Workshop | — | — | Sri Venkata Sai Motors | Sri Venkata Sai Motors |

Estimate arithmetic: parts 31,860 + labour 15,570 + supplies 2,000 = **49,430**; 18 % = **8,897.40**;
total **58,327.40** — which equals the claimed amount, to the paisa.

---

## 5. Claim B — UNCLEAN (record this one as the catch)

**Same policy. Different time of day (16:45), so the duplicate guard cannot fire.**

| Field | Type this |
|---|---|
| Claim type | `Own Vehicle Damage` |
| Driver name | `Suresh Pillai` |
| Driver licence | `TG0520170066128` |
| Vehicle number | `TG13MX4747` |
| Passenger name | `Anil Kumar` |
| Passenger contact | `9666650321` |
| Passengers aboard | `1` |
| Incident date/time | **05 Nov 2026, 16:45** |
| Incident location | `KPHB Phase 6 main road, near the vegetable market, Hyderabad - 500072` |
| Claimed amount | **`52780`** |
| Document link | `https://evidence.internal/coastal/CLM-B` |
| App not in use | unchecked |

**Trip log:** AppOnline 16:10 · RideAccepted 16:20 · PassengerPickedUp 16:28 · RideCompleted 17:20
→ incident 16:45 = **Period 3**, no boundary flag (17 min clear of 16:28).

**Description:**

> Vehicle was hit from behind by a Tata Ace while slowing for traffic near the vegetable market.
> Rear bumper and tailgate damaged. Passenger unhurt. Vehicle towed to Sri Venkata Sai Motors.

**Uploads:**

| File | Document type |
|---|---|
| `FIR-02-defects.pdf` | `FIR` |
| `RepairEstimate-02-defects.pdf` | `RepairEstimate` |
| `TowingReceipt-02-defects.pdf` | `Other` |

### What the audit must catch — say each one out loud

| # | Finding | Where it lives |
|---|---|---|
| 1 | **Registration mismatch** — documents read `TG13MX4477`, the form says `TG13MX4747` (two digits transposed) | FIR-02 vehicle table |
| 2 | **Document predates the incident** — estimate dated `03 Nov`, incident `05 Nov` | estimate header |
| 3 | **Document after the incident** — towing receipt dated `06 Nov` | towing header |
| 4 | **Duplicate line** — "Rear bumper assembly" appears twice at ₹12,000 | estimate parts |
| 5 | **Total exceeds claim** — estimate ₹57,820 vs claimed ₹52,780 | estimate foot |
| 6 | **FIR window disagrees** — FIR records the occurrence as 04 Nov 14:00–15:00, a day before the claim | FIR occurrence block |
| 7 | **Late FIR, declared "No delay"** — registered 09 Nov for a 04 Nov occurrence | FIR header |

Finding 4 is the sharpest one: remove the duplicated bumper and the estimate base falls
from ₹49,000 to ₹37,000, and the total from ₹57,820 to ₹43,660 — under the claimed amount.
That is the line to use on camera: *"the only reason the total is above the claim is that the same
part was billed twice."*

---

## 6. Surveyor flow (on camera, both claims)

1. **Queue** — should show both new claims plus nothing else if the DB is clean.
2. **Pick up** Claim A → the claim detail shows four Pending field verifications.
3. **Documents → Run integrity check.** Verdict should read **Consistent**.
4. Mark all four fields **Verified** → submit report: Genuine / Approve / ₹58,327.40 / notes ≥ 10 chars.
5. Back to queue → **Pick up** Claim B → integrity check → **Inconsistent** (or Needs review, if
   your threshold treats the date defects as warnings).
6. Mark `Documents` **Suspicious** with a one-line note, others Verified → report:
   Suspicious / Reject (no amount).
7. Mention the 409: try submitting the report while a field is still Pending — the UI shows
   "fields pending" instead of silently accepting.

## 7. Admin flow (on camera)

1. Open the claim → **Review**: preliminary determination next to the surveyor's report.
2. Claim A: Approve at ₹58,327.40 → claim becomes **Paid**, payout recorded.
3. Claim B: the surveyor recommended Reject; if you want to demo the override rule, choose Approve
   with an amount and no note → the API returns 400 *"An override note is mandatory"*. Then add the
   note and it goes through. That single interaction proves FR5.15 faster than any slide.
4. Dashboard tile: claims this month, payouts, and the attention list picking up the flagged claim.

## 8. Renewal (end the video with it)

Two options — pick one before recording:

**Option 1 (no config change, recommended):** skip the SQL backdate in §3. The policy then runs
`18 Nov 2026 → 18 Nov 2027` and renew returns 400 *"outside its renewal window"* — a legitimate
thing to show, but it is a rejection, not a renewal.

**Option 2 (a real renewal):** run the backdate but end the term at **30 Nov 2026**:

```sql
UPDATE Policies
SET StartDateUtc = '2025-12-01T10:00:00+00:00',
    EndDateUtc   = '2026-11-30T10:00:00+00:00'
WHERE CompanyProfileId = (SELECT TOP 1 Id FROM CompanyProfiles WHERE Email = N'desk@coastalspice.in')
  AND Status = N'Active';
```

Now the Renew button is live (ends in 12 days, inside the 30-day window) and the claims ratio is
`58,327.40 / 261,360 = 0.223` → **Discount10**:
`₹2,61,360 × 0.90 = ₹2,35,224`. Pay it and the parent flips to Expired, the renewal starts **1 Dec 2026**.

> Do **not** use the Lane A policy for renewal math: it has a Paid claim at 96× the premium's
> discount threshold, so it lands in Surcharge15 and the numbers will confuse the take.

---

## 9. File map

```
lane-b-ui/
├─ README-B.md                  ← this file
├─ seed-lane-b-backdate.sql      ← optional term fix / renewal setup (two statements, no ids)
└─ documents/
   ├─ FIR-01-clean.pdf                    37 KB
   ├─ RepairEstimate-01-clean.pdf
   ├─ TowingReceipt-01-clean.pdf
   ├─ FIR-02-defects.pdf
   ├─ RepairEstimate-02-defects.pdf
   └─ TowingReceipt-02-defects.pdf
```

All six are single-page, watermarked `SAMPLE · SYNTHETIC DEMO DOCUMENT`, and every number in them is
re-derived and asserted by `../generator/audit_docs.py`.
