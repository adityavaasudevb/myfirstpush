# Approval : rejection card — the fix

Two files change, one is new, and it is a drop-in copy at the same paths.

```
src/app/features/dashboard/admin-dashboard/admin-dashboard.ts     CHANGED
src/app/features/dashboard/admin-dashboard/admin-dashboard.html   CHANGED
src/app/features/dashboard/admin-dashboard/admin-dashboard.css    NEW (empty)
```

Full paths from your Angular project root:

```
src/app/features/dashboard/admin-dashboard/admin-dashboard.ts
src/app/features/dashboard/admin-dashboard/admin-dashboard.html
src/app/features/dashboard/admin-dashboard/admin-dashboard.css
```

## The exact edit, if you would rather not replace whole files

### 1. `admin-dashboard.ts`

Find this method (around line 54):

```ts
  /** Ratio is null when there were zero rejections this month. */
  ratioText(d: Dashboard): string {
    const r = d.metrics.approvalToRejectionRatio;
    return r == null ? '—' : `${this.trim(r)} : 1`;
  }
```

Replace it with:

```ts
  ratioText(d: Dashboard): string {
    const r = d.metrics.approvalToRejectionRatio;
    if (r == null) return '—';
    return `${this.trim(r)} : 1`;
  }

  /** "4 : 1" in words, so the number cannot be misread as a percentage. */
  ratioCaption(d: Dashboard): string {
    const r = d.metrics.approvalToRejectionRatio;
    if (r == null) return 'No claims were rejected this month';
    if (r === 0) return 'Nothing approved — every decided claim was rejected';
    if (r === 1) return 'One approval for every rejection';
    return `${this.trim(r)} approved for every 1 rejected`;
  }
```

### 2. `admin-dashboard.html`

Find this card (around line 27):

```html
      <div class="card p-4" title="Approvals ÷ rejections among claims decided this month. Null when there were zero rejections.">
        <p class="text-xs font-bold uppercase tracking-wide text-ink-soft">Approval : rejection</p>
        <p class="mt-1 text-3xl font-extrabold tabular-nums text-ink">{{ ratioText(d) }}</p>
        @if (d.metrics.approvalToRejectionRatio == null) {
          <p class="mt-0.5 text-xs text-ink-soft">No rejections this month</p>
        }
      </div>
```

Replace it with:

```html
      <div class="card p-4"
           title="Decisions taken this month, not claims filed or sitting in a list. Approvals ÷ rejections; null when nothing was rejected.">
        <p class="text-xs font-bold uppercase tracking-wide text-ink-soft">Approval : rejection</p>
        <p class="mt-1 text-3xl font-extrabold tabular-nums text-ink">{{ ratioText(d) }}</p>
        <p class="mt-0.5 text-xs text-ink-soft">{{ ratioCaption(d) }}</p>
        <p class="mt-1 text-[11px] text-ink-soft">Decided this month · not a pass rate</p>
      </div>
```

### 3. `admin-dashboard.css`

Create it if it does not exist, with any one comment line in it:

```css
/* Admin dashboard — component styles. Tailwind utilities only; file kept so styleUrl resolves. */
```

The component declares `styleUrl: './admin-dashboard.css'`. If that file is
missing the Angular build fails with a "styleUrl not found" error — this is
the one thing that can bite you after copying.

## What changes on screen

| Server value | Before | After |
|---|---|---|
| `null` | `—` + "No rejections this month" | `—` · *No claims were rejected this month* · *Decided this month · not a pass rate* |
| `0` | `0 : 1`, nothing else | `0 : 1` · *Nothing approved — every decided claim was rejected* |
| `1` | `1 : 1`, nothing else | `1 : 1` · *One approval for every rejection* |
| `4` | `4 : 1`, nothing else | `4 : 1` · *4 approved for every 1 rejected* |
| `1.5` | `1.5 : 1`, nothing else | `1.5 : 1` · *1.5 approved for every 1 rejected* |

## Why it was confusing

The number is `approved ÷ rejected` among claims **decisioned inside the
current calendar month**. It is not a percentage and not a pass rate. With 6
paid and 4 rejected decided this month it reads `1.5 : 1`. `4 : 1` is four
approvals for every rejection.

The backend is correct. Nothing in `DashboardService.cs`, `DashboardDto.cs`,
`dashboard.model.ts` or `dashboard.service.spec.ts` changes, and no API
contract changes.

## Why the demo shows a dash

`Seed/seed.sql` marks one claim `Paid` and **none** `Rejected`. Zero
rejections means no denominator, so the server sends `null` and the card shows
`—`. Reject one claim live during the demo and it fills in. That is the design,
not a defect.
