# Slice B — Company Workspace · FINAL: B1–B4 + B5/B6 (Claims)

Cumulative zip: quotes → apply → pay → policies → renew → claims. All DTO-verified.

## 1 · Generate
```
ng g c features/claims/file-claim
ng g c features/claims/my-claims
ng g c features/claims/claim-details
ng g s core/services/claims-api
```
Replace the four CLI spec files with the zip versions. New files:
`core/models/claim.model.ts`, `core/services/claims-api.service.ts`.

## 2 · Routes (companyShell children — static paths BEFORE params)
```
{ path: 'claims', component: MyClaims },
{ path: 'claims/new', component: FileClaim },
{ path: 'claims/:id', component: ClaimDetailsPage },
```
Imports: `features/claims/my-claims/my-claims` · `.../file-claim/file-claim` · `.../claim-details/claim-details`
(classes: `MyClaims`, `FileClaim`, `ClaimDetailsPage`).

## 3 · Re-paste
- `features/dashboard/company-dashboard/company-dashboard.html` — 3-col grid, My claims + File a claim live, muted "Insights".
- `shared/layouts/app-layout/app-layout.ts` — navbar gains **My claims**.

## 4 · Verify
1. **File a claim**: pick the seeded Active policy → fill incident + parties → leave the
   two trip events (AppOnline before, RideCompleted after — brackets the incident) →
   submit → result panel: claim number + derived period + preliminary decision + amount.
2. Try the **"app was not in use"** checkbox variant → App Off first assessment.
3. **My claims**: chips (Awaiting pickup / Under investigation / Report submitted / Paid / Rejected),
   pager, rows show claimed (+ Paid amount when present) + Flagged chip.
4. **Claim details**: first-assessment card, incident & parties, trip-log timeline,
   field checks (Pending → seeds), status-history timeline. Seeded claims
   (CLM-2026-…) show fuller stories (Verifications, report on the reported one).
5. `ng test` green.
