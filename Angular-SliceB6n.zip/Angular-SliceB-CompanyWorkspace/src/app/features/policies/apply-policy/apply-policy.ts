import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { QuoteService } from '../../../core/services/quote.service';
import { PolicyService } from '../../../core/services/policy.service';
import { Quote, TierName } from '../../../core/models/quote.model';
import { ApplyPolicyRequest, ApplyPolicyResponse, PayPolicyResponse } from '../../../core/models/policy.model';
import { TIER_OPTIONS, ADD_ON_OPTIONS } from '../../../core/constants/pricing';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-apply-policy',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe],
  templateUrl: './apply-policy.html',
  styleUrl: './apply-policy.css',
})
export class ApplyPolicy {
  private readonly fb = inject(FormBuilder);
  private readonly route = inject(ActivatedRoute);
  private readonly quotesApi = inject(QuoteService);
  private readonly policies = inject(PolicyService);

  readonly tiers = TIER_OPTIONS;
  readonly addOns = ADD_ON_OPTIONS;

  readonly quoteId = this.route.snapshot.queryParamMap.get('quoteId');

  // From-scratch inputs (used only when no quoteId is present)
  readonly form = this.fb.nonNullable.group({
    fleetSize: [25, [Validators.required, Validators.min(1)]],
    tier: ['Tier B' as TierName, Validators.required],
  });
  private readonly selectedAddOns = signal<ReadonlySet<string>>(new Set());

  readonly loadingQuote = signal(false);
  readonly quote = signal<Quote | null>(null);
  readonly quoteError = signal<string | null>(null);

  readonly submitting = signal(false);
  readonly submitError = signal<string | null>(null);
  readonly applied = signal<ApplyPolicyResponse | null>(null);

  readonly paying = signal(false);
  readonly payError = signal<string | null>(null);
  readonly paid = signal<PayPolicyResponse | null>(null);

  constructor() {
    if (this.quoteId) {
      this.loadingQuote.set(true);
      this.quotesApi.get(this.quoteId).subscribe({
        next: (q) => {
          this.quote.set(q);
          this.loadingQuote.set(false);
        },
        error: (err) => {
          this.quoteError.set(responseErrorText(err));
          this.loadingQuote.set(false);
        },
      });
    }
  }

  hasAddOn(key: string): boolean {
    return this.selectedAddOns().has(key);
  }

  selectTier(key: 'Tier A' | 'Tier B'): void {
    this.form.controls.tier.setValue(key);
  }

  toggleAddOn(key: string): void {
    const next = new Set(this.selectedAddOns());
    next.has(key) ? next.delete(key) : next.add(key);
    this.selectedAddOns.set(next);
  }

  submit(): void {
    const q = this.quote();
    let body: ApplyPolicyRequest;
    if (q) {
      // From-quote: inputs echo the quote; InsuranceService cross-checks (FR3.4).
      body = { originQuoteId: q.id, tier: q.tier, addOns: q.addOns, fleetSize: q.fleetSize };
    } else {
      if (this.form.invalid) {
        this.form.markAllAsTouched();
        return;
      }
      const v = this.form.getRawValue();
      body = { originQuoteId: null, tier: v.tier, addOns: [...this.selectedAddOns()], fleetSize: v.fleetSize };
    }
    this.submitting.set(true);
    this.submitError.set(null);
    this.policies.apply(body).subscribe({
      next: (res) => {
        this.applied.set(res);
        this.submitting.set(false);
      },
      error: (err) => {
        this.submitError.set(responseErrorText(err));
        this.submitting.set(false);
      },
    });
  }

  pay(): void {
    const a = this.applied();
    if (!a) return;
    this.paying.set(true);
    this.payError.set(null);
    this.policies.pay(a.policyId).subscribe({
      next: (res) => {
        this.paid.set(res);
        this.paying.set(false);
      },
      error: (err) => {
        this.payError.set(responseErrorText(err));
        this.paying.set(false);
      },
    });
  }
}
