import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { ClaimDetailsPage } from './claim-details';

describe('ClaimDetailsPage', () => {
  let component: ClaimDetailsPage;
  let fixture: ComponentFixture<ClaimDetailsPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClaimDetailsPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(ClaimDetailsPage);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
