import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimDetails } from '../../../core/models/claim.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-claim-details',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './claim-details.html',
  styleUrl: './claim-details.css',
})
export class ClaimDetailsPage {
  private readonly route = inject(ActivatedRoute);
  private readonly claimsApi = inject(ClaimsApiService);

  private readonly id = this.route.snapshot.paramMap.get('id')!;

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly claim = signal<ClaimDetails | null>(null);

  constructor() {
    this.claimsApi.get(this.id).subscribe({
      next: (c) => {
        this.claim.set(c);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      case 'UnderInvestigation':
      case 'SurveyorReportSubmitted':
        return 'bg-blue-100 text-blue-800';
      case 'AwaitingSurveyorPickup':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  verificationChip(status: string): string {
    switch (status) {
      case 'Verified':
        return 'bg-green-100 text-green-800';
      case 'Suspicious':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-warm-light text-ink-soft'; // Pending
    }
  }

  periodChip(period: string): string {
    return period === 'App Off' ? 'bg-red-100 text-red-700' : 'bg-primary-faint text-primary';
  }

  /** "AwaitingSurveyorPickup" / "AppOnline" → spaced words */
  pretty(s: string): string {
    return s.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  fmtDate(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }

  fmtTime(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime())
      ? '—'
      : `${d.toLocaleDateString('en-GB').replaceAll('/', '-')} ${d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
  }
}
