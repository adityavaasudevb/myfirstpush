import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PolicyService } from '../../../core/services/policy.service';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { PolicyListItem } from '../../../core/models/policy.model';
import {
  CreateClaimRequest,
  CreateClaimResponse,
  TripEventInput,
  CLAIM_TYPES,
  TRIP_EVENT_TYPES,
} from '../../../core/models/claim.model';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

interface TripEventForm {
  eventType: string;
  occurredAt: string; // datetime-local value
}

@Component({
  selector: 'app-file-claim',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, MoneyPipe],
  templateUrl: './file-claim.html',
  styleUrl: './file-claim.css',
})
export class FileClaim {
  private readonly fb = inject(FormBuilder);
  private readonly policies = inject(PolicyService);
  private readonly claimsApi = inject(ClaimsApiService);

  readonly claimTypes = CLAIM_TYPES;
  readonly eventTypes = TRIP_EVENT_TYPES;

  readonly loadingPolicies = signal(true);
  readonly activePolicies = signal<PolicyListItem[]>([]);

  readonly form = this.fb.nonNullable.group({
    policyId: ['', Validators.required],
    driverName: ['', Validators.required],
    driverLicenceNumber: ['', Validators.required],
    vehicleNumber: ['', Validators.required],
    passengerName: ['', Validators.required],
    passengerContact: ['', Validators.required],
    incidentAt: ['', Validators.required],
    incidentLocation: ['', Validators.required],
    description: ['', [Validators.required, Validators.minLength(10)]],
    claimedAmountInr: [0, [Validators.required, Validators.min(1)]],
    claimType: ['Third-Party Liability', Validators.required],
    documentLink: ['', Validators.required],
    appNotInUseDeclared: [false],
  });

  readonly events = signal<TripEventForm[]>([
    { eventType: 'AppOnline', occurredAt: '' },
    { eventType: 'RideCompleted', occurredAt: '' },
  ]);

  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);
  readonly result = signal<CreateClaimResponse | null>(null);

  constructor() {
    this.policies.mine({ status: 'Active' }).subscribe({
      next: (pg) => {
        this.activePolicies.set(pg.items);
        this.loadingPolicies.set(false);
      },
      error: () => this.loadingPolicies.set(false),
    });
  }

  addEvent(): void {
    this.events.update((es) => [...es, { eventType: 'AppOnline', occurredAt: '' }]);
  }

  removeEvent(i: number): void {
    this.events.update((es) => es.filter((_, ix) => ix !== i));
  }

  patchEvent(i: number, patch: Partial<TripEventForm>): void {
    this.events.update((es) => es.map((e, ix) => (ix === i ? { ...e, ...patch } : e)));
  }

  periodChip(period: string): string {
    return period === 'App Off'
      ? 'bg-red-100 text-red-700'
      : 'bg-primary-faint text-primary';
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    this.error.set(null);
    const v = this.form.getRawValue();
    const tripEvents: TripEventInput[] | null = v.appNotInUseDeclared
      ? null
      : this.events()
          .filter((e) => e.occurredAt)
          .map((e) => ({ eventType: e.eventType, occurredAtUtc: new Date(e.occurredAt).toISOString() }));
    const body: CreateClaimRequest = {
      policyId: v.policyId,
      driverName: v.driverName,
      driverLicenceNumber: v.driverLicenceNumber,
      vehicleNumber: v.vehicleNumber,
      passengerName: v.passengerName,
      passengerContact: v.passengerContact,
      incidentAtUtc: new Date(v.incidentAt).toISOString(),
      incidentLocation: v.incidentLocation,
      description: v.description,
      claimedAmountInr: Number(v.claimedAmountInr),
      claimType: v.claimType,
      documentLink: v.documentLink,
      appNotInUseDeclared: v.appNotInUseDeclared,
      tripEvents,
    };
    this.claimsApi.file(body).subscribe({
      next: (res) => {
        this.result.set(res);
        this.submitting.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.submitting.set(false);
      },
    });
  }
}
