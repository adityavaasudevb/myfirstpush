import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { FileClaim } from './file-claim';

describe('FileClaim', () => {
  let component: FileClaim;
  let fixture: ComponentFixture<FileClaim>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FileClaim],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(FileClaim);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
