import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimListItem } from '../../../core/models/claim.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

const FILTERS = [
  { key: 'All', label: 'All' },
  { key: 'AwaitingSurveyorPickup', label: 'Awaiting pickup' },
  { key: 'UnderInvestigation', label: 'Under investigation' },
  { key: 'SurveyorReportSubmitted', label: 'Report submitted' },
  { key: 'Paid', label: 'Paid' },
  { key: 'Rejected', label: 'Rejected' },
];

@Component({
  selector: 'app-my-claims',
  imports: [CommonModule, RouterLink, MoneyPipe],
  templateUrl: './my-claims.html',
  styleUrl: './my-claims.css',
})
export class MyClaims {
  private readonly claimsApi = inject(ClaimsApiService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<ClaimListItem> | null>(null);
  readonly statusFilter = signal('All');
  readonly page = signal(1);

  readonly filters = FILTERS;

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.claimsApi
      .mine({ page: this.page(), status: this.statusFilter() === 'All' ? undefined : this.statusFilter() })
      .subscribe({
        next: (pg) => {
          this.paged.set(pg);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }

  setFilter(f: string): void {
    if (this.statusFilter() === f) return;
    this.statusFilter.set(f);
    this.page.set(1);
    this.reload();
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  statusChip(status: string): string {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      case 'UnderInvestigation':
      case 'SurveyorReportSubmitted':
        return 'bg-blue-100 text-blue-800';
      case 'AwaitingSurveyorPickup':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  /** "AwaitingSurveyorPickup" → "Awaiting surveyor pickup" */
  pretty(status: string): string {
    return status.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  fmt(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
