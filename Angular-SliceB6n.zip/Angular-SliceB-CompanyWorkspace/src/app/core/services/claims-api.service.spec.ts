import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { ClaimsApiService } from './claims-api.service';

describe('ClaimsApiService', () => {
  let service: ClaimsApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(ClaimsApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
