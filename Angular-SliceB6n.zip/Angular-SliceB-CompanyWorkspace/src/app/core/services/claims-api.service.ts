import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ClaimDetails,
  ClaimListItem,
  CreateClaimRequest,
  CreateClaimResponse,
} from '../models/claim.model';
import { Paged, unwrapPaged } from '../models/paged';

const API = environment.apiBaseUrl;

/** Server page size for claim lists (change in one place). */
export const PAGE_SIZE = 25;

// Claim endpoints (doc §6.4). Ownership is resolved server-side from the token.
@Injectable({ providedIn: 'root' })
export class ClaimsApiService {
  private readonly http = inject(HttpClient);

  /** FR5.1/FR5.2 — intake; the response already carries the preliminary
   *  rules-engine outcome (period, decision, amount, flags). */
  file(body: CreateClaimRequest): Observable<CreateClaimResponse> {
    return this.http.post<CreateClaimResponse>(`${API}/claims`, body);
  }

  /** FR9.4 — the caller's claims, paged, optional status + incident-date filters. */
  mine(filter?: { status?: string; from?: string; to?: string; page?: number }): Observable<Paged<ClaimListItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', PAGE_SIZE);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.from) params = params.set('incidentFrom', filter.from);
    if (filter?.to) params = params.set('incidentTo', filter.to);
    return this.http
      .get<unknown>(`${API}/claims/company`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizeListItem)));
  }

  /** FR5.17 — full claim: children, report, status history. */
  get(id: string): Observable<ClaimDetails> {
    return this.http.get<ClaimDetails>(`${API}/claims/${id}`);
  }
}

type Raw = Record<string, any>;

function normalizeListItem(c: Raw): ClaimListItem {
  return {
    ...c,
    finalPayoutAmountInr: c.finalPayoutAmountInr ?? null,
  } as ClaimListItem;
}
