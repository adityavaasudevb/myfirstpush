# Slice C — Surveyor (C1 queue+pickup · C2 investigation) 

All contracts verified against the real ClaimsController:
- `GET queue` / `GET assigned` → paged ClaimQueueItemDto
- `POST pickup` / `POST verify-field` / `POST report` → **204 No Content**
- Verification fields: DriverInfo · PassengerInfo · TripEventLog · Documents
- Report vocab: outcome Genuine/Suspicious/Fraudulent · recommendation Approve/Reject

## 1 · Generate
```
ng g c features/claims/assigned-claims
ng g c features/claims/investigate-claim
```
(The queue page REPLACES the slice-A `surveyor-queue` placeholder — keep its
existing spec, it already has the providers.) Replace the two new specs with the
zip versions. Re-paste `core/models/claim.model.ts` (gains queue + action types)
and `core/services/claims-api.service.ts` (gains the surveyor methods).

## 2 · Routes — replace the surveyor block in app.routes.ts
The slice-A block was `/surveyor → children: [{ path: '', component: SurveyorQueue }]`.
Make its children:
```
{ path: '', component: SurveyorQueue },
{ path: 'assigned', component: AssignedClaims },
{ path: 'claims/:id', component: InvestigateClaim },
```
(keep the existing authGuard + role data wrapping it)

## 3 · Verify (login as raj.surveyor@claimsurvey.in — approved)
1. **Queue**: your AppOffReject test claim (CLM-2026-98B4AA4B) should be listed —
   Flagged chip if flagged; **Pick up →** → toast, lands on the investigation page
   (status now Under Investigation; the queue no longer shows it).
2. **My investigations**: the picked claim listed → Continue →
3. **Investigate**: trip-log timeline, intake, documents link; verify all four fields
   (try one Suspicious with a note); once none Pending → report form unlocks →
   submit Approve w/ amount → toast → back to My investigations (claim now
   "Surveyor Report Submitted").
4. Check with Company login → My claims → that claim shows the new status + field checks.
5. `ng test` green.
