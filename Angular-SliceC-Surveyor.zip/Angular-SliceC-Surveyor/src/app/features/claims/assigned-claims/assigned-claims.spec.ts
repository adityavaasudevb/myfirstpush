import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { AssignedClaims } from './assigned-claims';

describe('AssignedClaims', () => {
  let component: AssignedClaims;
  let fixture: ComponentFixture<AssignedClaims>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssignedClaims],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(AssignedClaims);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
