import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimQueueItem } from '../../../core/models/claim.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-assigned-claims',
  imports: [CommonModule, RouterLink, MoneyPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './assigned-claims.html',
  styleUrl: './assigned-claims.css',
})
export class AssignedClaims {
  private readonly claimsApi = inject(ClaimsApiService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<ClaimQueueItem> | null>(null);
  readonly page = signal(1);

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.claimsApi.assigned(this.page()).subscribe({
      next: (pg) => {
        this.paged.set(pg);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(responseErrorText(err));
        this.loading.set(false);
      },
    });
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  pretty(s: string): string {
    return s.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  statusChip(status: string): string {
    switch (status) {
      case 'UnderInvestigation':
        return 'bg-blue-100 text-blue-800';
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      case 'SurveyorReportSubmitted':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-warm-light text-ink-soft';
    }
  }

  fmt(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
