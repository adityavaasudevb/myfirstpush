import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ClaimsApiService } from '../../../core/services/claims-api.service';
import { ClaimQueueItem } from '../../../core/models/claim.model';
import { Paged } from '../../../core/models/paged';
import { MoneyPipe } from '../../../shared/ui/money-pipe';
import { AlertService } from '../../../shared/toast/alert.service';
import { responseErrorText } from '../../../core/services/auth.service';

@Component({
  selector: 'app-surveyor-queue',
  imports: [CommonModule, RouterLink, MoneyPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './surveyor-queue.html',
  styleUrl: './surveyor-queue.css',
})
export class SurveyorQueue {
  private readonly claimsApi = inject(ClaimsApiService);
  private readonly alerts = inject(AlertService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly paged = signal<Paged<ClaimQueueItem> | null>(null);
  readonly flaggedOnly = signal(false);
  readonly page = signal(1);
  readonly pickingId = signal<string | null>(null);

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.claimsApi
      .queue({ page: this.page(), isFlagged: this.flaggedOnly() ? true : undefined })
      .subscribe({
        next: (pg) => {
          this.paged.set(pg);
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(responseErrorText(err));
          this.loading.set(false);
        },
      });
  }

  setFlaggedOnly(v: boolean): void {
    if (this.flaggedOnly() === v) return;
    this.flaggedOnly.set(v);
    this.page.set(1);
    this.reload();
  }

  goTo(p: number): void {
    if (p < 1 || p > this.totalPages() || p === this.page()) return;
    this.page.set(p);
    this.reload();
  }

  totalPages(): number {
    const pg = this.paged();
    return pg ? Math.max(1, Math.ceil(pg.total / pg.pageSize)) : 1;
  }

  pages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  /** FR5.9 — atomic pickup; on success the claim lands in My investigations. */
  pickUp(c: ClaimQueueItem): void {
    this.pickingId.set(c.id);
    this.claimsApi.pickup(c.id).subscribe({
      next: () => {
        this.alerts.success(`${c.claimNumber} is assigned to you.`);
        this.router.navigate(['/surveyor/claims', c.id]);
      },
      error: (err) => {
        this.pickingId.set(null);
        this.alerts.error(responseErrorText(err)); // e.g. someone picked it first (409)
        this.reload();
      },
    });
  }

  // ---- display helpers ----

  pretty(s: string): string {
    return s.replace(/([a-z])([A-Z])/g, '$1 $2');
  }

  periodChip(period: string): string {
    return period === 'App Off' ? 'bg-red-100 text-red-700' : 'bg-primary-faint text-primary';
  }

  fmt(iso: string): string {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-GB').replaceAll('/', '-');
  }
}
