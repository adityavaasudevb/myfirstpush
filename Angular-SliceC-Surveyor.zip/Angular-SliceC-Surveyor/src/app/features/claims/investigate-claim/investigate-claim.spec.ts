import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

import { InvestigateClaim } from './investigate-claim';

describe('InvestigateClaim', () => {
  let component: InvestigateClaim;
  let fixture: ComponentFixture<InvestigateClaim>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InvestigateClaim],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(InvestigateClaim);
    expect(fixture.componentInstance).toBeTruthy();
  });
});
