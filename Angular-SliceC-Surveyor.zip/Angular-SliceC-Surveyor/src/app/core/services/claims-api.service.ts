import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ClaimDetails,
  ClaimListItem,
  ClaimQueueItem,
  CreateClaimRequest,
  CreateClaimResponse,
  SubmitReportRequest,
  VerifyFieldRequest,
} from '../models/claim.model';
import { Paged, unwrapPaged } from '../models/paged';

const API = environment.apiBaseUrl;

/** Server page size for claim lists (change in one place). */
export const PAGE_SIZE = 25;

// Claim endpoints (doc §6.4). Ownership/assignment is enforced server-side.
@Injectable({ providedIn: 'root' })
export class ClaimsApiService {
  private readonly http = inject(HttpClient);

  // ------------------------------- company -------------------------------

  /** FR5.1/FR5.2 — intake; the response already carries the preliminary outcome. */
  file(body: CreateClaimRequest): Observable<CreateClaimResponse> {
    return this.http.post<CreateClaimResponse>(`${API}/claims`, body);
  }

  /** FR9.4 — the caller's claims, paged, optional status + incident-date filters. */
  mine(filter?: { status?: string; from?: string; to?: string; page?: number }): Observable<Paged<ClaimListItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', PAGE_SIZE);
    if (filter?.status) params = params.set('status', filter.status);
    if (filter?.from) params = params.set('incidentFrom', filter.from);
    if (filter?.to) params = params.set('incidentTo', filter.to);
    return this.http
      .get<unknown>(`${API}/claims/company`, { params })
      .pipe(map((res) => unwrapPaged(res, normalizeListItem)));
  }

  /** FR5.17 — full claim (Company own / Admin / assigned Surveyor). */
  get(id: string): Observable<ClaimDetails> {
    return this.http.get<ClaimDetails>(`${API}/claims/${id}`);
  }

  // ------------------------------- surveyor -------------------------------

  /** FR5.9/FR9.3 — open queue (unassigned, AwaitingSurveyorPickup). */
  queue(filter?: { isFlagged?: boolean; from?: string; to?: string; page?: number }): Observable<Paged<ClaimQueueItem>> {
    let params = new HttpParams().set('page', filter?.page ?? 1).set('pageSize', PAGE_SIZE);
    if (filter?.isFlagged != null) params = params.set('isFlagged', filter.isFlagged);
    if (filter?.from) params = params.set('incidentFrom', filter.from);
    if (filter?.to) params = params.set('incidentTo', filter.to);
    return this.http
      .get<unknown>(`${API}/claims/queue`, { params })
      .pipe(map((res) => unwrapPaged(res, (c) => c)));
  }

  /** FR9.3 — claims assigned to the caller. */
  assigned(page = 1): Observable<Paged<ClaimQueueItem>> {
    const params = new HttpParams().set('page', page).set('pageSize', PAGE_SIZE);
    return this.http
      .get<unknown>(`${API}/claims/assigned`, { params })
      .pipe(map((res) => unwrapPaged(res, (c) => c)));
  }

  /** FR5.9 — atomic pickup; 409 if someone won the race. Creates the four
   *  Pending field-verification records. Returns 204. */
  pickup(id: string): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/pickup`, {});
  }

  /** FR5.10 — mark one field Verified/Suspicious (+ optional note). 204. */
  verifyField(id: string, body: VerifyFieldRequest): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/verify-field`, body);
  }

  /** FR5.13 — final report; 409 while any field is Pending. 204. */
  submitReport(id: string, body: SubmitReportRequest): Observable<void> {
    return this.http.post<void>(`${API}/claims/${id}/report`, body);
  }
}

type Raw = Record<string, any>;

function normalizeListItem(c: Raw): ClaimListItem {
  return {
    ...c,
    finalPayoutAmountInr: c.finalPayoutAmountInr ?? null,
  } as ClaimListItem;
}
