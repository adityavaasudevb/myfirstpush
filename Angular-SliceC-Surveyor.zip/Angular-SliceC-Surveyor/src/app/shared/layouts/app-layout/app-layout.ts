import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { Role } from '../../../core/constants/roles';

interface NavLink {
  label: string;
  route: string;
  exact?: boolean;
}

// Role-based navbar links — extended as more workspace pages are built.
const ROLE_NAV: Record<Role, NavLink[]> = {
  Company: [
    { label: 'Dashboard', route: '/company', exact: true },
    { label: 'Get a quote', route: '/company/quotes/new' },
    { label: 'My quotes', route: '/company/quotes' },
    { label: 'My policies', route: '/company/policies' },
    { label: 'My claims', route: '/company/claims' },
  ],
  Surveyor: [
    { label: 'Open queue', route: '/surveyor', exact: true },
    { label: 'My investigations', route: '/surveyor/assigned' },
  ],
  Admin: [{ label: 'Overview', route: '/admin', exact: true }],
};

@Component({
  selector: 'app-app-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app-layout.html',
  styleUrl: './app-layout.css',
})
export class AppLayout {
  readonly auth = inject(AuthService);

  links(): NavLink[] {
    const r = this.auth.role();
    return r ? ROLE_NAV[r] : [];
  }
}
